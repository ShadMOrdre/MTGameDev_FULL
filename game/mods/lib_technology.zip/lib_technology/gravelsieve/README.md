# Gravel Sieve Mod
A Mod for those who do not want to spend half their lives underground...

Inspired from a Minecr**t Video on YT.

This mod simplifies the extraction of ores by the fact that ores can be obtained simply by sieving gravel.

This mod includes three new tools:
 - a hammer to produce gravel from Cobblestone
 - two gravel sieves to find ores (a manual sieve and a automatic sieve)

The sieved gravel can be crafted to Compressed Gravel (inspired by Modern Hippie) and "cooked" in the furnace to get Cobblestone again.

Recipe for the Gravel Sieve:

    Wood,  -----------,  Wood
    Wood,  Steel Ingot,  Wood
    Wood,  -----------,  Wood


Recipe for the Automatic Gravel Sieve:

    Gravel Sieve,  Mese Crystal,  Mese Crystal


Recipe for Compressed Gravel:

    Sieved Gravel, Sieved Gravel,
    Sieved Gravel, Sieved Gravel,


### Dependencies
default, optional moreores, hopper, and pipeworks
