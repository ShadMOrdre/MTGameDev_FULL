bucket
=========================
This is an addition to the Minetest Game `bucket` mod that implements the `fluid_lib` API seamlessly.
See license.txt for original license information.

Authors of source code
----------------------
Kahrl <kahrl@gmx.net> (LGPL 2.1)

celeron55, Perttu Ahola <celeron55@gmail.com> (LGPL 2.1)

Various Minetest developers and contributors (LGPL 2.1)

Modified by Evert "Diamond" Prants <evert@lunasqu.ee> (MIT)

Authors of media (textures)
---------------------------
ElementW (CC BY-SA 3.0)
