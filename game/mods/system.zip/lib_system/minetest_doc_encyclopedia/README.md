# Encyclopedia [`doc_encyclopedia`]
This mod adds an item to access the help (based on the
Documentation System [`doc`]. Just hold the item in hand and punch.

Version: 1.2.0.

## Crafting
The encyclopedia is crafted with this shaped recipe:

    SS
    S S
    SS

* `S`: Any item in group “stick”

If you use Minetest Game (mod `default`), there's another recipe
possible:

     B
     B
     B

* `B`: Book

## Itemstring
The itemstring of this item is `doc_encyclopedia:encyclopedia`.

## License
Everything in this mod is licensed under the MIT License.
