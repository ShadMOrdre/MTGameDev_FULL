falling.lua replacement

edited by TenPlus1

Features:
- Added new group {falling_node_hurt} to hurt player or mobs below falling items
- Falling nodes will only replace air, buildable to, water and attached nodes
- Any attached nodes will drop items when replaced

License: MIT
