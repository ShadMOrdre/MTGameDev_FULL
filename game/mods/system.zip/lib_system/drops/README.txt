Install this by putting it in your .minetest/mods folder.
