item_entity.lua replacement

edited by TenPlus1

Features:
- Items are destroyed by lava
- Items are pushed along by flowing water (thanks to QwertyMine3)
- Items are removed after 900 seconds or the time that is specified by
   remove_items in minetest.conf (-1 disables it)
- Particle effects added
- Dropped items keep sliding when on ice
- Items stuck inside solid nodes move to nearest empty space

License: MIT
