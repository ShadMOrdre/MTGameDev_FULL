This mod adds new sounds to torches.

Works with default torches and sofars (Blockmens) 3d Torches
