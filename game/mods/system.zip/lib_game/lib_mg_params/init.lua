

--[[
minetest.register_on_mapgen_init(function(mgparams)
	minetest.set_mapgen_params({mgname="valleys"})
	minetest.setting_set("mg_valleys_lava_features", 0)
	minetest.setting_set("mg_valleys_water_features", 0)
end)
--]]


-- the mod object
lib_mg_params = {}
lib_mg_params.version = "1.0"
lib_mg_params.path = minetest.get_modpath(minetest.get_current_modname())

-- Intllib
local S
local NS
if minetest.get_modpath("game") then
	S = game.intllib
else
	if minetest.get_modpath("intllib") then
		S = intllib.Getter()
	else
		S, NS = dofile(lib_mg_params.path.."/intllib.lua")
	end
end
lib_mg_params.intllib = S

minetest.log(S("[MOD]: lib_mg_params:  Loading..."))

if game then
	lib_mg_params.world_type = game.world_type
else
	lib_mg_params.world_type = minetest.settings:get("lib_mg_params_world_type") or 2
end
minetest.log(S("[MOD]: lib_mg_params:  Using world type " .. tostring(lib_mg_params.world_type)))


-- minetest.register_on_mapgen_init(function(mgparams)

	-- --######################################################################################################################################################################
	-- --##  world_type options:                                                                                                                                             ##
	-- --##  Default = 0, Valleys = 1, Continental = 2, Continental_v2 = 3, Islands = 4, Islands_x2 = 5, Islands_x25 = 6, Islands_x3 = 7, Archipelago = 8, Floatworld = 9    ##
	-- --######################################################################################################################################################################

	if lib_mg_params.world_type == 0 then
		minetest.set_mapgen_setting("mg_name", "v7", true)
		-- minetest.set_mapgen_setting("mgv7_spflags", "mountains,ridges,nofloatlands,caverns", true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_alt", {lacunarity = 2, offset = 4, scale = 25, spread = {600,600,600}, seed = 5934, octaves = 5, persistence = 0.6, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_height_select", {lacunarity = 2, offset = -8, scale = 16, spread = {500,500,500}, seed = 4213, octaves = 6, persistence = 0.7, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_base", {lacunarity = 2, offset = 4, scale = 70, spread = {600,600,600}, seed = 82341, octaves = 5, persistence = 0.6, flags = "defaults"}, true)
	elseif lib_mg_params.world_type == 1 then
		minetest.set_mapgen_setting("mg_name", "valleys", true)
		-- minetest.set_mapgen_setting_noiseparams("mgvalleys_np_terrain_height", {lacunarity = 2, offset = -10, scale = 50, spread = {1024,1024,1024}, seed = 5202, octaves = 6, persistence = 0.4, flags = "eased"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgvalleys_np_valley_depth", {lacunarity = 2, offset = 5, scale = 4, spread = {512,512,512}, seed = -1914, octaves = 1, persistence = 1, flags = "eased"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgvalleys_np_valley_profile", {lacunarity = 2, offset = 0.6, scale = 0.5, spread = {512,512,512}, seed = 777, octaves = 1, persistence = 1, flags = "eased"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgvalleys_np_inter_valley_fill", {lacunarity = 2, offset = 0, scale = 1, spread = {256,512,256}, seed = 1993, octaves = 6, persistence = 0.8, flags = "eased"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgvalleys_np_inter_valley_slope", {lacunarity = 2, offset = 0.5, scale = 0.5, spread = {128,128,128}, seed = 746, octaves = 1, persistence = 1, flags = "eased"}, true)
	-- elseif lib_mg_params.world_type == 2 then
		-- minetest.set_mapgen_setting("mg_name", "v7", true)
		-- minetest.set_mapgen_setting("mgv7_spflags", "nomountains,noridges,nofloatlands,nocaverns", true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_alt", {lacunarity = 2, offset = 4, scale = 100, spread = {2400,2400,2400}, seed = 5934, octaves = 6, persistence = 0.6, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_height_select", {lacunarity = 2, offset = -0.5, scale = 1, spread = {500,500,500}, seed = 4213, octaves = 4, persistence = 0.4, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_base", {lacunarity = 2, offset = 4, scale = 400, spread = {2400,2400,2400}, seed = 5934, octaves = 8, persistence = 0.3, flags = "defaults"}, true)
	-- elseif lib_mg_params.world_type == 3 then
		-- minetest.set_mapgen_setting("mg_name", "v7", true)
		-- minetest.set_mapgen_setting("mgv7_spflags", "nomountains,noridges,nofloatlands,nocaverns", true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_alt", {lacunarity = 2, offset = 4, scale = 100, spread = {2400,2400,2400}, seed = 5934, octaves = 6, persistence = 0.6, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_height_select", {lacunarity = 2, offset = -0.5, scale = 1, spread = {500,500,500}, seed = 4213, octaves = 4, persistence = 0.4, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_base", {lacunarity = 2, offset = 4, scale = 400, spread = {2400,2400,2400}, seed = 82341, octaves = 8, persistence = 0.3, flags = "defaults"}, true)
	-- elseif lib_mg_params.world_type == 4 then
		-- minetest.set_mapgen_setting("mg_name", "v7", true)
		-- minetest.set_mapgen_setting("mgv7_spflags", "nomountains,noridges,nofloatlands,nocaverns", true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_alt", {lacunarity = 2, offset = 4, scale = 100, spread = {600,600,600}, seed = 5934, octaves = 6, persistence = 0.6, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_height_select", {lacunarity = 2, offset = -0.5, scale = 1, spread = {500,500,500}, seed = 4213, octaves = 4, persistence = 0.4, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_base", {lacunarity = 2, offset = 4, scale = 400, spread = {600,600,600}, seed = 5934, octaves = 8, persistence = 0.3, flags = "defaults"}, true)
	-- elseif lib_mg_params.world_type == 5 then
		-- minetest.set_mapgen_setting("mg_name", "v7", true)
		-- minetest.set_mapgen_setting("mgv7_spflags", "nomountains,noridges,nofloatlands,nocaverns", true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_alt", {lacunarity = 2, offset = 4, scale = 100, spread = {1200,1200,1200}, seed = 5934, octaves = 6, persistence = 0.6, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_height_select", {lacunarity = 2, offset = -0.5, scale = 1, spread = {500,500,500}, seed = 4213, octaves = 4, persistence = 0.4, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_base", {lacunarity = 2, offset = 4, scale = 400, spread = {1200,1200,1200}, seed = 5934, octaves = 8, persistence = 0.3, flags = "defaults"}, true)
	-- elseif lib_mg_params.world_type == 6 then
		-- minetest.set_mapgen_setting("mg_name", "v7", true)
		-- minetest.set_mapgen_setting("mgv7_spflags", "nomountains,noridges,nofloatlands,nocaverns", true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_alt", {lacunarity = 2, offset = 4, scale = 100, spread = {1536,1536,1536}, seed = 5934, octaves = 6, persistence = 0.6, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_height_select", {lacunarity = 2, offset = -0.5, scale = 1, spread = {500,500,500}, seed = 4213, octaves = 4, persistence = 0.4, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_base", {lacunarity = 2, offset = 4, scale = 400, spread = {1536,1536,1536}, seed = 5934, octaves = 8, persistence = 0.3, flags = "defaults"}, true)
	-- elseif lib_mg_params.world_type == 7 then
		-- minetest.set_mapgen_setting("mg_name", "v7", true)
		-- minetest.set_mapgen_setting("mgv7_spflags", "nomountains,noridges,nofloatlands,nocaverns", true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_alt", {lacunarity = 2, offset = 4, scale = 100, spread = {1800,1800,1800}, seed = 5934, octaves = 6, persistence = 0.6, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_height_select", {lacunarity = 2, offset = -0.5, scale = 1, spread = {500,500,500}, seed = 4213, octaves = 4, persistence = 0.4, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_base", {lacunarity = 2, offset = 4, scale = 400, spread = {1800,1800,1800}, seed = 5934, octaves = 8, persistence = 0.3, flags = "defaults"}, true)
	-- elseif lib_mg_params.world_type == 8 then
		-- minetest.set_mapgen_setting("mg_name", "v7", true)
		-- minetest.set_mapgen_setting("mgv7_spflags", "mountains,ridges,floatlands,caverns", true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_alt", {lacunarity = 2, offset = 4, scale = 25, spread = {600,600,600}, seed = 5934, octaves = 5, persistence = 0.6, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_height_select", {lacunarity = 2, offset = -8, scale = 16, spread = {500,500,500}, seed = 4213, octaves = 6, persistence = 0.7, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_base", {lacunarity = 2, offset = 4, scale = 70, spread = {600,600,600}, seed = 82341, octaves = 5, persistence = 0.6, flags = "defaults"}, true)
	-- elseif lib_mg_params.world_type == 9 then
		-- minetest.set_mapgen_setting("mg_name", "valleys", true)
		-- minetest.set_mapgen_setting_noiseparams("mgvalleys_np_terrain_height", {lacunarity = 2, offset = -5, scale = 25, spread = {1024,1024,1024}, seed = 5202, octaves = 6, persistence = 0.4, flags = "eased"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgvalleys_np_valley_depth", {lacunarity = 2, offset = 5, scale = 4, spread = {512,512,512}, seed = -1914, octaves = 1, persistence = 1, flags = "eased"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgvalleys_np_valley_profile", {lacunarity = 2, offset = 0.6, scale = 0.5, spread = {512,512,512}, seed = 777, octaves = 1, persistence = 1, flags = "eased"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgvalleys_np_inter_valley_fill", {lacunarity = 2, offset = 0, scale = 1, spread = {256,512,256}, seed = 1993, octaves = 6, persistence = 0.8, flags = "eased"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgvalleys_np_inter_valley_slope", {lacunarity = 2, offset = 0.5, scale = 0.5, spread = {128,128,128}, seed = 746, octaves = 1, persistence = 1, flags = "eased"}, true)
	-- elseif lib_mg_params.world_type == 10 then

	else
		-- minetest.set_mapgen_setting("mg_name", "v7", true)
		-- minetest.set_mapgen_setting("mgv7_spflags", "nomountains,noridges,nofloatlands,nocaverns", true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_alt", {lacunarity = 2, offset = 4, scale = 100, spread = {2400,2400,2400}, seed = 5934, octaves = 6, persistence = 0.6, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_height_select", {lacunarity = 2, offset = -0.5, scale = 1, spread = {500,500,500}, seed = 4213, octaves = 4, persistence = 0.4, flags = "defaults"}, true)
		-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_base", {lacunarity = 2, offset = 4, scale = 400, spread = {2400,2400,2400}, seed = 5934, octaves = 8, persistence = 0.3, flags = "defaults"}, true)
	end
-- end)



--[[
--minetest.log(S("[MOD] lib_mg_params using noise set " .. lib_mg_params.noise_set_id))

--lib_mg_params.use_gennotify = true --minetest.setting_getbool('lib_ecology_use_gennotify') or true
--minetest.set_gen_notify("alternative_cave")

-- minetest.register_on_mapgen_init(function(mgparams)
  -- --minetest.set_mapgen_params({mgname="singlenode", flags="nolight"})
  -- minetest.set_mapgen_setting("mgname", "mgv7", true)
  -- minetest.set_mapgen_setting("mgv7_spflags", "nomountains, noridges, nofloatlands, nocaverns", true)
  
	--minetest.set_mapgen_setting(name, value, [override_meta])
	--mgv7_spflags = mountains,ridges,nofloatlands,caverns
	-- minetest.set_mapgen_setting("mgname", "mgv7", true)
	-- minetest.set_mapgen_setting("mgv7_spflags", "nomountains,noridges,nofloatlands,nocaverns", true)
	-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_alt", {flags = defaults, lacunarity = 2, offset = 4, scale = 100, spread = {2400,2400,2400}, seed = 5934, octaves = 6, persistence = 0.6}, true)
	-- minetest.set_mapgen_setting_noiseparams("mgv7_np_height_select", {flags = defaults, lacunarity = 2, offset = -0.5, scale = 1, spread = {500,500,500}, seed = 4213, octaves = 4, persistence = 0.4}, true)
	-- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_base", {flags = defaults, lacunarity = 2, offset = 4, scale = 400, spread = {2400,2400,2400}, seed = 5934, octaves = 8, persistence = 0.3}, true)
 
  -- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_alt", {flags = defaults, lacunarity = 2, offset = 4, scale = 100, spread = {2400,2400,2400}, seed = 5934, octaves = 5, persistence = 0.7}, true)
  -- minetest.set_mapgen_setting_noiseparams("mgv7_np_height_select", {flags = defaults, lacunarity = 2, offset = -0.25, scale = 1, spread = {500,500,500}, seed = 4213, octaves = 4, persistence = 0.4}, true)
  -- minetest.set_mapgen_setting_noiseparams("mgv7_np_terrain_base", {flags = defaults, lacunarity = 2, offset = 4, scale = 400, spread = {2400,2400,2400}, seed = 82341, octaves = 8, persistence = 0.3}, true)
-- end)



--dofile(lib_mg_params.path.."/voxel.lua")
--]]



minetest.log(S("[MOD]: lib_mg_params:  Successfully Loaded."))





