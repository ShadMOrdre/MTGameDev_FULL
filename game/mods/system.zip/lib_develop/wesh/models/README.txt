This folder will contain your generated meshes, if you want to get rid of any of them you need to delete them from here

IMPORTANT: do NOT delete any of the "zzz_canvas_NN.obj" files!
