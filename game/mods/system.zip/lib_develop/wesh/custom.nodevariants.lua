-- only alter this file if it's named "custom.nodevariants.lua"
-- alter the variants as you please and delete / comment out
-- the variants you don't want to be available in the game
-- the original versions are in "default/nodevariants.lua"

return {
	plain = "plain-16.png",
	plainborder = "plain-border-72.png",
	wool = "wool-72.png",
	woolborder = "wool-border-72.png",
}
