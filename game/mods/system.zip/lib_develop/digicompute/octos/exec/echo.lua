local params = ...
local text   = (table.concat(params, " "))

print(text)
