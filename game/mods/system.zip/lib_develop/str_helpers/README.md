minetest-str_helpers
====================

Minetest string helpers library
