External Commands
----------------
This mod allows sending chat messages from outside minetest. Support for server commands is planned.
The following command will send a chat message to all players on the server:

	echo [message] > [mod folder]/message

The mod folder depends on where you installed the mod; it is usually “~/.minetest/mods/minetest/external_cmd”
