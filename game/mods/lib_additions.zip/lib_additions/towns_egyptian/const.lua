--
-- switch for debugging
--
towns_egyptian.debug = false
--
-- material to replace cobblestone with
--
towns_egyptian_wallmaterial = {
  "lib_materials:stone_adobe",
  "lib_materials:stone_sandstone",
  "lib_materials:stone_sandstone_desert",
  "lib_materials:stone_sandstone_silver",
  "lib_materials:stone_sandstone_white",
  "default:sandstone", 
  "default:desert_sandstone", 
  "default:desertstone_cobble",
}
--
-- path to schematics
--
towns_egyptian_schem_path = towns_egyptian.modpath.."/schematics/"
--
-- list of schematics
--  {name = "townhall", mts = towns_egyptian_schem_path.."townhall.mts", hsize = 15, max_num = 0, rplc = "n"},
--  {name = "well", mts = towns_egyptian_schem_path.."well.mts", hsize = 11, max_num = 0.045, rplc = "n"},
--  {name = "hut", mts = towns_egyptian_schem_path.."hut.mts", hsize = 11, max_num = 0.9, rplc = "y"},
--  {name = "garden", mts = towns_egyptian_schem_path.."garden.mts", hsize = 11, max_num = 0.1, rplc = "n"},
--  {name = "lamp", mts = towns_egyptian_schem_path.."lamp.mts", hsize = 10, max_num = 0.1, rplc = "n"},
--  {name = "tower", mts = towns_egyptian_schem_path.."tower.mts", hsize = 11, max_num = 0.055, rplc = "n"},
--  {name = "church", mts = towns_egyptian_schem_path.."church.mts", hsize = 17, max_num = 0.050, rplc = "n"},
--  {name = "blacksmith", mts = towns_egyptian_schem_path.."blacksmith.mts", hsize = 11, max_num = 0.050, rplc = "n"},
--  {name = "mgs_temple_anubis_new_01_19w_15l_10h_0_270", mts = towns_egyptian_schem_path.."mgs_temple_anubis_new_01_19w_15l_10h_0_270.mts", hsize = 20, max_num = 0.050, rplc = "n"},
--  {name = "mgs_temple_large_02_21w_19l_32h_0_180", mts = towns_egyptian_schem_path.."mgs_temple_large_02_21w_19l_32h_0_180.mts", hsize = 30, max_num = 0.050, rplc = "n"},
--  {name = "mgs_sand_house_01_11w_9l_8h_1_0", mts = towns_egyptian_schem_path.."mgs_sand_house_01_11w_9l_8h_1_0.mts", hsize = 10, max_num = 0.050, rplc = "n"},
-- {name = "trader_clay_1", mts = towns_egyptian_schem_path.."trader_clay_1.mts", hsize = 10, max_num = 0.050, rplc = "n"},
-- {name = "trader_clay_4", mts = towns_egyptian_schem_path.."trader_clay_4.mts", hsize = 10, max_num = 0.050, rplc = "n"},
-- {name = "clay_pit_1", mts = towns_egyptian_schem_path.."clay_pit_1.mts", hsize = 10, max_num = 0.050, rplc = "n"},
-- {name = "clay_pit_4", mts = towns_egyptian_schem_path.."clay_pit_4.mts", hsize = 10, max_num = 0.050, rplc = "n"},
--
--[[
  {name = "farm_full_3", mts = towns_egyptian_schem_path.."farm_full_3.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_full_4", mts = towns_egyptian_schem_path.."farm_full_4.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_tiny_4", mts = towns_egyptian_schem_path.."farm_tiny_4.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_tiny_5", mts = towns_egyptian_schem_path.."farm_tiny_5.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_tiny_6", mts = towns_egyptian_schem_path.."farm_tiny_6.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_tiny_7", mts = towns_egyptian_schem_path.."farm_tiny_7.mts", hsize = 20, max_num = 0.050, rplc = "n"},


  {name = "farm_full_2", mts = towns_egyptian_schem_path.."farm_full_2.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_tiny_2", mts = towns_egyptian_schem_path.."farm_tiny_2.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_tiny_3", mts = towns_egyptian_schem_path.."farm_tiny_3.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "default_town_hotel", mts = towns_egyptian_schem_path.."default_town_hotel.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "trader_clay_4", mts = towns_egyptian_schem_path.."trader_clay_4.mts", hsize = 20, max_num = 0.050, rplc = "n"},

  
  {name = "mgs_castle_new_01_35w_27l_15h_0_180", mts = towns_egyptian_schem_path.."mgs_castle_new_01_35w_27l_15h_0_180.mts", hsize = 38, max_num = 0.050, rplc = "n"},
  {name = "mgs_castle_new_02_35w_25l_15h_0_0", mts = towns_egyptian_schem_path.."mgs_castle_new_02_35w_25l_15h_0_0.mts", hsize = 38, max_num = 0.050, rplc = "n"},
  {name = "towntest_Nanuk_lavabeacon_0_180", mts = towns_egyptian_schem_path.."towntest_Nanuk_lavabeacon_0_180.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_full_1", mts = towns_egyptian_schem_path.."farm_full_1.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "well2", mts = towns_egyptian_schem_path.."well2.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "church_1", mts = towns_egyptian_schem_path.."church_1.mts", hsize = 25, max_num = 0.050, rplc = "n"},
  {name = "default_town_park", mts = towns_egyptian_schem_path.."default_town_park.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "baking_house_4", mts = towns_egyptian_schem_path.."baking_house_4.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "forge_1_0", mts = towns_egyptian_schem_path.."forge_1_0.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "mgs_bldg_fortress_01_0_0", mts = towns_egyptian_schem_path.."mgs_bldg_fortress_01_0_0.mts", hsize = 35, max_num = 0.050, rplc = "n"},
  {name = "mill_1", mts = towns_egyptian_schem_path.."mill_1.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "towntest_cornernote_tower_1_90", mts = towns_egyptian_schem_path.."towntest_cornernote_tower_1_90.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "taverne_2", mts = towns_egyptian_schem_path.."taverne_2.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "field_2", mts = towns_egyptian_schem_path.."field_2.mts", hsize = 30, max_num = 0.050, rplc = "n"},
  {name = "towntest_cornernote_turret_1_270", mts = towns_egyptian_schem_path.."towntest_cornernote_turret_1_270.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  
--]]
--
towns_egyptian_schematic_table = { 
  {name = "mgs_fountain_anubis_new_01_9w_7l_5h_0_90", mts = towns_egyptian_schem_path.."mgs_fountain_anubis_new_01_9w_7l_5h_0_90.mts", hsize = 10, max_num = 0.0, rplc = "n"},
  {name = "mgs_statue_anubis_01_11w_5l_17h_0_270", mts = towns_egyptian_schem_path.."mgs_statue_anubis_01_11w_5l_17h_0_270.mts", hsize = 15, max_num = 0.040, rplc = "n"},
  {name = "sandcity_meeting_small_1_1_270", mts = towns_egyptian_schem_path.."sandcity_meeting_small_1_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_tower_1_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_tower_1_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_small_1_1_270", mts = towns_egyptian_schem_path.."sandcity_small_1_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "mgs_temple_large_02_21w_19l_32h_0_180", mts = towns_egyptian_schem_path.."mgs_temple_large_02_21w_19l_32h_0_180.mts", hsize = 22, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_mixed_1_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_mixed_1_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_tower_2_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_tower_2_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_small_2_1_270", mts = towns_egyptian_schem_path.."sandcity_small_2_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "mgs_sand_house_01_11w_9l_8h_1_0", mts = towns_egyptian_schem_path.."mgs_sand_house_01_11w_9l_8h_1_0.mts", hsize = 14, max_num = 0.050, rplc = "n"},
  {name = "sandcity_tiny_1_1_270", mts = towns_egyptian_schem_path.."sandcity_tiny_1_1_270.mts", hsize = 6, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_small_2_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_small_2_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_tower_3_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_tower_3_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_small_3_1_270", mts = towns_egyptian_schem_path.."sandcity_small_3_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_tiny_3_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_tiny_3_1_270.mts", hsize = 6, max_num = 0.050, rplc = "n"},
  {name = "sandcity_small_4_1_270", mts = towns_egyptian_schem_path.."sandcity_small_4_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_tower_4_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_tower_4_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_tiny_2_1_270", mts = towns_egyptian_schem_path.."sandcity_tiny_2_1_270.mts", hsize = 6, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_mixed_2_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_mixed_2_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_small_3_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_small_3_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_tiny_3b_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_tiny_3b_1_270.mts", hsize = 6, max_num = 0.050, rplc = "n"},
  {name = "sandcity_small_5_1_270", mts = towns_egyptian_schem_path.."sandcity_small_5_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_tower_5_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_tower_5_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_tiny_3_1_270", mts = towns_egyptian_schem_path.."sandcity_tiny_3_1_270.mts", hsize = 6, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_tower_6_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_tower_6_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "sandcity_tiny_4_1_270", mts = towns_egyptian_schem_path.."sandcity_tiny_4_1_270.mts", hsize = 6, max_num = 0.050, rplc = "n"},
  {name = "sandcity_ap_tower_7_1_270", mts = towns_egyptian_schem_path.."sandcity_ap_tower_7_1_270.mts", hsize = 10, max_num = 0.050, rplc = "n"},
}
--
-- baseplate material, to replace dirt with grass and where buildings can be built
--
towns_egyptian_surface_mat = {
	"lib_materials:stone_desert_gravel",
	"lib_materials:stone_sandstone_white_gravel",
	"lib_materials:stone_sandstone_desert_gravel",
}
--
-- temporary info for currentliy built settlement (position of each building) 
--
towns_egyptian_settlement_info = {}
--
-- list of towns_egyptian, load on server start up
--
towns_egyptian_settled_areas_in_world = {}
--
-- min_distance between towns_egyptian
--
min_dist_towns_egyptian = 1000
if towns_egyptian.debug == true 
then
  min_dist_towns_egyptian = 200
end
--
-- maximum allowed difference in height for building a sttlement
--
towns_egyptian_max_height_difference = 6
--
--
--
towns_egyptian_half_map_chunk_size = 40
towns_egyptian_quarter_map_chunk_size = 20
