# Font OldWizard for Minetest Font API mod

This mod adds OldWizard font to Font API mod (from [display_modpack](https://github.com/pyrollo/display_modpack)).

For more information, see the [forum topic](https://forum.minetest.net/viewtopic.php?t=13563) at the Minetest forums.

![Font OldWizard Preview](screenshot.png)

**Dependancies**: font_api

**License**: code under LGPL v2.1, font in Public Domain

## Original Font

**Original font**: [OldWizard by Angel](http://www.pentacom.jp/pentacom/bitfontmaker2/gallery/?id=168)

**License**: Public Domain

