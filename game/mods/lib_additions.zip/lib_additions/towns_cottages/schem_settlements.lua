

--Air, Lava, and Water constants used throughout schematics
		local __ = {name = "air", param2 = 0, prob = 0}
		local wt = {name = "default:river_water_source", param2 = 0, prob = 254}
		local lv = {name = "default:lava_source", param2 = 0, prob = 254}
		local lf = {name = "default:lava_flowing", param2 = 0, prob = 254}
		
--Node Definitions
		local M0 = {name = "lib_materials:stone", param2 = 0, prob = 254}
		local M1 = {name = "lib_materials:stone_cobble", param2 = 0, prob = 254}
		local M2 = {name = "lib_materials:stone_brick", param2 = 0, prob = 254}
		local M3 = {name = "lib_materials:stone_block", param2 = 0, prob = 254}
		local M4 = {name = "", param2 = 0, prob = 254}
		local M5 = {name = "", param2 = 0, prob = 254}
		local M6 = {name = "", param2 = 0, prob = 254}
		local M7 = {name = "", param2 = 0, prob = 254}
		local M8 = {name = "", param2 = 0, prob = 254}
		local M9 = {name = "", param2 = 0, prob = 254}
		local MX = {name = "", param2 = 4, prob = 254}
		local MZ = {name = "", param2 = 8, prob = 254}

		local N0 = {name = "lib_materials:stone_sand", param2 = 0, prob = 254}
		local N1 = {name = "lib_materials:sand", param2 = 0, prob = 254}
		local N2 = {name = "lib_materials:stone_gravel", param2 = 0, prob = 254}
		local N3 = {name = "lib_materials:stone_cobble_mossy", param2 = 0, prob = 254}
		local N5 = {name = "", param2 = 0, prob = 254}
		local N6 = {name = "", param2 = 0, prob = 254}
		local N7 = {name = "", param2 = 0, prob = 254}
		local N8 = {name = "", param2 = 0, prob = 254}
		local N9 = {name = "default:wood", param2 = 0, prob = 254}
		local NY = {name = "default:tree", param2 = 0, prob = 254}
		local NZ = {name = "default:tree", param2 = 4, prob = 254}
		local NX = {name = "default:tree", param2 = 8, prob = 254}

		local S0 = {name = "stairs:stair_stonebrick", param2 = 0, prob = 254}
		local S1 = {name = "stairs:stair_stonebrick", param2 = 1, prob = 254}
		local S2 = {name = "stairs:stair_stonebrick", param2 = 2, prob = 254}
		local S3 = {name = "stairs:stair_stonebrick", param2 = 3, prob = 254}
		local S4 = {name = "stairs:stair_stonebrick", param2 = 20, prob = 254}
		local S6 = {name = "stairs:stair_stonebrick", param2 = 21, prob = 254}
		local S7 = {name = "stairs:stair_stonebrick", param2 = 22, prob = 254}
		local S8 = {name = "stairs:stair_stonebrick", param2 = 23, prob = 254}
		local SN = {name = "stairs:stair_stonebrick", param2 = 4, prob = 254}
		local SE = {name = "stairs:stair_stonebrick", param2 = 5, prob = 254}
		local SW = {name = "stairs:stair_stonebrick", param2 = 6, prob = 254}
		local SS = {name = "stairs:stair_stonebrick", param2 = 7, prob = 254}
		
		local Q0 = {name = "stairs:slab_wood", param2 = 0, prob = 254}
		local Q1 = {name = "stairs:slab_wood", param2 = 1, prob = 254}
		local Q2 = {name = "stairs:slab_wood", param2 = 2, prob = 254}
		local Q3 = {name = "stairs:slab_wood", param2 = 3, prob = 254}
		local Q5 = {name = "stairs:slab_wood", param2 = 20, prob = 254}
		local Q6 = {name = "stairs:slab_wood", param2 = 21, prob = 254}
		local Q7 = {name = "stairs:slab_wood", param2 = 22, prob = 254}
		local Q8 = {name = "stairs:slab_wood", param2 = 23, prob = 254}
		local QN = {name = "stairs:slab_wood", param2 = 4, prob = 254}
		local QE = {name = "stairs:slab_wood", param2 = 8, prob = 254}
		local QW = {name = "stairs:slab_wood", param2 = 12, prob = 254}
		local QS = {name = "stairs:slab_wood", param2 = 16, prob = 254}
		
		local O0 = {name = "stairs:stair_outer_stone", param2 = 0, prob = 254}
		local O1 = {name = "stairs:stair_outer_stone", param2 = 1, prob = 254}

		local JW = {name = "default:junglewood", param2 = 0, prob = 254}
		local PW = {name = "default:pine_wood", param2 = 0, prob = 254}
		

		local DD = {name = "default:dirt", param2 = 0, prob = 254}
		local GR = {name = "default:dirt_with_grass", param2 = 0, prob = 254}
		local G1 = {name = "default:glass", param2 = 0, prob = 254}

		local F0 = {name = "default:furnace", param2 = 0, prob = 254}
		local F1 = {name = "default:furnace", param2 = 1, prob = 254}
		local F2 = {name = "default:furnace", param2 = 2, prob = 254}
		local F3 = {name = "default:furnace", param2 = 3, prob = 254}

		local C0 = {name = "default:chest", param2 = 0, prob = 254}
		local C1 = {name = "default:chest", param2 = 1, prob = 254}
		local C2 = {name = "default:chest", param2 = 2, prob = 254}
		local C3 = {name = "default:chest", param2 = 3, prob = 254}

		local L0 = {name = "default:ladder_wood", param2 = 0, prob = 254}
		local L1 = {name = "default:ladder_wood", param2 = 1, prob = 254}
		local L2 = {name = "default:ladder_wood", param2 = 2, prob = 254}
		local L3 = {name = "default:ladder_wood", param2 = 3, prob = 254}
		local L4 = {name = "default:ladder_wood", param2 = 4, prob = 254}
		local L5 = {name = "default:ladder_wood", param2 = 5, prob = 254}

		local DR = {name = "lib_doors:tree_default_wood_door_centered_300_height_150_width_right", param2 = 1, prob = 254}
		local DL = {name = "lib_doors:tree_default_wood_door_centered_300_height_150_width", param2 = 1, prob = 254}
		local D0 = {name = "lib_doors:tree_default_wood_door_centered_with_window", param2 = 0, prob = 254}
		local D1 = {name = "lib_doors:tree_default_wood_door_centered_with_window", param2 = 1, prob = 254}
		local D2 = {name = "lib_doors:tree_default_wood_door_centered_with_window", param2 = 2, prob = 254}
		local D3 = {name = "lib_doors:tree_default_wood_door_centered_with_window", param2 = 3, prob = 254}
		local D5 = {name = "doors:trapdoor", param2 = 0, prob = 254}
		local D6 = {name = "doors:trapdoor", param2 = 1, prob = 254}
		local D7 = {name = "doors:trapdoor", param2 = 2, prob = 254}
		local D8 = {name = "doors:trapdoor", param2 = 3, prob = 254}

		local TC = {name = "default:torch_ceiling", param2 = 0, prob = 254}
		local TT = {name = "default:torch", param2 = 1, prob = 254}
		local T1 = {name = "default:torch_wall", param2 = 1, prob = 254}
		local T2 = {name = "default:torch_wall", param2 = 2, prob = 254}
		local T3 = {name = "default:torch_wall", param2 = 3, prob = 254}
		local T4 = {name = "default:torch_wall", param2 = 4, prob = 254}
		local T5 = {name = "default:torch_wall", param2 = 5, prob = 254}

		local A0 = {name = "lib_tools:anvil", param2 = 0, prob = 254}
		local A1 = {name = "lib_tools:anvil", param2 = 1, prob = 254}
		local A2 = {name = "lib_tools:anvil", param2 = 2, prob = 254}
		local A3 = {name = "lib_tools:anvil", param2 = 3, prob = 254}

		local B0 = {name = "beds:bed_bottom", param2 = 0, prob = 254}
		local B1 = {name = "beds:bed_bottom", param2 = 1, prob = 254}
		local B2 = {name = "beds:bed_bottom", param2 = 2, prob = 254}
		local B3 = {name = "beds:bed_bottom", param2 = 3, prob = 254}
		local B5 = {name = "beds:bed_top", param2 = 0, prob = 254}
		local B6 = {name = "beds:bed_top", param2 = 1, prob = 254}
		local B7 = {name = "beds:bed_top", param2 = 2, prob = 254}
		local B8 = {name = "beds:bed_top", param2 = 3, prob = 254}

		local RB = {name = "lib_tools:ropebox", param2 = 3, prob = 254}
		local RP = {name = "lib_tools:box_rope", param2 = 0, prob = 254}

		local R1 = {name = "cottages:roof_wood", param2 = 1, prob = 254}
		local R3 = {name = "cottages:roof_wood", param2 = 3, prob = 254}
		local R5 = {name = "cottages:roof_connector_wood", param2 = 1, prob = 254}
		local R7 = {name = "cottages:roof_connector_wood", param2 = 3, prob = 254}

		local X0 = {name = "xpanes:bar_flat", param2 = 0, prob = 254}
		local X1 = {name = "xpanes:bar_flat", param2 = 1, prob = 254}
		local X2 = {name = "xpanes:bar_flat", param2 = 2, prob = 254}
		local X3 = {name = "xpanes:bar_flat", param2 = 3, prob = 254}

		local Z1 = {name = "lib_tools:cauldron_empty", param2 = 0, prob = 254}
		local Z2 = {name = "lib_furniture:table_special_01_wood_stone", param2 = 0, prob = 254}
		local Z3 = {name = "default:steelblock", param2 = 0, prob = 254}
		local Z4 = {name = "xpanes:bar_flat", param2 = 1, prob = 254}
		local Z5 = {name = "mg_villages:mob_workplace_marker", param2 = 0, prob = 254}
		local Z6 = {name = "cottages:shelf", param2 = 1, prob = 254}
		local Z7 = {name = "cottages:shelf", param2 = 3, prob = 254}
		local Z8 = {name = "cottages:table", param2 = 2, prob = 254}

		local II = {name = "default:fence_wood",param2 = 0,prob = 254}




		towns_imperial.schem_bldg_settlements_blacksmith_x7_y7_z7_r000 = {
			size = {x = 7,y = 7,z = 7},
			data = {
				__, __, __, __, __, __, __, __, __,
				{param2 = 0,name = "stairs:stair_stone_block",prob = 254},
				{param2 = 0,name = "stairs:stair_stone_block",prob = 254},
				{param2 = 0,name = "stairs:stair_stone_block",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, DD, __, DD, DD, DD, __, __, M2, M2, M2, M2, M2, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __,
				{param2 = 3,name = "stairs:slab_cobble",prob = 254},
				{param2 = 3,name = "stairs:slab_cobble",prob = 254},
				{param2 = 3,name = "stairs:slab_cobble",prob = 254},
				{param2 = 3,name = "stairs:slab_cobble",prob = 254},
				{param2 = 3,name = "stairs:slab_cobble",prob = 254}, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, __, __, M2, M2, M2, M2, M2, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				{param2 = 3,name = "stairs:slab_cobble",prob = 254},
				{param2 = 3,name = "stairs:slab_cobble",prob = 254},
				{param2 = 3,name = "stairs:slab_cobble",prob = 254},
				{param2 = 3,name = "stairs:slab_cobble",prob = 254},
				{param2 = 3,name = "stairs:slab_cobble",prob = 254}, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, __, __, M2, M2, M2, M2, M2, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254}, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __,
				{param2 = 1,name = "xpanes:bar_flat",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __,
				{param2 = 21,name = "stairs:slab_cobble",prob = 254},
				{param2 = 21,name = "stairs:slab_cobble",prob = 254},
				{param2 = 21,name = "stairs:slab_cobble",prob = 254},
				{param2 = 21,name = "stairs:slab_cobble",prob = 254},
				{param2 = 21,name = "stairs:slab_cobble",prob = 254}, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, __, __, M2, M2, M2, M2, M2, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, lv,
				{param2 = 0,name = "walls:cobble",prob = 254}, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __,
				{param2 = 3,name = "xpanes:bar_flat",prob = 254}, __,
				{param2 = 1,name = "xpanes:bar_flat",prob = 254}, __, __, __, __, __, __, __, __, __, __, __,
				{param2 = 21,name = "stairs:slab_cobble",prob = 254},
				{param2 = 21,name = "stairs:slab_cobble",prob = 254},
				{param2 = 21,name = "stairs:slab_cobble",prob = 254},
				{param2 = 21,name = "stairs:slab_cobble",prob = 254},
				{param2 = 21,name = "stairs:slab_cobble",prob = 254}, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, __, __, M2, M2, M2, M2, M2, __, __, M1, M1, M1, F0, M1, __, __, M1, M1, M1, M1, M1, __, __, M1, M1, M1, M1, M1, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __,
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254},
				{ypos = 3,prob = 254},
				{ypos = 4,prob = 254},
				{ypos = 5,prob = 254},
				{ypos = 6,prob = 254}
			}
		}



		towns_imperial.schem_bldg_settlements_church_x7_y13_z10_r000 = {
			size = {x = 7,y = 13,z = 10},
			data = {
				__, __, __, __, __, __, __, __, __, __,
				{param2 = 0,name = "stairs:stair_cobble",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, S1, __, __, __, __, __, S3, __, S1, __, __, __, S3, __, __, __, S1,
				{param2 = 20,name = "stairs:slab_wood",prob = 254}, S3, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, __, __, M3, M1, JW, M1, M3, __, __, M3, M1, D2, M1, M3, __, __, M3, M1, __, M1, M3, __, __, M3, M1, M1, M1, M3, __, S1, M3, M1, G1, M1, M3, S3, __, S1, M1, M1, M1, S3, __, __, __, S1, M1, S3, __, __, __, __, __,
				{param2 = 0,name = "stairs:slab_wood",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, __, __, M1, JW, JW, JW, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, S1, __, __, __, __, __, S3, __, S1, __, __, __, S3, __, __, __, S1, __, S3, __, __, __, __, __,
				{param2 = 0,name = "stairs:slab_wood",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, __, __, M1, JW, JW, JW, M1, __, __, M1, S2, __, S2, M1, __, __, G1, __, __, __, G1, __, __, M1, __, __, __, M1, __, S1, __, __, __, __, __, S3, __, S1, __, __, __, S3, __, __, __, S1, __, S3, __, __, __, __, __,
				{param2 = 0,name = "stairs:slab_wood",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, __, __, M1, JW, JW, JW, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, S1, __, __, __, __, __, S3, __, S1, __, __, __, S3, __, __, __, S1, __, S3, __, __, __, __, __,
				{param2 = 1,name = "stairs:slab_wood",prob = 254}, __, __, __, __, __, __, __, __, __, __,
				{param2 = 1,name = "stairs:stair_outer_wood",prob = 254}, S0, S0, S0, S0, S0,
				{param2 = 0,name = "stairs:stair_outer_wood",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, __, __, M1, JW, JW, JW, M1, __, __, M1, S2, __, S2, M1, __, __, G1, __, __, __, G1, __, __, M1, __, __, __, M1, __, __, M3,
				{param2 = 21,name = "stairs:stair_cobble",prob = 254}, __,
				{param2 = 23,name = "stairs:stair_cobble",prob = 254}, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __, S1, M1, M1, M1, M1, M1, S3, __,
				{param2 = 1,name = "stairs:stair_outer_wood",prob = 254}, S0, S0, S0,
				{param2 = 0,name = "stairs:stair_outer_wood",prob = 254}, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, __, __, M1, JW, JW, JW, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, S1, M1, __, __, __, M1, S3, __, S1, __, __, __, S3, __, __, __, S0, S0, S0, __, __, __, DD, DD, DD, DD, DD, __, __, M1, JW, JW, JW, M1, __, __, M1, __,
				{param2 = 0,name = "stairs:stair_obsidian",prob = 254}, __, M1, __, __, M1, __, __, __, M1, __, __, M1, T4, __, T4, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, S1, M1, __, __, __, M1, S3, __, S1, __, __, __, S3, __, __, __, S2, S2, S2, __, __, __, DD, DD, DD, DD, DD, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, G1, M1, M3, __, __, M3, G1, G1, G1, M3, __, __, M3, M1, G1, M1, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __, S1, M1, M1, M1, M1, M1, S3, __,
				{param2 = 2,name = "stairs:stair_outer_wood",prob = 254}, S2, S2, S2,
				{param2 = 3,name = "stairs:stair_outer_wood",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				{param2 = 2,name = "stairs:stair_outer_wood",prob = 254}, S2, S2, S2, S2, S2,
				{param2 = 3,name = "stairs:stair_outer_wood",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254},
				{ypos = 3,prob = 254},
				{ypos = 4,prob = 254},
				{ypos = 5,prob = 254},
				{ypos = 6,prob = 254},
				{ypos = 7,prob = 254},
				{ypos = 8,prob = 254},
				{ypos = 9,prob = 254},
				{ypos = 10,prob = 254},
				{ypos = 11,prob = 254},
				{ypos = 12,prob = 254}
			}
		}



		towns_imperial.schem_bldg_settlements_garden_x7_y3_z7_r000 = {
			size = {x = 7,y = 3,z = 7},
			data = {
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, DD, DD, NY, NY, NY, NY, NY, NY, NY, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, DD, DD, NY,
				{param2 = 0,name = "farming:soil_wet",prob = 254},
				{param2 = 0,name = "farming:soil_wet",prob = 254},
				{param2 = 0,name = "farming:soil_wet",prob = 254},
				{param2 = 0,name = "farming:soil_wet",prob = 254},
				{param2 = 0,name = "farming:soil_wet",prob = 254}, NY, __,
				{param2 = 3,name = "farming:wheat_3",prob = 254},
				{param2 = 3,name = "farming:wheat_2",prob = 254},
				{param2 = 3,name = "farming:wheat_3",prob = 254},
				{param2 = 3,name = "farming:wheat_2",prob = 254},
				{param2 = 3,name = "farming:wheat_3",prob = 254}, __, DD, DD, DD, DD, DD, DD, DD, NY,
				{param2 = 0,name = "farming:soil_wet",prob = 254},
				{param2 = 0,name = "farming:soil_wet",prob = 254},
				{param2 = 0,name = "default:water_source",prob = 254},
				{param2 = 0,name = "farming:soil_wet",prob = 254},
				{param2 = 0,name = "farming:soil_wet",prob = 254}, NY, __,
				{param2 = 3,name = "farming:wheat_2",prob = 254},
				{param2 = 3,name = "farming:wheat_3",prob = 254}, __,
				{param2 = 3,name = "farming:wheat_3",prob = 254},
				{param2 = 3,name = "farming:wheat_2",prob = 254}, __, DD, DD, DD, DD, DD, DD, DD, NY,
				{param2 = 0,name = "farming:soil_wet",prob = 254},
				{param2 = 0,name = "farming:soil_wet",prob = 254},
				{param2 = 0,name = "farming:soil_wet",prob = 254},
				{param2 = 0,name = "farming:soil_wet",prob = 254},
				{param2 = 0,name = "farming:soil_wet",prob = 254}, NY, __,
				{param2 = 3,name = "farming:wheat_1",prob = 254},
				{param2 = 3,name = "farming:wheat_2",prob = 254},
				{param2 = 3,name = "farming:wheat_3",prob = 254},
				{param2 = 3,name = "farming:wheat_2",prob = 254},
				{param2 = 3,name = "farming:wheat_1",prob = 254}, __, DD, DD, DD, DD, DD, DD, DD, NY, NY, NY, NY, NY, NY, NY, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254}
			}
		}



		towns_imperial.schem_bldg_settlements_lamp_x3_y7_z3_r000 = {
			size = {x = 3,y = 7,z = 3},
			data = {
				__, __, __, __,
				{param2 = 0,name = "stairs:stair_cobble",prob = 254}, __, __, __, __, __,
				{param2 = 20,name = "stairs:stair_cobble",prob = 254}, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __,
				{param2 = 0,name = "stairs:stair_cobble",prob = 254}, __, __, __, __, __, DD, __,
				{param2 = 1,name = "stairs:stair_cobble",prob = 254}, M1,
				{param2 = 3,name = "stairs:stair_cobble",prob = 254}, __, M1, __,
				{param2 = 23,name = "stairs:stair_cobble",prob = 254},
				{param2 = 0,name = "default:coalblock",prob = 254},
				{param2 = 21,name = "stairs:stair_cobble",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 0,name = "fire:permanent_flame",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 1,name = "stairs:stair_cobble",prob = 254}, __,
				{param2 = 3,name = "stairs:stair_cobble",prob = 254}, __,
				{param2 = 0,name = "stairs:slab_cobble",prob = 254}, __, __, __, __, __,
				{param2 = 2,name = "stairs:stair_cobble",prob = 254}, __, __, __, __, __,
				{param2 = 22,name = "stairs:stair_cobble",prob = 254}, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __,
				{param2 = 2,name = "stairs:stair_cobble",prob = 254}, __, __, __, __
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254},
				{ypos = 3,prob = 254},
				{ypos = 4,prob = 254},
				{ypos = 5,prob = 254},
				{ypos = 6,prob = 254}
			}
		}



		towns_imperial.schem_bldg_settlements_tower_x7_y10_z7_r000 = {
			size = {x = 7,y = 10,z = 7},
			data = {
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				{param2 = 20,name = "stairs:stair_outer_stone_block",prob = 254},
				{param2 = 20,name = "stairs:stair_stone_block",prob = 254},
				{param2 = 20,name = "stairs:stair_stone_block",prob = 254},
				{param2 = 20,name = "stairs:stair_stone_block",prob = 254},
				{param2 = 20,name = "stairs:stair_stone_block",prob = 254},
				{param2 = 20,name = "stairs:stair_stone_block",prob = 254},
				{param2 = 21,name = "stairs:stair_outer_stone_block",prob = 254}, M3, __, M3, __, M3, __, M3, __, DD, DD, DD, DD, DD, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M3, M3, M3, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __,
				{param2 = 23,name = "stairs:stair_stone_block",prob = 254}, __, __, __, __, __,
				{param2 = 21,name = "stairs:stair_stone_block",prob = 254}, __, __, __, __, __, __, __, __, DD, JW, JW, JW, DD, __, __, M1, __, L5, __, M1, __, __, M1, __, L5, __, M1, __, __, M1, T5, L5, T5, M1, __, __, M3, JW, L5, JW, M3, __, __, M1, __, L5, __, M1, __, __, M1, __, L5, __, M1, __, __, M1,
				{param2 = 20,name = "stairs:slab_stone_block",prob = 254}, L5,
				{param2 = 23,name = "stairs:slab_stone_block",prob = 254}, M1, __,
				{param2 = 23,name = "stairs:stair_stone_block",prob = 254}, __, __, __, __, __,
				{param2 = 21,name = "stairs:stair_stone_block",prob = 254}, M3, __, __, __, __, __, M3, __, DD, JW, JW, JW, DD, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M3, JW, JW, JW, M3, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1,
				{param2 = 20,name = "stairs:slab_stone_block",prob = 254},
				{param2 = 20,name = "stairs:slab_stone_block",prob = 254},
				{param2 = 20,name = "stairs:slab_stone_block",prob = 254}, M1, __,
				{param2 = 23,name = "stairs:stair_stone_block",prob = 254}, __, __, __, __, __,
				{param2 = 21,name = "stairs:stair_stone_block",prob = 254}, __, __, __, __, __, __, __, __, DD, JW, JW, JW, DD, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M1, __, __, __, M1, __, __, M3, JW, JW, JW, M3, __, __, M1, __, __, __, M1, __, __, M1, __, T4, __, M1, __, __, M1,
				{param2 = 20,name = "stairs:slab_stone_block",prob = 254},
				{param2 = 20,name = "stairs:slab_stone_block",prob = 254},
				{param2 = 20,name = "stairs:slab_stone_block",prob = 254}, M1, __,
				{param2 = 23,name = "stairs:stair_stone_block",prob = 254}, __, __, __, __, __,
				{param2 = 21,name = "stairs:stair_stone_block",prob = 254}, M3, __, __, __, __, __, M3, __, DD, DD, JW, DD, DD, __, __, M3, M1, D0, M1, M3, __, __, M3, M1, __, M1, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M3, M3, M3, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __, __, M3, M1, M1, M1, M3, __,
				{param2 = 23,name = "stairs:stair_stone_block",prob = 254}, __, __, __, __, __,
				{param2 = 21,name = "stairs:stair_stone_block",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				{param2 = 23,name = "stairs:stair_outer_stone_block",prob = 254},
				{param2 = 22,name = "stairs:stair_stone_block",prob = 254},
				{param2 = 22,name = "stairs:stair_stone_block",prob = 254},
				{param2 = 22,name = "stairs:stair_stone_block",prob = 254},
				{param2 = 22,name = "stairs:stair_stone_block",prob = 254},
				{param2 = 22,name = "stairs:stair_stone_block",prob = 254},
				{param2 = 22,name = "stairs:stair_outer_stone_block",prob = 254}, M3, __, M3, __, M3, __, M3
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254},
				{ypos = 3,prob = 254},
				{ypos = 4,prob = 254},
				{ypos = 5,prob = 254},
				{ypos = 6,prob = 254},
				{ypos = 7,prob = 254},
				{ypos = 8,prob = 254},
				{ypos = 9,prob = 254}
			}
		}



		towns_imperial.schem_bldg_settlements_townhall_x10_y12_z11_r000 = {
			size = {x = 10,y = 12,z = 11},
			data = {
				__, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __,
				S1, __, __, __, __, __, __, __, __, S3,
				__, S1, __, __, __, __, __, __, S3, __,
				__, __, S1, __, __, __, __, S3, __, __,
				__, __, __, S1, __, __, S3, __, __, __,
				__, __, __, __, S1, S3, __, __, __, __,

				__, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __,
				{param2 = 20,name = "stairs:stair_junglewood",prob = 254},
				{param2 = 20,name = "stairs:stair_junglewood",prob = 254},
				{param2 = 20,name = "stairs:stair_junglewood",prob = 254},
				{param2 = 20,name = "stairs:stair_junglewood",prob = 254},
				{param2 = 20,name = "stairs:stair_junglewood",prob = 254},
				{param2 = 20,name = "stairs:stair_junglewood",prob = 254}, __, __, __, NY, M1, M1, M1, M1, M1, M1, NY, __, __, NY, M1, M1, M1, M1, M1, M1, NY, __, S1, NX, NX, NX, NX, NX, NX, NX, NX, S3, __, S1, M1, M1, X0, X0, M1, M1, S3, __, __, __, S1, M1, M1, M1, M1, S3, __, __, __, __, __, S1, M1, M1, S3, __, __, __, __, __, __, __, S1, S3, __, __, __, __, __, __, DD, DD, DD, DD, DD, DD, __, __, __, __, NY, M1, M1, M1, M1, NY, __, __, __, __, NY, M1, X0, X0, M1, NY, __, __, __, __, NY, M1, M1, M1, M1, NY, __, __, __,
				{param2 = 23,name = "stairs:stair_junglewood",prob = 254}, M1,
				{param2 = 2,name = "stairs:stair_stone_block",prob = 254}, M1, M1, M1, M1,
				{param2 = 21,name = "stairs:stair_junglewood",prob = 254}, __, __, M1, __, __, __, __, __, __, M1, __, __, M1, __, __, __, __, __, __, M1, __, S1,
				{param2 = 3,name = "default:bookshelf",prob = 254}, __, __, T5, __, __, __,
				{param2 = 1,name = "default:bookshelf",prob = 254}, S3, __, S1, __, __, __, __, __, __, S3, __, __, __, S1, __, __, __, __, S3, __, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, __, S1, S3, __, __, __, __, __, __, DD, JW, JW, JW, JW, DD, __, __, __, __, M1, __, __, __, __, M1, __, __, __, __, M1, __, __, __, __, M1, __, __, __, __, M1,
				{param2 = 2,name = "stairs:stair_stone_block",prob = 254}, __, __, __, M1, __, __, __,
				{param2 = 23,name = "stairs:stair_junglewood",prob = 254}, M1, __, __, __, __, M1,
				{param2 = 21,name = "stairs:stair_junglewood",prob = 254}, __, __, M1, __, __, __, __, __, __, M1, __, __, M1, __, __, __, __, __, __, M1, __, S1,
				{param2 = 3,name = "default:bookshelf",prob = 254}, __, __, __, __, __, __,
				{param2 = 1,name = "default:bookshelf",prob = 254}, S3, __, S1, __, __, __, __, __, __, S3, __, __, __, S1, __, __, __, __, S3, __, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, __, S1, S3, __, __, __, __, __, __, DD, JW, JW, JW, JW, DD, __, __, __, __, M1, C3, __, __, __, M1, __, __, __, __, M1,
				{param2 = 2,name = "stairs:stair_stone_block",prob = 254}, __, __, __, M1, __, __, __, __, M1, __, __, __, __, M1, __, __, __,
				{param2 = 23,name = "stairs:stair_junglewood",prob = 254}, M1, __, __, __, __, M1,
				{param2 = 21,name = "stairs:stair_junglewood",prob = 254}, __, __, M1, __, __, __, __, __, __, M1, __, __, M1, __, __, __, __, __, __, M1, __, S1,
				{param2 = 3,name = "default:bookshelf",prob = 254}, __, __, __, T4, __, __,
				{param2 = 1,name = "default:bookshelf",prob = 254}, S3, __, S1, __, __, __, __, __, __, S3, __, __, __, S1, __, __, __, __, S3, __, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, __, S1, S3, __, __, __, __, __, __, DD, JW, JW, JW, JW, JW, __, __, __, __, M1,
				{param2 = 2,name = "stairs:stair_stone_block",prob = 254}, __, __, __, D1, __, __, __, __, X3, __, __, __, __, __, __, __, __, __, M1, __, __, __, __, M1, __, __, __,
				{param2 = 23,name = "stairs:stair_junglewood",prob = 254}, M1, __, __, __, __, M1,
				{param2 = 21,name = "stairs:stair_junglewood",prob = 254}, __, __, M1, __, __, __, __, __, __, M1, __, __, M1, __, __, __, __, __, __, M1, __, S1, NX, NX, NX, NX, NX, NX, NZ, NZ, S3, __, S1, __, __, __, __, __, __, S3, __, __, __, S1, __, __, __, __, S3, __, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, __, S1, S3, __, __, __, __, __, __, DD, JW, JW, JW, JW, DD, __, __, __, __, M1, __, __, __, __, M1, __, __, __, __, M1, __, __, __, __, M1, __, __, __, __, M1, __, __, __, __, M1, __, __, __,
				{param2 = 23,name = "stairs:stair_junglewood",prob = 254}, M1, __, __, __, __, M1,
				{param2 = 21,name = "stairs:stair_junglewood",prob = 254}, __, __, M1, __, __, __, __, __, __, M1, __, __, M1, __, __, __, __, __, __, M1, __, S1,
				{param2 = 3,name = "default:bookshelf",prob = 254}, __, __, T5, __, __, __,
				{param2 = 1,name = "default:bookshelf",prob = 254}, S3, __, S1, __, __, __, __, __, __, S3, __, __, __, S1, __, __, __, __, S3, __, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, __, S1, S3, __, __, __, __, __, __, DD, JW, JW, JW, JW, DD, __, __, __, __, M1,
				{param2 = 3,name = "stairs:stair_junglewood",prob = 254}, II, II,
				{param2 = 1,name = "stairs:stair_junglewood",prob = 254}, M1, __, __, __, __, M1, __, D5, D5, __, M1, __, __, __, __, M1, __, __, __, __, M1, __, __, __,
				{param2 = 23,name = "stairs:stair_junglewood",prob = 254}, M1, __, __, __, __, M1,
				{param2 = 21,name = "stairs:stair_junglewood",prob = 254}, __, __, M1, __, __, __, __, __, __, M1, __, __, M1, __, __, __, __, __, __, M1, __, S1,
				{param2 = 3,name = "default:bookshelf",prob = 254}, __, __, __, __, __, __,
				{param2 = 1,name = "default:bookshelf",prob = 254}, S3, __, S1, __, __, __, __, __, __, S3, __, __, __, S1, __, __, __, __, S3, __, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, __, S1, S3, __, __, __, __, __, __, DD, DD, DD, DD, DD, DD, __, __, __, __, NY, M1, M1, M1, M1, NY, __, __, __, __, NY, M1, X0, X0, M1, NY, __, __, __, __, NY, M1, M1, M1, M1, NY, __, __, __,
				{param2 = 23,name = "stairs:stair_junglewood",prob = 254}, M1, M1, M1, M1, M1, M1,
				{param2 = 21,name = "stairs:stair_junglewood",prob = 254}, __, __, M1, __, __, __, __, __, __, M1, __, __, M1, __, __, __, __, __, __, M1, __, S1,
				{param2 = 3,name = "default:bookshelf",prob = 254}, __, __, __, T4, __, __,
				{param2 = 1,name = "default:bookshelf",prob = 254}, S3, __, S1, __, __, __, __, __, __, S3, __, __, __, S1, __, __, __, __, S3, __, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, __, S1, S3, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				{param2 = 22,name = "stairs:stair_junglewood",prob = 254},
				{param2 = 22,name = "stairs:stair_junglewood",prob = 254},
				{param2 = 22,name = "stairs:stair_junglewood",prob = 254},
				{param2 = 22,name = "stairs:stair_junglewood",prob = 254},
				{param2 = 22,name = "stairs:stair_junglewood",prob = 254},
				{param2 = 22,name = "stairs:stair_junglewood",prob = 254}, __, __, __, NY, M1, M1, M1, M1, M1, M1, NY, __, __, NY, M1, M1, M1, M1, M1, M1, NY, __, S1, NZ, NX, NX, NX, NX, NX, NX, NX, S3, __, S1, M1, M1, X0, X0, M1, M1, S3, __, __, __, S1, M1, M1, M1, M1, S3, __, __, __, __, __, S1, M1, M1, S3, __, __, __, __, __, __, __, S1, S3, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, S1, __, __, __, __, __, __, __, __, S3, __, S1, __, __, __, __, __, __, S3, __, __, __, S1, __, __, __, __, S3, __, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, __, S1, S3, __, __, __, __
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254},
				{ypos = 3,prob = 254},
				{ypos = 4,prob = 254},
				{ypos = 5,prob = 254},
				{ypos = 6,prob = 254},
				{ypos = 7,prob = 254},
				{ypos = 8,prob = 254},
				{ypos = 9,prob = 254},
				{ypos = 10,prob = 254},
				{ypos = 11,prob = 254}
			}
		}



		towns_imperial.schem_bldg_settlements_well_x5_y5_z5_r000 = {
			size = {x = 5,y = 5,z = 5},
			data = {
				DD, DD, DD, DD, DD, M1,
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254}, M1,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254}, DD, DD, DD, DD, DD,
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 0,name = "default:water_source",prob = 254},
				{param2 = 240,name = "default:water_source",prob = 254},
				{param2 = 0,name = "default:water_source",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __, __, __, __, __, __, __, __,
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254}, DD, DD, DD, DD, DD,
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 240,name = "default:water_source",prob = 254},
				{param2 = 240,name = "default:water_source",prob = 254},
				{param2 = 240,name = "default:water_source",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __, __, __, __, __, __, __, __,
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254}, DD, DD, DD, DD, DD,
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 0,name = "default:water_source",prob = 254},
				{param2 = 240,name = "default:water_source",prob = 254},
				{param2 = 0,name = "default:water_source",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __, __, __, __, __, __, __, __,
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254}, __, __, __, __, DD, M1,
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254}, M1,
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 0,name = "walls:cobble",prob = 254}, __, __, __,
				{param2 = 0,name = "walls:cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254},
				{param2 = 1,name = "stairs:slab_cobble",prob = 254}
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254},
				{ypos = 3,prob = 254},
				{ypos = 4,prob = 254}
			}
		}







