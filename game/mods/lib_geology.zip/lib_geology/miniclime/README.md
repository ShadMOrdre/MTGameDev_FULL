## Author of media files
inchadney (http://freesound.org/people/inchadney/):

  * `rain_drop.ogg` - CC-BY-SA 3.0 (cut from http://freesound.org/people/inchadney/sounds/58835/)

rcproductions54 (http://freesound.org/people/rcproductions54/):

  * `light_rain_drop.ogg` - CC-0 (http://freesound.org/people/rcproductions54/sounds/265045/)

uberhuberman

  * `heavy_rain_drop.ogg` - CC BY 3.0 (https://www.freesound.org/people/uberhuberman/sounds/21189/)
  
InspectorJ
  * `wind.ogg` - CC BY 3.0 (https://freesound.org/people/InspectorJ/sounds/376415/)
  -- originaly a .wav file, it was converted
azekill_DIABLO

  * `miniclime_dust.png` - CC-BY-SA 3.0
  * `miniclime_rain.png` - CC-BY-SA 3.0
  * `miniclime_fog.png` - CC-BY-SA 3.0
  * `miniclime_snow.png` - CC-BY-SA 3.0