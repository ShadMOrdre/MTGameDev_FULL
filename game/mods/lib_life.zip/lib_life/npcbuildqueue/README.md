# NPC Build Queues
Instructs your NPCs to build schematics. Requires [Mobs Redo](https://notabug.org/tenplus1/mobs_redo) by Tenplus1.

The API is documented in `init.lua` and `metafile.lua`.

See the [demonstration video](https://www.youtube.com/watch?v=14YCZ0aA68I).
