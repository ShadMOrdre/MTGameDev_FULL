mob_mummy = {}

dofile(minetest.get_modpath("mob_mummy").."/mummy.lua")

local function add_spawner(pos)
	minetest.set_node(pos, {name="mob_mummy:spawner_mummy"})
	if not minetest.setting_getbool("only_peaceful_mobs") then mob_mummy.spawn_mummy({x=pos.x,y=pos.y,z=pos.z-2},2) end
end


