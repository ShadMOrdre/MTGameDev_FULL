Minetest mod "Pyramids"
=======================
version: 0.4.2 Beta

License of source code and textures: WTFPL
------------------------------------------
(c) Copyright BlockMen (2013 - 2015)


License of mesh model: WTFPL
----------------------------
(c) Copyright Pavel_S (2013)


License of textures
-------------------
-pyramids_eye.png by bas080, CC-BY-SA 3.0
-pyramids_men.png by bas080, CC-BY-SA 3.0
-pyramids_sun.png by bas080, CC-BY-SA 3.0

all other: BlockMen, WTFPL


Licenses of sounds
------------------
The authors are : (freesound.org)
-mummy.1.ogg by Raventhornn, CC0
-mummy.2.ogg by Raventhornn, CC0
-mummy_hurt.1.ogg by Under7dude, CC0
-mummy_death.1.ogg by Michel88, CC-Sampling Plus 1.0

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.


Using the mod:
--------------

This mod adds randomly spawned pyramids in deserts. The pyramids are very rare and contain a chest with stuff.
Also there are mummys inside, which attack the player if found in their radius.
