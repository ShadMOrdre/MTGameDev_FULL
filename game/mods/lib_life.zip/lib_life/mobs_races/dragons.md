D00Med's Mobs

How to Dragon

By defeating dragons you will get eggs. Place them in their ideal environment and feed them a gem to create an elemental egg.

By defeating special dragons, you can obtain elemental gems.

Feed the right elemental gem to the elemental egg to hatch a dragon.

Use the Use key to shoot fireballs when riding your new pet dragon.

ENjoy
