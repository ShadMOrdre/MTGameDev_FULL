--[[   DEFAULT Spawning parameters
	-- ANTS
	mobs:spawn_specific("mobs_nssm:ant_soldier", {"mobs_nssm:ant_dirt"}, {"air"}, 0, 14, 7, 1000, 3, 4, 200)
	mobs:spawn_specific("mobs_nssm:ant_worker", {"mobs_nssm:ant_dirt"}, {"air"}, 0, 14, 5, 1000, 6, 4, 200)

	-- SPIDERS
	mobs:spawn_specific("mobs_nssm:tarantula", {"mobs_nssm:web", }, {"air"}, 0, 14, 6, 1000, 1, 20, 30)
	mobs:spawn_specific("mobs_nssm:uloboros", {"mobs_nssm:web", }, {"air"}, 0, 14, 8, 1000, 1, 25, 35)

	-- SEA
	mobs:spawn_specific("mobs_nssm:crocodile", {"lib_materials:muddy_river_water_source",}, {"air"}, 0, 14, 100, 2000, 1, -2, 12)
	mobs:spawn_specific("mobs_nssm:octopus", {"default:water_source"}, {"default:water_source"}, 0, 14, 100, 2000, 1, -192, 0)
	mobs:register_spawn("mobs_nssm:crocodile", {"default:sand","default:water_source"}, 0, 20, 32000, 2, 31000, true)
	mobs:register_spawn("mobs_nssm:octopus", {"default:water_source"}, 0, 20, 32000, 2, 31000, true)

	-- DESERT
	mobs:spawn_specific("mobs_nssm:sandworm", {"default:desert_sand", "default:desert_stone"}, {"air"}, 0, 14, 100, 2000, 1, 15, 55)

	-- MOUNTAINS
	mobs:spawn_specific("mobs_nssm:werewolf", {"lib_materials:dirt_with_fungi_covered_grass"}, {"air"}, 0, 10, 100, 1000, 1, 20, 30)

	-- ICE
	mobs:spawn_specific("mobs_nssm:white_werewolf", {"default:dirt_with_snow","default:snow"}, {"air"}, 0, 10, 100, 1000, 1, 80, 110)

	-- SKY
	--mobs:spawn_specific("mobs_nssm:moonheron", {"air"}, {"air"}, 0, 8, 100, 160000, 2, 10, 40)
--]]

--mobs:spawn_specfic(name, nodes, neighbors, min_light, max_light, interval, chance, active_object_count, min_height, max_height, day_toggle)
--mobs:spawn_specfic(name, nodes, neighbors, min_light, max_light, interval, chance, active_object_count, min_height, max_height, day_toggle)


-- Spawning parameters

-- ANTS
	mobs:spawn_specific("mobs_nssm:ant_soldier", {"mobs_nssm:ant_dirt"}, {"air"}, 0, 20, 120, 128000, 2, -31000, 31000)
	mobs:spawn_specific("mobs_nssm:ant_worker", {"mobs_nssm:ant_dirt"}, {"air"}, 0, 20, 120, 128000, 4, -31000, 31000)

-- SPIDERS
	mobs:spawn_specific("mobs_nssm:tarantula", {"default:jungle_grass", "default:jungletree", "mobs_nssm:web" }, {"air"}, 0, 20, 120, 128000, 1, -31000, 31000)
	mobs:spawn_specific("mobs_nssm:uloboros", {"default:jungle_grass", "default:jungletree", "mobs_nssm:web" }, {"air"}, 0, 20, 120, 128000, 3, -31000, 31000)

-- SEA
	mobs:spawn_specific("mobs_nssm:crocodile", {"default:sand","default:water_source"}, {"air"}, 0, 14, 120, 128000, 2, -31000, 2)
	mobs:spawn_specific("mobs_nssm:octopus", {"default:water_source"}, {"default:water_source"}, 0, 14, 120, 128000, 1, -31000, 0)

-- DESERT
	mobs:spawn_specific("mobs_nssm:sandworm", {"default:desert_sand", "default:desert_stone"}, {"air"}, 8, 14, 120, 128000, 2, -31000, 31000)

-- MOUNTAINS
	mobs:spawn_specific("mobs_nssm:werewolf", {"default:dirt_with_grass"}, {"default:dirt_with_grass"}, 0, 10, 120, 128000, 1, 20, 31000)

-- ICE
	mobs:spawn_specific("mobs_nssm:white_werewolf", {"default:dirt_with_snow","default:snow"}, {"air"}, 0, 10, 120, 128000, 1, -31000, 31000)

-- SKY
	mobs:spawn_specific("mobs_nssm:moonheron", {"air"}, {"air"}, 0, 8, 120, 160000, 1, 10, 40)

