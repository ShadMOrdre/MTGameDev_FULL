Not so simple mobs by NPX team

We would like to thank:
 - PilzAdam, for his wonderful simple-mobs mod;
 - Tenplus1, for his hard work in making mobs_redo;
 - rnd, for his pathfinding;
 - Echoes91, for Spears: simple but amazing;
 - and obviously Celeron-55 and all the people who contributed to Minetest and its community;
 - Denise and Ponzi_Duro for the revision of the guide
 - Double P and Ponzi_Duro for the beta testing

License GPL v3

The mod makes the game really hard, please read the Guide before playing:
https://dl.orangedox.com/a9tDekhYmWRkJt0J0a

Note: this is a custom mob pack made from the original nssm mobs to work with
mobs redo api for a particular server.
