PMobs by CProgrammerRU

This mod uses the Mobs Redo Api to add new mobs to minetest.

2.5 - Added Npc, Guard, Archer, Ninja, Wolf, Dog and Yeti

Special thanks to TenPlus1.