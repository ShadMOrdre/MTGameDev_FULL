local MOD_NAME = core.get_current_modname()
local MOD_PATH = core.get_modpath(MOD_NAME)

dofile(MOD_PATH.."/api.lua")
