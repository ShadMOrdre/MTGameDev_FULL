Ancient Runes
=============

Ancient Runes adds the 24 runes of the Scandinavian runes alphabet (fuþark).
You can craft burins to gather Iron Dust and Mese Dust which can be crafted
to Rune Dust.You will only collect Iron and Mese Dust if you punch stone.
The propability of receiving a certain sort of dust is increased by certain
ore lodes.

License
=======

* The following files are Copyright 2018 Marius Spix and licensed under the
  SIL Open Font License 1.1. See OFL-1.1.txt for further information:
    * ancientrunes_overlay_algiz.png
    * ancientrunes_overlay_ansuz.png
    * ancientrunes_overlay_berkanan.png
    * ancientrunes_overlay_dagaz.png
    * ancientrunes_overlay_ehwaz.png
    * ancientrunes_overlay_fehu.png
    * ancientrunes_overlay_gyfu.png
    * ancientrunes_overlay_hagalaz.png
    * ancientrunes_overlay_ihwa.png
    * ancientrunes_overlay_isaz.png
    * ancientrunes_overlay_jera.png
    * ancientrunes_overlay_kaunan.png
    * ancientrunes_overlay_laguz.png
    * ancientrunes_overlay_mannaz.png
    * ancientrunes_overlay_naudiz.png
    * ancientrunes_overlay_othala.png
    * ancientrunes_overlay_peorth.png
    * ancientrunes_overlay_raido.png
    * ancientrunes_overlay_sowilo.png
    * ancientrunes_overlay_thurisaz.png
    * ancientrunes_overlay_tiwaz.png
    * ancientrunes_overlay_ur.png
    * ancientrunes_overlay_wynn.png
    * ancientrunes_overlay_yngvi.png
* Unless otherwise stated, all other files in the textures subdirectory are
  Copyright 2018 Marius Spix and licensed under the Creative Commons
  Attribution-ShareAlike 3.0 Unported License. See CC-by-SA-3.0.txt for
  further information:
    * ancientrunes_item_iron_powder.png
    * ancientrunes_item_mese_powder.png
    * ancientrunes_item_rune_powder.png
    * ancientrunes_particle_iron_powder.png
    * ancientrunes_particle_mese_powder.png
    * ancientrunes_tool_burin_bronze.png
    * ancientrunes_tool_burin_diamond.png
    * ancientrunes_tool_burin_mese.png
    * ancientrunes_tool_burin_mithril.png
    * ancientrunes_tool_burin_silver.png
    * ancientrunes_tool_burin_steel.png
    * ancientrunes_tool_burin_stone.png
    * ancientrunes_tool_burin_wood.png
* Unless otherwise stated, all other files are Copyright 2018 by Marius Spix
  <marius.spix@web.de> and licensed under the Apache License. See
  Apache-2.0.txt for further information.
