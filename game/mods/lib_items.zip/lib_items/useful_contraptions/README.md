# useful_contraptions
https://forum.minetest.net/viewtopic.php?f=11&t=16666&p=273260

minetest mod contaioning some useful machines
Self made and out of other mods.
