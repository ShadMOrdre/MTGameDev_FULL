###Banners mod for Minetest
This is the banner mod for minetest.
The source code is licensed under GPLv3, and the game assets are licensed under Creative Commons 0 (CC0, [https://wiki.creativecommons.org/wiki/CC0](see here)).

