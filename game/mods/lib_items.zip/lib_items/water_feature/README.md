Just adds a water feature node for decoration. More may be added at a later date.

https://forum.minetest.net/viewtopic.php?f=47&t=20211&hilit=water+feature
