--[[
	{ -- example entry:
		-- the filename of the schematic
		scm="npc_house_level_3_1_180",
		-- title, description and level will be used instead of the filename in order to describe the building for the player
		title="Small house",
		descr="Founding a family",
		-- filename of what this building can be upgraded to;
		-- the upgrade building ought to have...
		-- ...the same dimensions
		-- ...provide exactly the same as this building (see provide-entry)
		-- ...have a level of exactly 1 higher (the first building starts at level 0)
		upgrade_to="npc_house_level_4_1_180",
		-- what this building provides (=single string)
		provides="housing",
		-- ..and the level at which it is provided (note: start at level 0);
		-- buildings at level 0 can be placed and built directly; all others need to be achieved through upgrading
		level=3,
		-- each building may require what other buildings provide at a certain level; in order to be allowed to build this
		-- particular building, you need one building that provides "lumberjack" at level 1 (or higher), another one that
		-- provides "pub" at level 1 (or higher), another one which provides "mine" at level 1, a "church" at at least
		-- level 2, and so on;
		requires={ lumberjack = 1, pub = 1, mine = 1, church = 2, farm = 0, mill = 0},
		-- this house holds beds for 3 inhabitants and can house that many npc (not used yet)
		inh=3,
		-- 2 of the npc living in this house can work elsewhere (not used yet)
		worker=2,
		-- 1 of them is a child (not used yet)
		children=1,
		-- how many npc need to work here in order for the building to function? (not used yet)
		needs_worker=1,
		-- which job does the building provide? (not used yet)
		job="houseowner"
	},
--]]

local citybuilder_structures_village_medieval = {
	--LEVEL ZERO - THE BEGINNING
	-- very tiny wooden cabin
	{scm="farm_tiny_1_level_0_1_180", title="First House",    descr="Just arrived",             upgrade_to=nil,
		-- we need to get started somehow
		requires=nil,
		provides="housing", level=0, inh=2, worker=2, children=0, needs_worker=0},

	{scm="npc_lumberjack_level_0_1_0", title="Forrest",    descr="Tree farm",  upgrade_to=nil,
		-- we need to get started somehow
		requires=nil,
		provides="lumberjack", level=0, inh=0, worker=0, children=0, needs_worker=1, job="lumberjack"},

	{scm="well_8", title="Water Well",    descr="Well for water supply",  upgrade_to=nil,
		-- we need to get started somehow
		requires=nil,
		provides="well", level=0, inh=0, worker=0, children=0, needs_worker=0},

	{scm="wheat_field", title="Wheat Farm",    descr="Wheat, for making bread",  upgrade_to=nil,
		-- we need to get started somehow
		requires=nil,
		provides="farm", level=0, inh=0, worker=0, children=0, needs_worker=1, job="farmer"},




	--LEVEL ONE
	-- very tiny wooden cabin
	{scm="farm_tiny_2_level_0_1_180", title="Housing 1",    descr="Rooms to expand",             upgrade_to=nil,
		-- we need to get started somehow
		requires={ housing = 0},
		provides="housing", level=1, inh=2, worker=2, children=0, needs_worker=0},

	{scm="farm_tiny_3_level_0_1_180", title="Housing 2",    descr="Rooms to expand",             upgrade_to=nil,
		-- we need to get started somehow
		requires={ housing = 0},
		provides="housing", level=1, inh=2, worker=2, children=0, needs_worker=0},

	{scm="npc_lumbermill_level_0_1_0", title="Lumber Mill",    descr="Tree mill",  upgrade_to=nil,
		-- we need to get started somehow
		requires={ lumberjack = 0, well = 0},
		provides="lumbermill", level=1, inh=0, worker=0, children=0, needs_worker=1, job="miller"},

	{scm="cow_shed_1_270", title="Cow Shed",    descr="Even cows need a place for the night",  upgrade_to=nil,
		-- we need to get started somehow
		requires={ lumberjack = 0, well = 0},
		provides="ranch", level=1, inh=0, worker=0, children=0, needs_worker=1, job="rancher"},



	--LEVEL TWO
	{scm="mill_1", title="Grist Mill",    descr="Grist mill for milling wheat",  upgrade_to=nil,
		-- we need to get started somehow
		requires={ housing = 1, lumbermill = 1, farm = 0},
		provides="gristmill", level=2, inh=0, worker=0, children=0, needs_worker=1, job="gristmiller"},

	{scm="mgs_mine_new_02_13w_9l_31h_0_270", title="Mine",    descr="Mine / Quarry for extracting rock and ore",  upgrade_to=nil,
		-- we need to get started somehow
		requires={ housing = 1, lumbermill = 1},
		provides="mine", level=2, inh=0, worker=0, children=0, needs_worker=2, job="miner"},

	{scm="forge_1_0", title="Forge",    descr="Forge for a blacksmith",  upgrade_to=nil,
		-- we need to get started somehow
		requires={ housing = 1, lumbermill = 1},
		provides="forge", level=2, inh=0, worker=0, children=0, needs_worker=1, job="blacksmith"},




	};


local path = minetest.get_modpath( minetest.get_current_modname()).."/schems/";

for i,v in ipairs( citybuilder_structures_village_medieval ) do
        citybuilder.add_blueprint( path, v, "citybuilder_structures_village_medieval" );
end
