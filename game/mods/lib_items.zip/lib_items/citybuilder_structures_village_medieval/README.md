These are some structures for https://github.com/Sokomine/citybuilder/ which is a mod for Minetest.
