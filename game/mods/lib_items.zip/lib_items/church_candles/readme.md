=====================

#Minetest mod  "Candles" by darkrose

##Copyright (C) Lisa Milne 2013 <lisa@ltmnet.com>

modified for  the "Church Modpack" 

Licensed under GPL2.0 or later,

see http://www.gnu.org/licenses/gpl-2.0.html

=====================

Church Mod Forum Topic :

https://forum.minetest.net/viewtopic.php?f=9&t=16029&sid=65c913208fd877b0d021969ad86cd0d4#p242311


=====================

depends :
- default
- moreores
- farming
- vessels
- mobs?

=====================

![Preview](https://raw.githubusercontent.com/Napiophelios/church/master/church_candles/screenshot.png)

Textures by Napiophelios

License: CC-BY-SA 3.0

=====================
