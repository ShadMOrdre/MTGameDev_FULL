Licenses: CC0
By AiTechEye
Version: 10

hook:
hit on a edge to climb up.

upgraded hook:
use with double hight

rope:
place on a edge to climb, or throw it.

locked rope:
only you can take it, or throw it.

slingshot:
throw junk far away and hurt your enemies
place it to change side to use

Mouth breather assembly:
use outside water/vaccum to refill with air, use in water/vaccum to refill your breath (max 10 times))

Work rbot:
Place the controler to change between 8 modes.

Pchest:
portable chest, the stuff is stored inside the chest/tool, and not in a ghost inventory.