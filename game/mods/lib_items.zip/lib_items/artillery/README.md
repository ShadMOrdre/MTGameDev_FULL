	     _         _   _ _ _                 
	    / \   _ __| |_(_) | | ___ _ __ _   _ 
	   / _ \ | '__| __| | | |/ _ \ '__| | | |
	  / ___ \| |  | |_| | | |  __/ |  | |_| |
	 /_/   \_\_|   \__|_|_|_|\___|_|   \__, |
                                        |___/ ~Pew pew

This will soon be a mod for heavy artillery (turrets, laz0rs, etc..).