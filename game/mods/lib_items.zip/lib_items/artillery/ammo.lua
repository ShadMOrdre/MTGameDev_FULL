minetest.register_craftitem("artillery:mortar_shell", {
	description = "Mortar Shell",
	image = "shell.png",
})