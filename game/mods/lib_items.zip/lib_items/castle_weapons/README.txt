=-=-=-=-=-=-=-=-=-=

Castles Mod
by: Philipbenr And DanDuncombe

=-=-=-=-=-=-=-=-=-=

Licence: MIT, LGPLv2.1 (Crossbow)

see: LICENSE

=-=-=-=-=-=-=-=-=-=

This mod contains a crossbow with bolts, suitable for ranged combat. The crossbow is sourced from the "shooter" mod.

It also contains a battleaxe for fighting up close and personal.