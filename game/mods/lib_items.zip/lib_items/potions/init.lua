-- Poison

local water = {
	"bucket:bucket_water",
	"bucket:wooden_water",
	"bucket:wooden_freshwater",
	"group:water",
}

local water_replacements = {
	{"bucket:bucket_water","bucket:bucket_empty"},
	{"bucket:wooden_water","bucket:wooden_empty"},
	{"bucket:wooden_freshwater","bucket:wooden_empty"},
}

minetest.register_craftitem("potions:poison",{
	description = "Poison!",
	inventory_image = "potions_poison.png",
	wield_image = "potions_poison.png",
	on_use = minetest.item_eat(-10),
})

minetest.register_craft( {
         type = "shapeless",
         output = "potions:poison",
         recipe = { "mushroom:red" , "vessels:glass_bottle" },
})

minetest.register_craftitem("potions:ruby",{
	description = "Ruby Potion",
	inventory_image = "potions_red.png",
	wield_image = "potions_red.png",
	on_use = minetest.item_eat(12),
})

minetest.register_craft( {
         type = "shapeless",
         output = "potions:ruby",
         recipe = { 
		 		"group:water", 
		 		"vessels:glass_bottle",
				"mineral:ruby_gem",
				"plant:beetroot", 
		},
})

minetest.register_craftitem("potions:diamond",{
	description = "Diamond Potion",
	inventory_image = "potions_gold.png",
	wield_image = "potions_gold.png",
	on_use = minetest.item_eat(-1),
})

minetest.register_craft( {
         type = "shapeless",
         output = "potions:diamond",
         recipe = { 
		 		"group:water", 
		 		"vessels:glass_bottle",
				"mineral:diamond_gem",
				"mineral:gold_ingot", 
		},
})

minetest.register_craftitem("potions:saphire",{
	description = "Saphire Potion",
	inventory_image = "potions_blue.png",
	wield_image = "potions_blue.png",
	on_use = minetest.item_eat(1),
})

minetest.register_craft( {
         type = "shapeless",
         output = "potions:saphire",
         recipe = { 
		 		"group:water", 
		 		"vessels:glass_bottle",
				"mineral:saphire_gem", 
		},
})

minetest.register_craftitem("potions:emerald",{
	description = "Emerald Potion",
	inventory_image = "potions_green.png",
	wield_image = "potions_green.png",
	on_use = minetest.item_eat(0),
})

minetest.register_craft( {
         type = "shapeless",
         output = "potions:emerald",
         recipe = { 
		 		"group:water", 
		 		"vessels:glass_bottle",
				"mineral:emerald_gem", 
		},
})

minetest.register_craftitem("potions:topaz",{
	description = "Topaz Potion",
	inventory_image = "potions_indigo.png",
	wield_image = "potions_indigo.png",
	on_use = minetest.item_eat(18),
})

minetest.register_craft( {
         type = "shapeless",
         output = "potions:topaz",
         recipe = { 
		 		"group:water", 
		 		"vessels:glass_bottle",
				"mineral:topaz_gem", 
		},
})

minetest.register_craftitem("potions:amethyst",{
	description = "Amethyst Potion",
	inventory_image = "potions_purple.png",
	wield_image = "potions_purple.png",
	on_use = minetest.item_eat(-1),
})

minetest.register_craft( {
         type = "shapeless",
         output = "potions:amethyst",
         recipe = { 
		 		"group:water", 
		 		"vessels:glass_bottle",
				"mineral:amethyst_gem", 
		},
})
