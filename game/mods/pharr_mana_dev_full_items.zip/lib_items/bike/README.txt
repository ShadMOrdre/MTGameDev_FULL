Minetest mod: bike
========================
See license.txt for license information.

Authors of source code
----------------------
Originally by PilzAdam (MIT)
Various Minetest developers and contributors (MIT)
Hume2 (MIT)

Authors of media (textures and model)
-------------------------------------
Texture: Hume2 (MIT)
Model: Hume2 (MIT)
