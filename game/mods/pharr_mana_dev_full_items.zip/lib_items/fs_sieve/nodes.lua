minetest.register_node("fs_sieve:compressed_gravel", {
	description = "Compressed Gravel",
	tiles = {"fs_sieve_compressed_gravel.png"},
	groups = {cracky = 2, crumbly = 2},
	sounds = default.node_sound_gravel_defaults(),
})

