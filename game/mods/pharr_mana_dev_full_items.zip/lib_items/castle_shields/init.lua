castle_shields = {}

local MP = minetest.get_modpath(minetest.get_current_modname())
dofile(MP.."/shield_functions.lua")
dofile(MP.."/default_shields.lua")
