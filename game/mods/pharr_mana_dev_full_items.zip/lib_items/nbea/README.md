=====================

#NodeBox Editor Abuse Mod [nbea]

by Napiophelios

License: WTFPL

=====================

Several pointless nodes that look neat

=====================

##depends :

- default
- mesecons?

=====================

![Preview](https://raw.githubusercontent.com/Napiophelios/NBox_Abuse/master/screenshot.png)

All Media (Textures and Sound effects)
License : Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)

http://creativecommons.org/licenses/by-sa/3.0/

=====================
