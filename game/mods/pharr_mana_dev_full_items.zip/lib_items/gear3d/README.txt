Gears for Minetest [gear3d]
===========================

Proof of concept gears mod for Minetest
---------------------------------------

Very much a work-in-progress so only some decorative animated nodes
for now. You will need to use the screwdriver to manipulate rotations,
however, I do eventually plan to have intelligent placement along with
support for mesecons, etc.

As this is WIP you can expect the registered node names to change!
