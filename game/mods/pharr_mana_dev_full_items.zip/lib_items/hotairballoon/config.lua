hotairballoon = {}

--If you want to be available only through /giveme or at admin shops, set this to false.
hotairballoon.crafts = true

--If you want to be only one use, set this to true.
hotairballoon.one_use = false
