# bible
a mod for minetest (see http://minetest.net) that adds a bible.
IMHO it was missing in the church mod (https://github.com/mootpoint/church), that brings many helpful items to build a good church.

The aim is to have different bibles, that can be opened and closed and contain bible verses.

I'm a pastor, not a professional coder, so help and new ideas are very welcome.

To install the mod, just download the .zip file, extract it, and copy everything to the "mods" folder of minetest on Your computer. Then open the game, go to "local game" ("Lokales Spiel"), choose a world, cklick "configure" ("Konfigurieren") and activate it.
Have fun and don't forget to read the real bible :-) 
