RandomMessages mod by arsdragonfly.
Put your messages in (world directory)/random_messages,1 message per line.
Messages can be all kinds of hints, mod usage, etc.
Add/Remove messages on the fly:
/rmessages viewmessages
to see all the messages.
/rmessages addmessage blah blah blah
to add the random message blah blah blah.
/rmessages removemessage 2
to remove the 2nd random message in /rmessages viewmessages .
In minetest.conf, random_messages_interval decides how often a message is sent.
Released under CC0.
Special thanks to:
Michael Rasmussen (michael@jamhome.us)
Enjoy it! ^_^
arsdragonfly@gmail.com
6/19/2013

20170710 Converted into a biblebot by maikerumine
KJV Bibles from: https://sites.google.com/site/ruwach/bibletext

bible.txt
Size: 1.27mb
Format: One Big Text file of the whole Bible
Bible Version: King James Bible also known as the Authorised Version
Bible Copyright: Public Domain
Software Copyright: Public Domain
 