[Mod] connected chests [connected_chests]

This mod allows making bigger default chests.  
Just hold shift and place a chest onto another one's side.  
This is not the first mod which adds big chests.

**Depends:** see [depends.txt](https://raw.githubusercontent.com/HybridDog/connected_chests/master/depends.txt)  
**License:** see [LICENSE.txt](https://raw.githubusercontent.com/HybridDog/connected_chests/master/LICENSE.txt)  
**Download:** [zip](https://github.com/HybridDog/connected_chests/archive/master.zip), [tar.gz](https://github.com/HybridDog/connected_chests/tarball/master)  

![I'm a screenshot!](http://wiki.minetest.net/images/d/d1/Connected_chest.png)

If you got ideas or found bugs, please tell them to me.

[How to install a mod?](http://wiki.minetest.net/Installing_Mods)


TODO:  
* add abms when registering the chest instead of using chestdata
* lid opening