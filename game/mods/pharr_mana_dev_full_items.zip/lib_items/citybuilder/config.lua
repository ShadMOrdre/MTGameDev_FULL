
-- how shall the savefile be named?
citybuilder.savefilename = "citybuilder.data";

-- how many cities shall each player be able to have at max?
citybuilder.max_cities_per_player = 5;

-- how far do two citybuilder blocks have to be apart at least?
citybuilder.min_intercity_distance = 400;
