Item Frames mod for minetest

This mod differs from the original and the one included in homedecor modpack in that no one person owns the itemframe or pedestals, they are protected with minetest.is_protected() so can have multiple owners or none at all...

Right-click to add or remove an item from a frame or pedestal, please note that if an item already has on_rightclick registered then it cannot be added to either.  Punch frame or pedestal to force update if items do not appear.
