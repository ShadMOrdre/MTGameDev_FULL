# Medieval Mod For Minetest

Medieval is an up and coming mod for minetest. 

## Requires 
* Darkage

## What the mod adds to the minetest game

Medieval adds a range of blocks to the game. starting with the ones stated below;

1. Three New Medieval Glass as well as coloured glass 
2. Four New Bar nodes made with multiple Materials such as Brick, Wood and cobble
3. New Boxes such as potato and fish boxes 
4. New plaster nodes like the cobble plaster in darkage
5. Item Sign which allows you to put items in the sign  

They are some more things which may be coming to the mod soon  

1. New Decorative nodes such as table nodes and shelves nodes
2. Connecting texture nodes   