Bell that rings every hour as many times as the hour counts (1-12 times)
Works like a church bell.

Sound and textures not yet included.

The positions of placed bells are saved. Thus, each bell can ring independently of the load status of the area the bell is in.

You can ring a bell manually.

