Minetest mod "New Fireworks"
======================
Version: 0.0.3

# License of source code:
Copyright (C) 2017 googol <googolgl@gmail.com>

# Notice:
This mod is only useable with Minetest 0.4.15-dev or above!

# Description:
This mod adds to the minetest Fireworks.
Happy Holidays!!!


# Change Log
#### [0.0.1] - 2017-02-12
- Betta
#### [0.0.2] - 2017-02-20
- Pre relise
#### [0.0.3] - 2017-02-21
- Aded multi-explosion

# Links:
Forum Topic:
- <https://forum.minetest.net/>

Bitbucket:
- <https://bitbucket.org/g00g01/new_fireworks>
