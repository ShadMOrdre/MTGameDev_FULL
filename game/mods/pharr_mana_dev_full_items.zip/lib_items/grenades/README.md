# grenades
Adds a grenade API and a few grenades to Minetest

License of code: **MIT**

License of sound and textures: **CC-BY**
