Minetest Game mod: sailing
========================
See license.txt for license information.

Authors of source code
----------------------
Sailing by cakenggt

Authors of media (textures and model)
-------------------------------------
Textures: cakenggt and Minetest (CC BY-SA 3.0)
Model: cakenggt (CC BY-SA 3.0)
