
This is a trader for minetest.
Dependencies: none

Please use the chatcommand  /trader   to spawn traders.

Textures bauerin.png, kuhhaendler.png and bauer_in_sonntagslkeidung.png where done by Jordach.
Texture wheat_farmer_by_addi.png has been done by Addi and is CC-BY-SA. It is based on Jordachs SAM texture.

Texture for the money/money2 (textures/mobf_trader_money.png) has been created by John1.
