local path = minetest.get_modpath("mobs_skeleton_archer")

dofile(path .. "/skeleton.lua") -- Mesh by Morn76 Animation by Pavel_S
dofile(path .. "/heads.lua") -- maikerumine

--IN CASE THROWING IS NOT INSTALLED, THIS FIX
	if not throwing then
		dofile(minetest.get_modpath("mobs_skeleton_archer").."/2_extra.lua")
		minetest.register_alias("throwing:bow_wood", "mobs:bow_wood")
		minetest.register_alias("throwing:arrow", "mobs:arrow")
		mobs:alias_mob("throwing:arrow_entity", "mobs:arrow_entity")
		else
		minetest.register_alias("_:bow_wood", "throwing:bow_wood")
		minetest.register_alias("_:arrow", "throwing:arrow")
		mobs:alias_mob("_:arrow_entity", "throwing:arrow_entity")
	end

print ("[MOD] Mobs Redo 'Skeleton Archer' loaded")
