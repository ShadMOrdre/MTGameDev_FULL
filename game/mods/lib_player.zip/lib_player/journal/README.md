# journal
a minetest mod that adds a journal
