


local MP = minetest.get_modpath(minetest.get_current_modname())
local S, NS = dofile(MP.."/intllib.lua")

if not minetest.get_modpath("3d_armor") then
	minetest.log("warning", S("armor_additions: Mod loaded but unused."))
	return
end



local craft_ingreds = {
	obsidian = "default:obsidian",
	carbonfiber = "lib_materials:carbon_steel_ingot",
	copper = "default:copperblock",
	leather = "mobs:leather",
}

for k, v in pairs(craft_ingreds) do
	minetest.register_craft({
		output = "armor_additions:helmet_"..k,
		recipe = {
			{v, v, v},
			{v, "", v},
			{"", "", ""},
		},
	})
	minetest.register_craft({
		output = "armor_additions:chestplate_"..k,
		recipe = {
			{v, "", v},
			{v, v, v},
			{v, v, v},
		},
	})
	minetest.register_craft({
		output = "armor_additions:leggings_"..k,
		recipe = {
			{v, v, v},
			{v, "", v},
			{v, "", v},
		},
	})
	minetest.register_craft({
		output = "armor_additions:boots_"..k,
		recipe = {
			{v, "", v},
			{v, "", v},
		},
	})
	minetest.register_craft({
		output = "armor_additions:shield_"..k,
		recipe = {
			{v, v, v},
			{v, v, v},
			{"", v, ""},
		},
	})
end




minetest.register_tool("armor_additions:helmet_royal_diamond", {
		description = "Royal Diamond Helmet",
		inventory_image = "armor_additions_inv_helmet_royal_diamond.png",
		groups = {armor_head=22.5, armor_heal=18, armor_use=165},
		wear = 0,
})
minetest.register_tool("armor_additions:chestplate_royal_diamond", {
	description = "Royal Diamond Chestplate",
	inventory_image = "armor_additions_inv_chestplate_royal_diamond.png",
	groups = {armor_torso=30, armor_heal=18, armor_use=165},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_royal_diamond", {
	description = "Royal Diamond Leggings",
	inventory_image = "armor_additions_inv_leggings_royal_diamond.png",
	groups = {armor_legs=30, armor_heal=18, armor_use=165},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_royal_diamond", {
	description = "Royal Diamond Boots",
	inventory_image = "armor_additions_inv_boots_royal_diamond.png",
	groups = {armor_feet=22.5, armor_heal=18, armor_use=165},
	wear = 0,
})
--[[
minetest.register_tool("armor_additions:shield_royal_diamond", {
	description = "Royal Diamond Shield",
	inventory_image = "armor_additions_inv_shield_royal_diamond.png",
	groups = {armor_shield=22.5, armor_heal=18, armor_use=165},
	wear = 0,
})
--]]
minetest.register_tool("armor_additions:helmet_royal_gold", {
		description = "Royal Gold Helmet",
		inventory_image = "armor_additions_inv_helmet_royal_gold.png",
		groups = {armor_head=22.5, armor_heal=18, armor_use=165},
		wear = 0,
})
minetest.register_tool("armor_additions:chestplate_royal_gold", {
	description = "Royal Gold Chestplate",
	inventory_image = "armor_additions_inv_chestplate_royal_gold.png",
	groups = {armor_torso=30, armor_heal=18, armor_use=165},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_royal_gold", {
	description = "Royal Gold Leggings",
	inventory_image = "armor_additions_inv_leggings_royal_gold.png",
	groups = {armor_legs=30, armor_heal=18, armor_use=165},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_royal_gold", {
	description = "Royal Gold Boots",
	inventory_image = "armor_additions_inv_boots_royal_gold.png",
	groups = {armor_feet=22.5, armor_heal=18, armor_use=165},
	wear = 0,
})
--[[
minetest.register_tool("armor_additions:shield_royal_gold", {
	description = "Royal Gold Shield",
	inventory_image = "armor_additions_inv_shield_royal_gold.png",
	groups = {armor_shield=22.5, armor_heal=18, armor_use=165},
	wear = 0,
})
--]]
minetest.register_tool("armor_additions:helmet_royal_steel", {
		description = "Royal Steel Helmet",
		inventory_image = "armor_additions_inv_helmet_royal_steel.png",
		groups = {armor_head=22.5, armor_heal=18, armor_use=165},
		wear = 0,
})
minetest.register_tool("armor_additions:chestplate_royal_steel", {
	description = "Royal Steel Chestplate",
	inventory_image = "armor_additions_inv_chestplate_royal_steel.png",
	groups = {armor_torso=30, armor_heal=18, armor_use=165},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_royal_steel", {
	description = "Royal Steel Leggings",
	inventory_image = "armor_additions_inv_leggings_royal_steel.png",
	groups = {armor_legs=30, armor_heal=18, armor_use=165},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_royal_steel", {
	description = "Royal Steel Boots",
	inventory_image = "armor_additions_inv_boots_royal_steel.png",
	groups = {armor_feet=22.5, armor_heal=18, armor_use=165},
	wear = 0,
})
--[[
minetest.register_tool("armor_additions:shield_royal_steel", {
	description = "Royal Steel Shield",
	inventory_image = "armor_additions_inv_shield_royal_steel.png",
	groups = {armor_shield=22.5, armor_heal=18, armor_use=165},
	wear = 0,
})
--]]



minetest.register_tool("armor_additions:helmet_obsidian", {
	description = "Obsidian Helmet",
	inventory_image = "armor_additions_inv_helmet_obsidian.png",
	groups = {armor_head=22.5, armor_heal=18, armor_use=300},
	wear = 0,
})
minetest.register_tool("armor_additions:chestplate_obsidian", {
	description = "Obsidian Chestplate",
	inventory_image = "armor_additions_inv_chestplate_obsidian.png",
	groups = {armor_torso=30, armor_heal=18, armor_use=300},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_obsidian", {
	description = "Obsidian Leggings",
	inventory_image = "armor_additions_inv_leggings_obsidian.png",
	groups = {armor_legs=30, armor_heal=18, armor_use=300},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_obsidian", {
	description = "Obsidian Boots",
	inventory_image = "armor_additions_inv_boots_obsidian.png",
	groups = {armor_feet=22.5, armor_heal=18, armor_use=300},
	wear = 0,
})
minetest.register_tool("armor_additions:shield_obsidian", {
	description = "Obsidian Shield",
	inventory_image = "armor_additions_inv_shield_obsidian.png",
	groups = {armor_shield=22.5, armor_heal=18, armor_use=300},
	wear = 0,
})

minetest.register_tool("armor_additions:helmet_carbonfiber", {
		description = "Carbonfiber Helmet",
		inventory_image = "armor_additions_inv_helmet_carbonfiber.png",
		groups = {armor_head=22.5, armor_heal=18, armor_use=165},
		wear = 0,
})
minetest.register_tool("armor_additions:chestplate_carbonfiber", {
	description = "Carbonfiber Chestplate",
	inventory_image = "armor_additions_inv_chestplate_carbonfiber.png",
	groups = {armor_torso=30, armor_heal=18, armor_use=165},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_carbonfiber", {
	description = "Carbonfiber Leggings",
	inventory_image = "armor_additions_inv_leggings_carbonfiber.png",
	groups = {armor_legs=30, armor_heal=18, armor_use=165},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_carbonfiber", {
	description = "Carbonfiber Boots",
	inventory_image = "armor_additions_inv_boots_carbonfiber.png",
	groups = {armor_feet=22.5, armor_heal=18, armor_use=165},
	wear = 0,
})
minetest.register_tool("armor_additions:shield_carbonfiber", {
	description = "Carbonfiber Shield",
	inventory_image = "armor_additions_inv_shield_carbonfiber.png",
	groups = {armor_shield=22.5, armor_heal=18, armor_use=165},
	wear = 0,
})


minetest.register_tool("armor_additions:helmet_titanium", {
		description = "Titanium Helmet",
		inventory_image = "armor_additions_inv_helmet_titanium.png",
		groups = {armor_head=22.5, armor_heal=18, armor_use=165},
		wear = 0,
})
minetest.register_tool("armor_additions:chestplate_titanium", {
	description = "Titanium Chestplate",
	inventory_image = "armor_additions_inv_chestplate_titanium.png",
	groups = {armor_torso=30, armor_heal=18, armor_use=165},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_titanium", {
	description = "Titanium Leggings",
	inventory_image = "armor_additions_inv_leggings_titanium.png",
	groups = {armor_legs=30, armor_heal=18, armor_use=165},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_titanium", {
	description = "Titanium Boots",
	inventory_image = "armor_additions_inv_boots_titanium.png",
	groups = {armor_feet=22.5, armor_heal=18, armor_use=165},
	wear = 0,
})
minetest.register_tool("armor_additions:shield_titanium", {
	description = "Titanium Shield",
	inventory_image = "armor_additions_inv_shield_titanium.png",
	groups = {armor_shield=22.5, armor_heal=18, armor_use=165},
	wear = 0,
})


	
minetest.register_tool("armor_additions:helmet_copper", {
	description = "copper Helmet",
	inventory_image = "armor_additions_inv_helmet_copper.png",
	groups = {armor_head=8, armor_heal=0, armor_use=750},
	wear = 0,
})
minetest.register_tool("armor_additions:chestplate_copper", {
	description = "copper Chestplate",
	inventory_image = "armor_additions_inv_chestplate_copper.png",
	groups = {armor_torso=13, armor_heal=0, armor_use=750},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_copper", {
	description = "copper Leggings",
	inventory_image = "armor_additions_inv_leggings_copper.png",
	groups = {armor_legs=13, armor_heal=0, armor_use=750},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_copper", {
	description = "copper Boots",
	inventory_image = "armor_additions_inv_boots_copper.png",
	groups = {armor_feet=8, armor_heal=0, armor_use=750},
	wear = 0,
})
minetest.register_tool("armor_additions:shield_copper", {
	description = "copper shield",
	inventory_image = "armor_additions_inv_shield_copper.png",
	groups = {armor_shield=8, armor_heal=0, armor_use=750},
	wear = 0,
})

minetest.register_craft({
	output = 'armor_additions:helmet_copper',
	recipe = {
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
		{'default:copper_ingot', '', 'default:copper_ingot'},
		{'', '', ''},
	}
})
minetest.register_craft({
	output = 'armor_additions:chestplate_copper',
	recipe = {
		{'default:copper_ingot', '', 'default:copper_ingot'},
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
	}
})
minetest.register_craft({
	output = 'armor_additions:leggings_copper',
	recipe = {
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
		{'default:copper_ingot', '', 'default:copper_ingot'},
		{'default:copper_ingot', '', 'default:copper_ingot'},
	}
})
minetest.register_craft({
	output = 'armor_additions:boots_copper',
	recipe = {
		{'', '', ''},
		{'default:copper_ingot', '', 'default:copper_ingot'},
		{'default:copper_ingot', '', 'default:copper_ingot'},
	}
})
minetest.register_craft({
	output = 'armor_additions:shield_copper',
	recipe = {
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
		{'', 'default:copper_ingot', ''},
	}
})

minetest.register_tool("armor_additions:helmet_chainmail", {
	description = "chainmail Helmet",
	inventory_image = "armor_additions_inv_helmet_chainmail.png",
	groups = {armor_head=8, armor_heal=0, armor_use=750},
	wear = 0,
})
minetest.register_tool("armor_additions:chestplate_chainmail", {
	description = "chainmail Chestplate",
	inventory_image = "armor_additions_inv_chestplate_chainmail.png",
	groups = {armor_torso=13, armor_heal=0, armor_use=750},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_chainmail", {
	description = "chainmail Leggings",
	inventory_image = "armor_additions_inv_leggings_chainmail.png",
	groups = {armor_legs=13, armor_heal=0, armor_use=750},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_chainmail", {
	description = "chainmail Boots",
	inventory_image = "armor_additions_inv_boots_chainmail.png",
	groups = {armor_feet=8, armor_heal=0, armor_use=750},
	wear = 0,
})
minetest.register_tool("armor_additions:shield_chainmail", {
	description = "chainmail shield",
	inventory_image = "armor_additions_inv_shield_chainmail.png",
	groups = {armor_shield=8, armor_heal=0, armor_use=750},
	wear = 0,
})

minetest.register_craft({
	output = 'armor_additions:helmet_chainmail',
	recipe = {
		{'xpanes:bar_flat', 'xpanes:bar_flat', 'xpanes:bar_flat'},
		{'xpanes:bar_flat', '', 'xpanes:bar_flat'},
		{'', '', ''},
	}
})
minetest.register_craft({
	output = 'armor_additions:chestplate_chainmail',
	recipe = {
		{'xpanes:bar_flat', '', 'xpanes:bar_flat'},
		{'xpanes:bar_flat', 'xpanes:bar_flat', 'xpanes:bar_flat'},
		{'xpanes:bar_flat', 'xpanes:bar_flat', 'xpanes:bar_flat'},
	}
})
minetest.register_craft({
	output = 'armor_additions:leggings_chainmail',
	recipe = {
		{'xpanes:bar_flat', 'xpanes:bar_flat', 'xpanes:bar_flat'},
		{'xpanes:bar_flat', '', 'xpanes:bar_flat'},
		{'xpanes:bar_flat', '', 'xpanes:bar_flat'},
	}
})
minetest.register_craft({
	output = 'armor_additions:boots_chainmail',
	recipe = {
		{'', '', ''},
		{'xpanes:bar_flat', '', 'xpanes:bar_flat'},
		{'xpanes:bar_flat', '', 'xpanes:bar_flat'},
	}
})
minetest.register_craft({
	output = 'armor_additions:shield_chainmail',
	recipe = {
		{'xpanes:bar_flat', 'xpanes:bar_flat', 'xpanes:bar_flat'},
		{'xpanes:bar_flat', 'xpanes:bar_flat', 'xpanes:bar_flat'},
		{'', 'xpanes:bar_flat', ''},
	}
})

minetest.register_tool("armor_additions:helmet_leather", {
	description = "leather cap",
	inventory_image = "armor_additions_inv_helmet_leather.png",
	groups = {armor_head=7, armor_heal=2, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:chestplate_leather", {
	description = "leather tunic",
	inventory_image = "armor_additions_inv_chestplate_leather.png",
	groups = {armor_torso=12, armor_heal=2, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_leather", {
	description = "leather trousers",
	inventory_image = "armor_additions_inv_leggings_leather.png",
	groups = {armor_legs=7, armor_heal=2, armor_use=150},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_leather", {
	description = "leather Boots",
	inventory_image = "armor_additions_inv_boots_leather.png",
	groups = {armor_feet=7, armor_heal=2,physics_speed=0.15, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:shield_leather", {
	description = "leather shield",
	inventory_image = "armor_additions_inv_shield_leather.png",
	groups = {armor_shield=7, armor_heal=2, armor_use=1000},
	wear = 0,
})

minetest.register_craft({
	output = 'armor_additions:helmet_leather',
	recipe = {
		{'mobs:leather', 'mobs:leather', 'mobs:leather'},
		{'mobs:leather', '', 'mobs:leather'},
		{'', '', ''},
	}
})
minetest.register_craft({
	output = 'armor_additions:chestplate_leather',
	recipe = {
		{'mobs:leather', '', 'mobs:leather'},
		{'mobs:leather', 'mobs:leather', 'mobs:leather'},
		{'mobs:leather', 'mobs:leather', 'mobs:leather'},
	}
})
minetest.register_craft({
	output = 'armor_additions:leggings_leather',
	recipe = {
		{'mobs:leather', 'mobs:leather', 'mobs:leather'},
		{'mobs:leather', '', 'mobs:leather'},
		{'mobs:leather', '', 'mobs:leather'},
	}
})
minetest.register_craft({
	output = 'armor_additions:boots_leather',
	recipe = {
		{'', '', ''},
		{'mobs:leather', '', 'mobs:leather'},
		{'mobs:leather', '', 'mobs:leather'},
	}
})
minetest.register_craft({
	output = 'armor_additions:shield_leather',
	recipe = {
		{'mobs:leather', 'mobs:leather', 'mobs:leather'},
		{'mobs:leather', 'default:wood', 'mobs:leather'},
		{'', 'mobs:leather', ''},
	}
})

minetest.register_tool("armor_additions:helmet_studded", {
	description = "studded Helmet",
	inventory_image = "armor_additions_inv_helmet_studded.png",
	groups = {armor_head=12.4, armor_heal=2, armor_use=400},
	wear = 0,
})
minetest.register_tool("armor_additions:chestplate_studded", {
	description = "studded Chestplate",
	inventory_image = "armor_additions_inv_chestplate_studded.png",
	groups = {armor_torso=16.4, armor_heal=2, armor_use=400},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_studded", {
	description = "studded Leggings",
	inventory_image = "armor_additions_inv_leggings_studded.png",
	groups = {armor_legs=16.4, armor_heal=2, armor_use=400},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_studded", {
	description = "studded Boots",
	inventory_image = "armor_additions_inv_boots_studded.png",
	groups = {armor_feet=12.4, armor_heal=2, armor_use=400},
	wear = 0,
})
minetest.register_tool("armor_additions:shield_studded", {
	description = "studded shield",
	inventory_image = "armor_additions_inv_shield_studded.png",
	groups = {armor_shield=12.4, armor_heal=2, armor_use=400},
	wear = 0,
})

minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:helmet_studded",
	recipe = {"armor_additions:helmet_chainmail", "armor_additions:helmet_leather"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:chestplate_studded",
	recipe = {"armor_additions:chestplate_chainmail", "armor_additions:chestplate_leather"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:leggings_studded",
	recipe = {"armor_additions:leggings_chainmail", "armor_additions:leggings_leather"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:boots_studded",
	recipe = {"armor_additions:boots_chainmail", "armor_additions:boots_leather"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:shield_studded",
	recipe = {"armor_additions:shield_chainmail", "armor_additions:shield_leather"},
})

minetest.register_tool("armor_additions:helmet_leather_black", {
	description = "black leather cap",
	inventory_image = "armor_additions_inv_helmet_leather_black.png",
	groups = {leather_helmet=1, armor_head=7, armor_heal=2, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:chestplate_leather_black", {
	description = "black leather tunic",
	inventory_image = "armor_additions_inv_chestplate_leather_black.png",
	groups = {leather_chestplate=1, armor_torso=12, armor_heal=2, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_leather_black", {
	description = "black leather trousers",
	inventory_image = "armor_additions_inv_leggings_leather_black.png",
	groups = {leather_leggings=1, armor_legs=7, armor_heal=2, armor_use=150},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_leather_black", {
	description = "black leather Boots",
	inventory_image = "armor_additions_inv_boots_leather_black.png",
	groups = {leather_boots=1, armor_feet=7, armor_heal=2,physics_speed=0.15, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:shield_leather_black", {
	description = "black leather shield",
	inventory_image = "armor_additions_inv_shield_leather_black.png",
	groups = {leather_shield=1, armor_shield=7, armor_heal=2, armor_use=1000},
	wear = 0,
})

minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:shield_leather_black",
	recipe = {"armor_additions:shield_leather", "dye:black"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:helmet_leather_black",
	recipe = {"armor_additions:helmet_leather", "dye:black"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:chestplate_leather_black",
	recipe = {"armor_additions:chestplate_leather", "dye:black"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:leggings_leather_black",
	recipe = {"armor_additions:leggings_leather", "dye:black"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:boots_leather_black",
	recipe = {"armor_additions:boots_leather", "dye:black"},
})

minetest.register_tool("armor_additions:helmet_leather_grey", {
	description = "grey leather cap",
	inventory_image = "armor_additions_inv_helmet_leather_grey.png",
	groups = {leather_helmet=1, armor_head=7, armor_heal=2, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:chestplate_leather_grey", {
	description = "grey leather tunic",
	inventory_image = "armor_additions_inv_chestplate_leather_grey.png",
	groups = {leather_chestplate=1, armor_torso=12, armor_heal=2, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_leather_grey", {
	description = "grey leather trousers",
	inventory_image = "armor_additions_inv_leggings_leather_grey.png",
	groups = {leather_leggings=1, armor_legs=7, armor_heal=2, armor_use=150},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_leather_grey", {
	description = "grey leather Boots",
	inventory_image = "armor_additions_inv_boots_leather_grey.png",
	groups = {leather_boots=1, armor_feet=7, armor_heal=2,physics_speed=0.15, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:shield_leather_grey", {
	description = "grey leather shield",
	inventory_image = "armor_additions_inv_shield_leather_grey.png",
	groups = {leather_shield=1, armor_shield=7, armor_heal=2, armor_use=1000},
	wear = 0,
})

minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:shield_leather_grey",
	recipe = {"armor_additions:shield_leather", "dye:grey"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:helmet_leather_grey",
	recipe = {"armor_additions:helmet_leather", "dye:grey"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:chestplate_leather_grey",
	recipe = {"armor_additions:chestplate_leather", "dye:grey"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:leggings_leather_grey",
	recipe = {"armor_additions:leggings_leather", "dye:grey"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:boots_leather_grey",
	recipe = {"armor_additions:boots_leather", "dye:grey"},
})

minetest.register_tool("armor_additions:helmet_leather_dark_grey", {
	description = "dark grey leather cap",
	inventory_image = "armor_additions_inv_helmet_leather_dark_grey.png",
	groups = {leather_helmet=1, armor_head=7, armor_heal=2, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:chestplate_leather_dark_grey", {
	description = "dark grey leather tunic",
	inventory_image = "armor_additions_inv_chestplate_leather_dark_grey.png",
	groups = {leather_chestplate=1, armor_torso=12, armor_heal=2, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_leather_dark_grey", {
	description = "dark grey leather trousers",
	inventory_image = "armor_additions_inv_leggings_leather_dark_grey.png",
	groups = {leather_leggings=1, armor_legs=7, armor_heal=2, armor_use=150},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_leather_dark_grey", {
	description = "dark grey leather Boots",
	inventory_image = "armor_additions_inv_boots_leather_dark_grey.png",
	groups = {leather_boots=1, armor_feet=7, armor_heal=2,physics_speed=0.15, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:shield_leather_dark_grey", {
	description = "dark grey leather shield",
	inventory_image = "armor_additions_inv_shield_leather_dark_grey.png",
	groups = {leather_shield=1, armor_shield=7, armor_heal=2, armor_use=1000},
	wear = 0,
})

minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:shield_leather_dark_grey",
	recipe = {"armor_additions:shield_leather", "dye:dark_grey"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:helmet_leather_dark_grey",
	recipe = {"armor_additions:helmet_leather", "dye:dark_grey"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:chestplate_leather_dark_grey",
	recipe = {"armor_additions:chestplate_leather", "dye:dark_grey"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:leggings_leather_dark_grey",
	recipe = {"armor_additions:leggings_leather", "dye:dark_grey"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:boots_leather_dark_grey",
	recipe = {"armor_additions:boots_leather", "dye:dark_grey"},
})

minetest.register_tool("armor_additions:helmet_leather_dark_green", {
	description = "dark green leather cap",
	inventory_image = "armor_additions_inv_helmet_leather_dark_green.png",
	groups = {leather_helmet=1, armor_head=7, armor_heal=2, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:chestplate_leather_dark_green", {
	description = "dark green leather tunic",
	inventory_image = "armor_additions_inv_chestplate_leather_dark_green.png",
	groups = {leather_chestplate=1, armor_torso=12, armor_heal=2, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_leather_dark_green", {
	description = "dark green leather trousers",
	inventory_image = "armor_additions_inv_leggings_leather_dark_green.png",
	groups = {leather_leggings=1, armor_legs=7, armor_heal=2, armor_use=150},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_leather_dark_green", {
	description = "dark green leather Boots",
	inventory_image = "armor_additions_inv_boots_leather_dark_green.png",
	groups = {leather_boots=1, armor_feet=7, armor_heal=2,physics_speed=0.15, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:shield_leather_dark_green", {
	description = "dark green leather shield",
	inventory_image = "armor_additions_inv_shield_leather_dark_green.png",
	groups = {leather_shield=1, armor_shield=7, armor_heal=2, armor_use=1000},
	wear = 0,
})

minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:shield_leather_dark_green",
	recipe = {"armor_additions:shield_leather", "dye:dark_green"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:helmet_leather_dark_green",
	recipe = {"armor_additions:helmet_leather", "dye:dark_green"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:chestplate_leather_dark_green",
	recipe = {"armor_additions:chestplate_leather", "dye:dark_green"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:leggings_leather_dark_green",
	recipe = {"armor_additions:leggings_leather", "dye:dark_green"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:boots_leather_dark_green",
	recipe = {"armor_additions:boots_leather", "dye:dark_green"},
})

minetest.register_tool("armor_additions:helmet_leather_brown", {
	description = "brown leather cap",
	inventory_image = "armor_additions_inv_helmet_leather_brown.png",
	groups = {leather_helmet=1, armor_head=7, armor_heal=2, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:chestplate_leather_brown", {
	description = "brown leather tunic",
	inventory_image = "armor_additions_inv_chestplate_leather_brown.png",
	groups = {leather_chestplate=1, armor_torso=12, armor_heal=2, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:leggings_leather_brown", {
	description = "brown leather trousers",
	inventory_image = "armor_additions_inv_leggings_leather_brown.png",
	groups = {leather_leggings=1, armor_legs=7, armor_heal=2, armor_use=150},
	wear = 0,
})
minetest.register_tool("armor_additions:boots_leather_brown", {
	description = "brown leather Boots",
	inventory_image = "armor_additions_inv_boots_leather_brown.png",
	groups = {leather_boots=1, armor_feet=7, armor_heal=2,physics_speed=0.15, armor_use=1000},
	wear = 0,
})
minetest.register_tool("armor_additions:shield_leather_brown", {
	description = "brown leather shield",
	inventory_image = "armor_additions_inv_shield_leather_brown.png",
	groups = {leather_shield=1, armor_shield=7, armor_heal=2, armor_use=1000},
	wear = 0,
})

minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:shield_leather_brown",
	recipe = {"armor_additions:shield_leather", "dye:brown"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:helmet_leather_brown",
	recipe = {"armor_additions:helmet_leather", "dye:brown"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:chestplate_leather_brown",
	recipe = {"armor_additions:chestplate_leather", "dye:brown"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:leggings_leather_brown",
	recipe = {"armor_additions:leggings_leather", "dye:brown"},
})
minetest.register_craft({
	type = "shapeless",
	output = "armor_additions:boots_leather_brown",
	recipe = {"armor_additions:boots_leather", "dye:brown"},
})




if not minetest.get_modpath("lib_materials") then
	minetest.log("warning", S("technic_armor: Mod loaded but unused."))
	return
end

local stats = {
	lead = { name=S("Lead"), material="lib_materials:lead_ingot", armor=1.6, heal=0, use=500, radiation=80*1.1 },
	brass = { name=S("Brass"), material="lib_materials:brass_ingot", armor=1.8, heal=0, use=650, radiation=43 },
	wrought = { name=S("Wrought Iron"), material="lib_materials:wrought_iron_ingot", armor=2.2, heal=4, use=400, radiation=40 },
	cast = { name=S("Cast Iron"), material="lib_materials:cast_iron_ingot", armor=2.5, heal=8, use=200, radiation=40 },
	carbon = { name=S("Carbon Steel"), material="lib_materials:carbon_steel_ingot", armor=2.7, heal=10, use=100, radiation=40 },
	stainless = { name=S("Stainless Steel"), material="lib_materials:stainless_steel_ingot", armor=2.7, heal=10, use=75, radiation=40 },
}

local parts = {
	helmet = { place="head", name=S("Helmet"), level=5, radlevel = 0.10, craft={{1,1,1},{1,0,1}} },
	chestplate = { place="torso", name=S("Chestplate"), level=8, radlevel = 0.35, craft={{1,0,1},{1,1,1},{1,1,1}} },
	leggings = { place="legs", name=S("Leggings"), level=7, radlevel = 0.15, craft={{1,1,1},{1,0,1},{1,0,1}} },
	boots = { place="feet", name=S("Boots"), level=4, radlevel = 0.10, craft={{1,0,1},{1,0,1}} },
}
if minetest.get_modpath("shields") then
	parts.shield = { place="shield", name=S("Shield"), level=5, radlevel=0.00, craft={{1,1,1},{1,1,1},{0,1,0}} }
end

-- Makes a craft recipe based on a template
-- template is a recipe-like table but indices are used instead of actual item names:
-- 0 means nothing, everything else is treated as an index in the materials table
local function make_recipe(template, materials)
	local recipe = {}
	for j, trow in ipairs(template) do
		local rrow = {}
		for i, tcell in ipairs(trow) do
			if tcell == 0 then
				rrow[i] = ""
			else
				rrow[i] = materials[tcell]
			end
		end
		recipe[j] = rrow
	end
	return recipe
end

for key, armor in pairs(stats) do
	for partkey, part in pairs(parts) do
		local partname = "armor_additions:"..partkey.."_"..key
		minetest.register_tool(partname, {
			-- Translators: @1 stands for material and @2 for part of the armor, so that you could use a conjunction if in your language part name comes first then material (e.g. in french 'Silver Boots' is translated in 'Bottes en argent' by using '@2 en @1' as translated string)
			description = S("@1 @2", armor.name, part.name),
			inventory_image = "armor_additions_inv_"..partkey.."_"..key..".png",
			groups = {["armor_"..part.place]=math.floor(part.level*armor.armor), armor_heal=armor.heal, armor_use=armor.use, armor_radiation=math.floor(part.radlevel*armor.radiation)},
			wear = 0,
		})
		minetest.register_craft({
			output = partname,
			recipe = make_recipe(part.craft, {armor.material}),
		})
	end
end
