# Per Player Gamemode

Created by rubenwardy. Licensed under MIT.

Enable or disable game mode per player

* `/gamemode <mode>` - requires `gamemode` privilege
* `/gamemode playername <mode>` - requires `gamemode_super` privilege

Where `<mode>` is either `creative` or `survival`
