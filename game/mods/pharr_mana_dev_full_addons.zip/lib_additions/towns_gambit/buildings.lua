local count_buildings ={}
-- iterate over whole table to get all keys
local keyset = {}
for k in pairs(towns_gambit_schematic_table2) do
  table.insert(keyset, k)
end
--local variables for buildings
local building_all_info
local number_of_buildings 
local number_built
--
-- build schematic, replace material, rotation
--
function towns_gambit.build_schematic(pos, building, replace_wall, name, rot, offset)
  -- get building node material for better integration to surrounding
  local balcony_material =  minetest.get_node_or_nil(pos).name
  -- pick random material
  local material = towns_gambit_wallmaterial[math.random(1,#towns_gambit_wallmaterial)]
  -- schematic conversion to lua
  -- local schem_lua = minetest.serialize_schematic(building, 
    -- "lua", 
    -- {lua_use_comments = false, lua_num_indent_spaces = 0}).." return(schematic)"

	
  -- local schem_lua = tostring(building)

  -- -- replace material
  -- if replace_wall == "y" then
    -- schem_lua = schem_lua:gsub("default:cobble", material)
  -- end
  
  -- schem_lua = schem_lua:gsub("default:dirt_with_grass", balcony_material)
  
  -- -- special material for spawning npcs
  -- schem_lua = schem_lua:gsub("default:junglewood", "towns_gambit:junglewood")
  
  -- -- format schematic string
  -- local schematic = loadstring(schem_lua)()
  local schematic = building
  
  -- build foundation for the building an make room above
  local width = schematic["size"]["x"]
  local depth = schematic["size"]["z"]
  local height = schematic["size"]["y"]
  local possible_rotations = {"0", "90", "180", "270"}
  local rotation = possible_rotations[ math.random( #possible_rotations ) ]
  
  if rot ~= "-1" then
	rotation = rot
  end
  
  towns_gambit.foundation(pos, width, depth, height, rotation)
	
  -- place schematic
  local temp_pos = pos
  temp_pos.y = pos.y + offset
  
  minetest.after(8, function() --increase waiting time, if "block not found" in debug.txt
      minetest.place_schematic(temp_pos, 
        schematic, 
        rotation, 
        nil, 
		"place_center_x, place_center_z",
        true)
      -- initialize special nodes (chests, furnace)
      minetest.after(2, towns_gambit.initialize_nodes, pos, width, depth, height)
    end)
end
--
-- placing buildings in circles around center
--
function towns_gambit.place_settlement_circle(minp, maxp)
  -- find center of chunk
  local center = {
    x=maxp.x-towns_gambit_half_map_chunk_size, 
    y=maxp.y-towns_gambit_half_map_chunk_size, 
    z=maxp.z-towns_gambit_half_map_chunk_size
  } 
  -- find center_surcafe of chunk
  local center_surface = towns_gambit.find_surface(center)
  -- go build settlement around center
  if center_surface then
    -- add settlement to list
    table.insert(towns_gambit_settled_areas_in_world, 
      center_surface)
    -- save list to file
    towns_gambit.save()
    -- initialize all settlement information
    towns_gambit.initialize_settlement()
    -- build well in the center
    building_all_info = towns_gambit_schematic_table2[1]
    towns_gambit.build_schematic(center_surface, 
      building_all_info["mts"],
      building_all_info["rplc"], 
      building_all_info["name"],
	  building_all_info["rot"],
	  building_all_info["off"])
    -- add to settlement info table
    local index = 1
    towns_gambit_settlement_info[index] = {pos = center_surface, 
      name = building_all_info["name"], 
      hsize = building_all_info["hsize"]}
    --increase index for following buildings
    index = index + 1
    -- now some buildings around in a circle, radius = size of town center
    local x, z, r = center_surface.x, center_surface.z, building_all_info["hsize"]
    -- draw j circles around center and increase radius by math.random(2,5)
    for j = 1,20 do
      if number_built < number_of_buildings  then 
        -- set position on imaginary circle
        for j = 0, 360, 15 do
          local angle = j * math.pi / 180
          local ptx, ptz = x + r * math.cos( angle ), z + r * math.sin( angle )
          local pos1 = { x=ptx, y=center_surface.y, z=ptz}
          --
          local pos_surface = towns_gambit.find_surface(pos1)
          if pos_surface 
          then
            if towns_gambit.pick_next_building(pos_surface) 
            then
              towns_gambit.build_schematic(pos_surface, 
                building_all_info["mts"],
                building_all_info["rplc"], 
                building_all_info["name"],
				building_all_info["rot"],
				building_all_info["off"])
              number_built = number_built + 1
              towns_gambit_settlement_info[index] = {pos = pos_surface, 
                name = building_all_info["name"], 
                hsize = building_all_info["hsize"]}
              index = index + 1
              if number_of_buildings == number_built 
              then
                break
              end
            end
          else
            break
          end
        end
        r = r + math.random(2,5)
      end
    end
    if towns_gambit.debug == true
    then
      minetest.chat_send_all("really ".. number_built)
    end
    minetest.after(2, towns_gambit.paths)
--    towns_gambit.paths()
  end
end
function towns_gambit.initialize_settlement()
  -- towns_gambit_settlement_info table reset
  for k,v in pairs(towns_gambit_settlement_info) do
    towns_gambit_settlement_info[k] = nil
  end
  -- count_buildings table reset
  for k,v in pairs(towns_gambit_schematic_table2) do
--    local name = schematic_table[v]["name"]
    count_buildings[v["name"]] = 0
  end

  -- randomize number of buildings
  number_of_buildings = math.random(45,90)
  number_built = 1
  if towns_gambit.debug == true
  then
    minetest.chat_send_all("settlement ".. number_of_buildings)
  end
end
--
-- everything necessary to pick a fitting next building
--
function towns_gambit.pick_next_building(pos_surface)
  local randomized_schematic_table = shuffle(towns_gambit_schematic_table2)
  --local randomized_schematic_table = towns_gambit_schematic_table
  -- pick schematic
  local size = #randomized_schematic_table
  for i = size, 1, -1 do
    -- already enough buildings of that type?
    if count_buildings[randomized_schematic_table[i]["name"]] < randomized_schematic_table[i]["max_num"]*number_of_buildings    then
      building_all_info = randomized_schematic_table[i]
      -- check distance to other buildings
      local distance_to_other_buildings_ok = towns_gambit.check_distance(pos_surface, 
        building_all_info["hsize"])
      if distance_to_other_buildings_ok 
      then
        -- count built houses
        count_buildings[building_all_info["name"]] = count_buildings[building_all_info["name"]] +1
        return building_all_info["mts"]
      end
    end
  end
  return nil
end