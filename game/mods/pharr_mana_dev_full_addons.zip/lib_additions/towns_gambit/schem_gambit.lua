


--Air, Lava, and Water constants used throughout schematics
	local __ = {name = "air", param2 = 0, prob = 0}
	local wt = {name = "default:river_water_source", param2 = 0, prob = 254}
	local lv = {name = "default:lava_source", param2 = 0, prob = 254}
	local lf = {name = "default:lava_flowing", param2 = 0, prob = 254}
	
--Node Definitions
	local M0 = {name = "lib_materials:stone", param2 = 0, prob = 254}
	local M1 = {name = "lib_materials:stone_cobble", param2 = 0, prob = 254}
	local M2 = {name = "lib_materials:stone_brick", param2 = 0, prob = 254}

	local N0 = {name = "lib_materials:stone_sand", param2 = 0, prob = 254}
	local N1 = {name = "lib_materials:sand", param2 = 0, prob = 254}
	local N2 = {name = "lib_materials:stone_gravel", param2 = 0, prob = 254}
	local N3 = {name = "lib_materials:stone_cobble_mossy", param2 = 0, prob = 254}
	local N4 = {name = "lib_materials:stone_brick_mossy", param2 = 0, prob = 254}
	local N5 = {name = "lib_materials:stone_tile", param2 = 0, prob = 254}
	local N6 = {name = "lib_materials:stone_tile_with_dirt", param2 = 0, prob = 254}
	local N7 = {name = "lib_materials:stone_tile_mossy", param2 = 0, prob = 254}
	local N8 = {name = "lib_materials:stone_tile_crumbled", param2 = 0, prob = 254}

	local N9 = {name = "default:wood", param2 = 0, prob = 254}
	local NY = {name = "default:tree", param2 = 0, prob = 254}
	local NZ = {name = "default:tree", param2 = 4, prob = 254}
	local NX = {name = "default:tree", param2 = 8, prob = 254}

	local S0 = {name = "stairs:stair_wood", param2 = 0, prob = 254}
	local S1 = {name = "stairs:stair_wood", param2 = 1, prob = 254}
	local S2 = {name = "stairs:stair_wood", param2 = 2, prob = 254}
	local S3 = {name = "stairs:stair_wood", param2 = 3, prob = 254}
	local S4 = {name = "stairs:stair_wood", param2 = 20, prob = 254}
	local S6 = {name = "stairs:stair_wood", param2 = 21, prob = 254}
	local S7 = {name = "stairs:stair_wood", param2 = 22, prob = 254}
	local S8 = {name = "stairs:stair_wood", param2 = 23, prob = 254}
	local SN = {name = "stairs:slab_wood", param2 = 0, prob = 254}
	local SE = {name = "stairs:slab_wood", param2 = 1, prob = 254}
	local SW = {name = "stairs:slab_wood", param2 = 2, prob = 254}
	local S0 = {name = "stairs:slab_wood", param2 = 3, prob = 254}
	
	local Q0 = {name = "stairs:stair_cobble", param2 = 0, prob = 254}
	local Q1 = {name = "stairs:stair_cobble", param2 = 1, prob = 254}
	local Q2 = {name = "stairs:stair_cobble", param2 = 2, prob = 254}
	local Q3 = {name = "stairs:stair_cobble", param2 = 3, prob = 254}
	local Q5 = {name = "stairs:stair_cobble", param2 = 20, prob = 254}
	local Q6 = {name = "stairs:stair_cobble", param2 = 21, prob = 254}
	local Q7 = {name = "stairs:stair_cobble", param2 = 22, prob = 254}
	local Q8 = {name = "stairs:stair_cobble", param2 = 23, prob = 254}
	local QN = {name = "stairs:slab_cobble", param2 = 0, prob = 254}
	local QE = {name = "stairs:slab_cobble", param2 = 1, prob = 254}
	local QW = {name = "stairs:slab_cobble", param2 = 2, prob = 254}
	local QS = {name = "stairs:slab_cobble", param2 = 3, prob = 254}
	
	local FF = {name = "farming:soil_wet", param2 = 0, prob = 254}
	local CC = {name = "farming:cotton_8", param2 = 0, prob = 254}
	
	local DD = {name = "default:dirt", param2 = 0, prob = 254}
	local GR = {name = "default:dirt_with_grass", param2 = 0, prob = 254}
	local G1 = {name = "default:glass", param2 = 0, prob = 254}

	local F0 = {name = "default:furnace", param2 = 0, prob = 254}
	local F1 = {name = "default:furnace", param2 = 1, prob = 254}
	local F2 = {name = "default:furnace", param2 = 2, prob = 254}
	local F3 = {name = "default:furnace", param2 = 3, prob = 254}

	local C0 = {name = "default:chest", param2 = 0, prob = 254}
	local C1 = {name = "default:chest", param2 = 1, prob = 254}
	local C2 = {name = "default:chest", param2 = 2, prob = 254}
	local C3 = {name = "default:chest", param2 = 3, prob = 254}

	local L0 = {name = "default:ladder_wood", param2 = 0, prob = 254}
	local L1 = {name = "default:ladder_wood", param2 = 1, prob = 254}
	local L2 = {name = "default:ladder_wood", param2 = 2, prob = 254}
	local L3 = {name = "default:ladder_wood", param2 = 3, prob = 254}
	local L4 = {name = "default:ladder_wood", param2 = 4, prob = 254}
	local L5 = {name = "default:ladder_wood", param2 = 5, prob = 254}

	local B0 = {name = "beds:bed_bottom", param2 = 0, prob = 254}
	local B1 = {name = "beds:bed_bottom", param2 = 1, prob = 254}
	local B2 = {name = "beds:bed_bottom", param2 = 2, prob = 254}
	local B3 = {name = "beds:bed_bottom", param2 = 3, prob = 254}
	local B5 = {name = "beds:bed_top", param2 = 0, prob = 254}
	local B6 = {name = "beds:bed_top", param2 = 1, prob = 254}
	local B7 = {name = "beds:bed_top", param2 = 2, prob = 254}
	local B8 = {name = "beds:bed_top", param2 = 3, prob = 254}
	local BN = {name = "default:bookshelf", param2 = 0, prob = 254}
	local BE = {name = "default:bookshelf", param2 = 1, prob = 254}
	local BS = {name = "default:bookshelf", param2 = 2, prob = 254}
	local BW = {name = "default:bookshelf", param2 = 3, prob = 254}

	local DR = {name = "lib_doors:tree_default_wood_door_centered_300_height_150_width_right", param2 = 1, prob = 254}
	local DL = {name = "lib_doors:tree_default_wood_door_centered_300_height_150_width", param2 = 1, prob = 254}
	local D0 = {name = "lib_doors:tree_default_wood_door_centered_with_window", param2 = 0, prob = 254}
	local D1 = {name = "lib_doors:tree_default_wood_door_centered_with_window", param2 = 1, prob = 254}
	local D2 = {name = "lib_doors:tree_default_wood_door_centered_with_window", param2 = 2, prob = 254}
	local D3 = {name = "lib_doors:tree_default_wood_door_centered_with_window", param2 = 3, prob = 254}
	local D5 = {name = "doors:trapdoor", param2 = 0, prob = 254}
	local D6 = {name = "doors:trapdoor", param2 = 1, prob = 254}
	local D7 = {name = "doors:trapdoor", param2 = 2, prob = 254}
	local D8 = {name = "doors:trapdoor", param2 = 3, prob = 254}

	local TC = {name = "default:torch_ceiling", param2 = 0, prob = 254}
	local T0 = {name = "default:torch", param2 = 1, prob = 254}
	local T1 = {name = "default:torch_wall", param2 = 1, prob = 254}
	local T2 = {name = "default:torch_wall", param2 = 2, prob = 254}
	local T3 = {name = "default:torch_wall", param2 = 3, prob = 254}
	local T4 = {name = "default:torch_wall", param2 = 4, prob = 254}
	local T5 = {name = "default:torch_wall", param2 = 5, prob = 254}

	
	local II = {name = "default:fence_wood",param2 = 0,prob = 254}

	
towns_gambit.schem_gambit_cemetary_x15_y4_z11_180 = {
	size = {x = 15,y = 4,z = 11},
	data = { NY, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, NY, __, NY, II, II, II, II, II, II, II, II, II, II, II, II, NY, __, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, __, M1, Q3, __, __, __, __, __, __, __, __, __, __, Q1, M1, __, M1, __, __, __, __, __, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, __, __, __, M1, __, II, __, __, __, __, __, __, __, __, __, __, __, __, II, __, M1, __, __, T5, __, __, __, __, T5, __, __, __, __, M1, __, Q2, __, __, __, __, __, __, __, __, __, __, __, __, Q2, __, M1, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, __, __, __, __, __, __, __, __, __, M1, __, II, __, __, __, __, __, __, __, __, __, __, __, __, II, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, __,
		{param2 = 3,name = "stairs:stair_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 0,name = "default:junglegrass",prob = 254}, __,
		{param2 = 3,name = "stairs:stair_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254}, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, M1, __, II, __, __, __, __, __, __, __, __, __, __, __, __, II, __, M1, __, __, __, __, __, __, __, __, __, __, __, T2, M1, T3, __, __, __, __, __, __, __, __, __, __, __, __, __, Q0, __, M1, __, __, __, __, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, __, __, __, __, NY, __, II, __, __, __, __, __, __, __, __, __, __, __, __, NY,
		{param2 = 3,name = "default:sign_wall",prob = 254}, M1, __, __, __, __, __, __, __, __, __, __, __, Q1, NY, Q3, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, __, __,
		{param2 = 3,name = "stairs:stair_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254}, __, __,
		{param2 = 3,name = "stairs:stair_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254}, __, __, __, __,
		{param2 = 1,name = "doors:door_wood_b_1",prob = 254}, __, II, __, __, __, __, __, __, __, __, __, __, __, __,
		{param2 = 1,name = "doors:door_wood_t_1",prob = 254}, __, M1, __, __, __, __, __, __, __, __, __, __, __, Q1, NY, Q3, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, __, NY, __, II, __, __, __, __, __, __, __, __, __, __, __, __, NY, __, M1, __, __, __, __, __, __, __, __, __, __, __, Q1, NY, Q3, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, __, __,
		{param2 = 3,name = "stairs:stair_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254}, __, __,
		{param2 = 3,name = "stairs:stair_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254}, __, __, __, __, M1, __, II, __, __, __, __, __, __, __, __, __, __, __, __, II, __, M1, __, __, __, __, __, __, __, __, __, __, __, T2, M1, T3, __, __, __, __, __, __, __, __, __, __, __, __, __, Q2, __, M1, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, __, __, __, __, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, M1, __, II, __, __, __, __, __, __, __, __, __, __, __, __, II, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, __, __, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, __, __, __, __, __, M1, __, II, __, __, __, __, __, __, __, __, __, __, __, __, II, __, M1, __, __, T4, __, __, __, __, T4, __, __, __, __, M1, __, Q0, __, __, __, __, __, __, __, __, __, __, __, __, Q0, __, NY, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, NY, __, NY, II, II, II, II, II, II, II, II, II, II, II, II, NY, __, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, __, M1, Q3, __, __, __, __, __, __, __, __, __, __, Q1, M1, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254}
	}
}

towns_gambit.schem_gambit_church_x16_y9_z11_180 = {
	size = {x = 16,y = 9,z = 11},
	data = { __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, NY, II, II, II, II, II, II, II, II, II, II, II, NY, __, __, __, NY, M1, Q0, M1, Q0, M1, Q0, M1, Q0, M1, Q0, M1, NY, __, __, __, NY, N9, G1, N9, G1, N9, G1, N9, G1, N9, G1, N9, NY, __, __, __, NY, N9, G1, N9, G1, N9, G1, N9, G1, N9, G1, N9, NY, __, __, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, __, M1,
		{param2 = 0,name = "wool:red",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254}, QW, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __, M1, __, __, __, N9,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, T5, __, __, __, T5, __, __, __, T5, N9, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, __, N9, __, T5, __, __, T5, __, __, __, T5, __, __, N9, __, __, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, __, M1,
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254}, QW, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __, M1, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, Q0, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, M1, M1, Q3, __, M1,
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 0,name = "wool:red",prob = 254}, QW, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __, M1, M1, __, __, N9, __, __, QW, __, __, __, __, __, __, __, __, M1, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, M1, T3, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, Q0, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9,
		{param2 = 0,name = "wool:red",prob = 254},
		{param2 = 0,name = "wool:red",prob = 254},
		{param2 = 0,name = "wool:red",prob = 254},
		{param2 = 0,name = "wool:red",prob = 254},
		{param2 = 0,name = "wool:red",prob = 254},
		{param2 = 0,name = "wool:red",prob = 254}, N9, M1, M1, Q3, __, M1,
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 0,name = "wool:red",prob = 254}, QW, __, __, __, __, __, __, __,
		{param2 = 1,name = "doors:door_wood_b_1",prob = 254}, __, __, __, N9, __, __, QW, __, __, __, __, __, __, __, __,
		{param2 = 1,name = "doors:door_wood_t_1",prob = 254}, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, M1, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, M1, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, M1, M1, Q3, __, M1,
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 0,name = "wool:red",prob = 254}, QW, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __, M1, M1, __, __, N9, __, __, QW, __, __, __, __, __, __, __, __, M1, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, M1, T3, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, Q2, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, __, M1,
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254}, QW, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __, M1, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, Q2, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, __, M1,
		{param2 = 0,name = "wool:red",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254},
		{param2 = 3,name = "stairs:slab_stone",prob = 254}, QW, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __,
		{param2 = 1,name = "stairs:stair_stone",prob = 254}, __, M1, __, __, __, N9,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, T4, __, __, __, T4, __, __, __, T4, N9, __, __, __, N9, __, __, __, __, __, __, __, __, __, __, __, N9, __, __, __, N9, __, T4, __, __, T4, __, __, __, T4, __, __, N9, __, __, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, NY, II, II, II, II, II, II, II, II, II, II, II, NY, __, __, __, NY, M1, Q2, M1, Q2, M1, Q2, M1, Q2, M1, Q2, M1, NY, __, __, __, NY, N9, G1, N9, G1, N9, G1, N9, G1, N9, G1, N9, NY, __, __, __, NY, N9, G1, N9, G1, N9, G1, N9, G1, N9, G1, N9, NY, __, __, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254},
		{ypos = 4,prob = 254},
		{ypos = 5,prob = 254},
		{ypos = 6,prob = 254},
		{ypos = 7,prob = 254},
		{ypos = 8,prob = 254}
	}
}

towns_gambit.schem_gambit_field_x7_y3_z7_90 = {
	size = {x = 7,y = 3,z = 7},
	data = { N2, N2, N2, N2, N2, N2, N2, NY,
		{param2 = 0,name = "stairs:slab_wood",prob = 254},
		{param2 = 0,name = "stairs:slab_wood",prob = 254}, NY,
		{param2 = 0,name = "stairs:slab_wood",prob = 254},
		{param2 = 0,name = "stairs:slab_wood",prob = 254}, NY, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, DD, DD, NY, NY, NY, NY, NY, NY, NY, II, __, __, II, __, __, II, DD, DD, DD, DD, DD, DD, DD, NY, FF, FF, wt, FF, FF, NY, II, CC, CC, __, CC, CC, II, DD, DD, DD, DD, DD, DD, DD, NY, FF, FF, wt, FF, FF, NY, II, CC, CC, __, CC, CC, II, DD, DD, DD, DD, DD, DD, DD, NY, FF, FF, wt, FF, FF, NY, II, CC, CC, __, CC, CC, II, DD, DD, DD, DD, DD, DD, DD, NY, FF, FF, wt, FF, FF, NY, II, CC, CC, __, CC, CC, II, DD, DD, DD, DD, DD, DD, DD, NY, NY, NY, NY, NY, NY, NY, II, II, II, II, II, II, II
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254}
	}
}

towns_gambit.schem_gambit_forge_x10_y7_z7_270 = {
	size = {x = 10,y = 7,z = 7},
	data = { M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, M0, GR, M1, M1, M1, M1, M1, M1, M1, M1, M1, __, M1, M0, M0, M0, M0, M0, M0, M0, M1, __, M1, M0, M0, M0, M0, M0, M0, M0, M1, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, __, __, __, __, __, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, N2, N2, N2, N2, N2, M1, M1, M1, M0, M1, F2, __, __, __, __, Q1, M1, M1, M1, M0, F2, __, __, __, __, __, M1, M1, M1, M1, __, __, __, __, __, __, __, M1, __, M0, M0, M0, M0, M0, M0, M0, M0, M1, __, __, __, __, __, __, __, __, __, M1, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, N2, N2, N2, N2, N2, M1, M1, M1, M0, M1, __, __,
		{param2 = 22,name = "stairs:stair_stone",prob = 254}, __, __, Q1,
		{param2 = 7,name = "default:lava_flowing",prob = 254},
		{param2 = 0,name = "default:lava_source",prob = 254}, M1, II, __, __, __, __, __, __,
		{param2 = 23,name = "stairs:slab_cobble",prob = 254}, __, M1, M1, __, __, __, __, __, __, M1, __, M1, M0, M0, M0, M0, M0, M0, M0, M1, __, M1, __, __, __, __, __, __, __, M1, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, N2, N2, N2, N2, N2, M1, M1, M1, M0, M1, __, __,
		{param2 = 20,name = "stairs:stair_stone",prob = 254}, __, __, Q1,
		{param2 = 7,name = "default:lava_flowing",prob = 254},
		{param2 = 0,name = "default:lava_source",prob = 254}, M1, II, __, __, __, __, __, __,
		{param2 = 23,name = "stairs:slab_cobble",prob = 254}, __, M1, M1, __, __, __, __, __, __, M1, __, M1, M0, M0, M0, M0, M0, M0, M0, M1, __, M1, __, __, __, __, __, __, __, M1, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, N2, N2, N2, N2, N2, M1, M1, M1, M0, M1, __, __, __, __, __, Q1, M1, M1, M1, M0, __, __, __, __, __, __, M1, M1, M1, M1, __, __, __, __, __, __, __, M1, __, M0, M0, M0, M0, M0, M0, M0, M0, M1, __, __, __, __, __, __, __, __, __, M1, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, N2, N2, N2, N2, N2, N2, M1, M0, GR, M1, __, __, __, M1, M1, M1, M1, M1, __, M1, __, __, __, II, QW, QW, QW, M1, __, M1, __, __, __, II, __, __, __, M1, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, __, __, __, __, __, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, GR, N2, N2, N2, GR, GR, GR, GR, GR, GR, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, T5, __, __, __, __, __, __, __, T5, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254},
		{ypos = 4,prob = 254},
		{ypos = 5,prob = 254},
		{ypos = 6,prob = 254}
	}
}

towns_gambit.schem_gambit_fountain_x5_y5_z5_90 = {
	size = {x = 5,y = 5,z = 5},
	data = { M0, M0, M0, M0, M0, M1, QW, QW, QW, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, M1, M1, M1, M0, QW,
		{param2 = 6,name = "default:water_flowing",prob = 254},
		{param2 = 7,name = "default:water_flowing",prob = 254},
		{param2 = 6,name = "default:water_flowing",prob = 254}, QW, __, __,
		{param2 = 15,name = "default:water_flowing",prob = 254}, __, __, __, __,
		{param2 = 15,name = "default:water_flowing",prob = 254}, __, __, __, __, __, __, __, M0, M1, M1, M1, M0, QW,
		{param2 = 7,name = "default:water_flowing",prob = 254}, M1,
		{param2 = 7,name = "default:water_flowing",prob = 254}, QW, __,
		{param2 = 15,name = "default:water_flowing",prob = 254}, M1,
		{param2 = 15,name = "default:water_flowing",prob = 254}, __, __,
		{param2 = 15,name = "default:water_flowing",prob = 254}, wt,
		{param2 = 15,name = "default:water_flowing",prob = 254}, __, __, __, __, __, __, M0, M1, M1, M1, M0, QW,
		{param2 = 6,name = "default:water_flowing",prob = 254},
		{param2 = 7,name = "default:water_flowing",prob = 254},
		{param2 = 6,name = "default:water_flowing",prob = 254}, QW, __, __,
		{param2 = 15,name = "default:water_flowing",prob = 254}, __, __, __, __,
		{param2 = 15,name = "default:water_flowing",prob = 254}, __, __, __, __, __, __, __, M0, M1, M1, M1, M0, M1, QW, QW, QW, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254},
		{ypos = 4,prob = 254}
	}
}

towns_gambit.schem_gambit_house_x9_y7_z11_0 = {
	size = {x = 9,y = 7,z = 11},
	data = { __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, S1, __, __, __, __, __, __, S3, __, __, S1, __, __, __, __, S3, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, S1, S3, __, __, __, __, __, NY, II, II, II, II, NY, __, __, __, NY, M1, M1, M1, M1, NY, __, __, __, NY, N9, G1, G1, N9, NY, __, __, S1, NY, N9, N9, N9, N9, NY, S3, __, __, S1, N9, N9, N9, N9, S3, __, __, __, __, S1, N9, N9, S3, __, __, __, __, __, __, S1, S3, __, __, __, __, __, II, N9, N9, N9, N9, II, __, __, __, M1, M1, __, __, __, M1, __, __, __, N9, II, __, __, __, N9, __, __, S1, N9, QW, __, __, __, N9, S3, __, __, S1, __, __, __, __, S3, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, S1, S3, __, __, __, __, __, II, N9, N9, N9, N9, II, __, __, __, M1, F3, __, __, __, M1, __, __, __, G1, __, __, __, __, G1, __, __, S1, N9, QW, __, __, __, N9, S3, __, __, S1, __, __, __, __, S3, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, S1, S3, __, __, __, __, __, II, N9, N9, N9, N9, II, __, __, __, M1, M1, __, __, __, M1, __, __, __, N9, II, __, __, __, G1, __, __, S1, N9, QW, __, __, __, N9, S3, __, __, S1, __, __, __, __, S3, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, S1, S3, __, __, __, __, __, II, N9, N9, N9, N9, II, __, __, __, M1, Q8, Q6, __, __, M1, __, __, T2, N9, T1, __, __, __, N9, __, __, S1, N9, QW, __, __, __, N9, S3, __, __, S1, __, __, __, __, S3, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, S1, S3, __, __, __, M1, M1, NY, N9, N9, N9, N9, II, __, Q1, M1, NY, __, __, __, __, M1, __, __, II, NY, __, __, __, __, G1, __, __, S1, N9, QW, __, __, __, N9, S3, __, __, S1, __, __, __, __, S3, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, S1, S3, __, __, __, Q1, M1, M1, N9, N9, N9, N9, II, __, __, __,
		{param2 = 3,name = "doors:door_wood_b_1",prob = 254}, __, __, __, __, M1, __, __, __,
		{param2 = 3,name = "doors:door_wood_t_1",prob = 254}, __, __, __, __, G1, __, __, S1, N9, QW, __, __, __, N9, S3, __, __, S1, __, __, __, __, S3, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, S1, S3, __, __, __, M1, M1, NY, N9, N9, N9, N9, II, __, Q1, M1, NY, II, __, __, II, M1, __, __, II, NY, II, __, __, II, N9, __, __, S1, N9, QW, QW, QW, QW, N9, S3, __, __, S1, __, __, __, __, S3, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, S1, S3, __, __, __, __, __, NY, II, II, II, II, NY, __, __, __, NY, M1, M1, M1, M1, NY, __, __, __, NY, N9, G1, G1, N9, NY, __, __, S1, NY, N9, N9, N9, N9, NY, S3, __, __, S1, N9, N9, N9, N9, S3, __, __, __, __, S1, N9, N9, S3, __, __, __, __, __, __, S1, S3, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, S1, __, __, __, __, __, __, S3, __, __, S1, __, __, __, __, S3, __, __, __, __, S1, __, __, S3, __, __, __, __, __, __, S1, S3, __, __, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254},
		{ypos = 4,prob = 254},
		{ypos = 5,prob = 254},
		{ypos = 6,prob = 254}
	}
}

towns_gambit.schem_gambit_lamp_x3_y4_z3_270 = {
	size = {x = 3,y = 4,z = 3},
	data = {
		__, __, __, __, __, __, __, __, __, __, T4, __, __, II, __, __, II, __, __, II, __, T2,
		{param2 = 0,name = "wool:black",prob = 254}, T3, __, __, __, __, __, __, __, __, __, __, T5, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254}
	}
}

towns_gambit.schem_gambit_library_hotel_x12_y9_z18_180 = {
	size = {x = 12,y = 9,z = 18},
	data = { __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, Q1, __, __, __, __, __, __, __, __, __, __, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, NY, II, II, II, II, II, II, II, II, NY, __, __, NY, M1, M1, M1, M1, M1, M1, M1, M1, NY, __, __, NY, N9, N9, N9, N9, N9, N9, N9, N9, NY, __, __, NY, N9, N9, N9, N9, N9, N9, N9, N9, NY, __, __, NY, N9, N9, N9, N9, N9, N9, N9, N9, NY, __, __, NY, N9, N9, N9, N9, N9, N9, N9, N9, NY, __, __, NY, N9, N9, N9, N9, N9, N9, N9, N9, NY, __, Q1, NY, N9, N9, N9, N9, N9, N9, N9, N9, NY, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, M1,
		{param2 = 4,name = "default:sign_wall",prob = 254}, __, L2, BN, N9, N9, N9, N9, M1, __, __, N9, __, __, L2, BN, N9, Q3, __, __, N9, __, __, N9, T5, __, __, BN, Q3, __, __, __, N9, __, __, N9, N9, N9, N9, Q3, __, __, __, __, N9, Q3, __, N9, M1, __, __, __, __, __, __, Q3, N9, __, __, N9,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, __, __, __, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, N9, __, Q1, N9, __, __, __, __, __, __, __, __, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, M1, S3, __, __, BN, N9, N9, N9, N9, M1, __, __, N9, __, __, __, BN, N9, Q3, __, __, N9, __, __, N9, __, __, __, BN, Q3, __, __, __, N9, __, __, N9, N9, N9, N9, Q3, __, __, __, __, N9, Q3, __, N9, __, __, __, __, __, __, __, Q3, N9, __, __, N9, __, __, __, __, __, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, N9, __, Q1, N9, __, __, __, __, __, __, __, __, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, M1, S3, __, __, NY, NY, NY, Q2, Q2, M1, __, __, N9, __, __, __, NY, NY, NY, __, __, N9, __, __, N9, __, __, __, NY, NY, NY, __, __, N9, __, __, N9, N9, N9, N9, NY, NY, NY, NY, NY, N9, Q3, __, N9, __, __, __, NY, N9, N9, N9, N9, N9, __, __, N9, __, __, T2, NY, N9, N9, N9, N9, N9, __, Q1, N9, __, __, __, NY, N9, N9, N9, N9, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, M1,
		{param2 = 5,name = "default:sign_wall",prob = 254}, __, __, __, __, __, __, __, M1, __, __, N9, __, __, __, __, __, __, __, __, N9, __, __, N9, __, __, __, __, __, __, __, __, N9, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, Q3, __, N9, __, __, __, M1, Q3,
		{param2 = 3,name = "stairs:slab_sandstone",prob = 254},
		{param2 = 3,name = "stairs:slab_sandstone",prob = 254}, __, N9, __, __, N9, __, __, __, N9, __, __, __, __, N9, __, Q1, N9, __, __, __, N9, __, __, __, __, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, M1, __, __, __, __,
		{param2 = 4,name = "default:sign_wall",prob = 254}, __, __,
		{param2 = 4,name = "default:sign_wall",prob = 254}, M1, __, __, N9, __, __, __, __, __, __, __, __, N9, __, __, N9, __, __, __, __, __, __, __, __, N9, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, Q3, __, N9, __, __, __, M1, Q3,
		{param2 = 3,name = "stairs:slab_sandstone",prob = 254},
		{param2 = 3,name = "stairs:slab_sandstone",prob = 254}, __, S3, __, __, N9, __, __, __, N9, __, __, __, __, G1, __, Q1, N9, __, __, __, N9, __, __, __, __, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, M1, BN, __, __, Q5, S3, __, __, S1, Q3, __, __, N9, T1, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, __, __, __, G1, __, __, N9, __, __, __, __, __, __, __, __, N9, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, Q3, __, N9, __, __, __, M1, __, __, __, __, S3, __, __, N9, __, __, __, N9, __, __, __, __, G1, __, Q1, N9, __, __, __, N9, __, __, __, __, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, M1, BN, __, __,
		{param2 = 23,name = "stairs:slab_cobble",prob = 254}, S3, __, __, S1, Q3, __, __, N9, __, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, __, __, __, G1, __, __, N9, __, __, __, __, __, __, __, __, N9, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, Q3, __, N9, __, __, __,
		{param2 = 1,name = "doors:door_wood_b_1",prob = 254}, __, __, __, __, S3, __, __, N9, __, __, __,
		{param2 = 1,name = "doors:door_wood_t_1",prob = 254}, __, __, __, __, G1, __, Q1, N9, __, __, __, N9, __, __, __, __, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, M1, BN, __, __, Q7, S3, __, __, S1, Q3, __, __, N9, T1, __, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, __, __, __, G1, __, __, N9, __, __, __, __, __, __, __, __, N9, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, Q3, __, N9, __, __, __, M1,
		{param2 = 2,name = "default:sign_wall",prob = 254}, S0,
		{param2 = 3,name = "default:sign_wall",prob = 254}, BN, N9, __, __, N9, __, __, __, N9, __, __, __, T1, N9, __, Q1, N9, __, __, __, N9, __, __, __, __, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, II, __, __, M1, __, __, __, __,
		{param2 = 5,name = "default:sign_wall",prob = 254}, __, __,
		{param2 = 5,name = "default:sign_wall",prob = 254}, M1, __, __, N9, __, __, __, __, __, __, __, T4, N9, __, __, N9, __, __, __, __, __, __, __, __, N9, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, Q3, __, N9, __, __, __, NY, M1, M1, M1, M1, N9, __, __, N9, __, __, T2, NY, N9, N9, N9, N9, N9, __, Q1, N9, __, __, __, NY, N9, N9, N9, N9, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, NY, __, __, M1, __, __, NY, __, __, __, M1, M1, NY, __, __, N9, __, __, NY, __, __, __, M1, M1, NY, T3, __, N9, __, __, NY, __, __, __, M1, M1, NY, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, Q3, __, N9, __, __, __, M1,
		{param2 = 2,name = "default:sign_wall",prob = 254}, S2,
		{param2 = 3,name = "default:sign_wall",prob = 254}, BN, N9, __, __, N9, __, __, __, N9, __, __, __, T1, N9, __, Q1, N9, __, __, __, N9, __, __, __, __, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, NY, N9, S3, __, __, M1, __, __, Q5, __, __, __, NY, __, __, __, __, N9, __, __, __, __, __, __, NY, __, __, __, __, N9, __, __, II, __, __, __, NY, T3, __, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, Q3, __, N9, __, __, __,
		{param2 = 1,name = "doors:door_wood_b_1",prob = 254}, __, __, __, __, S3, __, __, N9, __, __, __,
		{param2 = 1,name = "doors:door_wood_t_1",prob = 254}, __, __, __, __, G1, __, Q1, N9, __, __, __, N9, __, __, __, __, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, S3, __, __, M1, __, __,
		{param2 = 23,name = "stairs:slab_cobble",prob = 254}, __, __, __,
		{param2 = 1,name = "doors:door_wood_b_1",prob = 254}, __, __, __, __, N9, __, __, __, __, __, __,
		{param2 = 1,name = "doors:door_wood_t_1",prob = 254}, __, __, __, __, N9, __, __, II, __, __, __, M1, __, __, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, Q3, __, N9, __, __, __, M1, __, __, __, __, S3, __, __, N9, __, __, __, N9, __, __, __, __, G1, __, Q1, N9, __, __, __, N9, __, __, __, __, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, NY, N9, S3, __, __, M1, __, __, Q7, __, __, __, NY, __, __, __, __, N9, __, __, __, __, __, __, NY, __, __, __, __, N9, __, __, II, __, __, __, NY, T3, __, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, Q3, __, N9, __, __, __, M1, Q3,
		{param2 = 3,name = "stairs:slab_sandstone",prob = 254},
		{param2 = 3,name = "stairs:slab_sandstone",prob = 254}, __, S3, __, __, N9, __, __, __, N9, __, __, __, __, G1, __, Q1, N9, __, __, __, N9, QW, QW, QW, __, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, II, N9, N9, N9, N9, N9, N9, N9, N9, S3, __, __, M1, BN, BN, NY, Q0, Q0, Q0, M1, __, __, __, __, N9, __, __, NY, __, __, __, N9,
		{param2 = 3,name = "default:sign_wall",prob = 254}, __, __, __, N9, __, T2, NY, __, __, __, M1, __, __, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, N9, Q3, __, N9, __, M1, __, M1, Q3,
		{param2 = 3,name = "stairs:slab_sandstone",prob = 254},
		{param2 = 3,name = "stairs:slab_sandstone",prob = 254}, __, N9, __, __, N9, __,
		{param2 = 0,name = "default:junglegrass",prob = 254}, __, N9, __, __, __, __, N9, __, Q1, N9, T3, __, T2, N9, QW, QW, QW, __, N9, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, NY, II, II, II, II, II, II, NY, N9, NY, __, __, NY, M1, M1, M1, Q2, Q2, Q2, NY, II, NY, __, __, NY, N9, N9, N9, G1, G1, G1, NY, II, NY, T3, __, NY, N9, N9, N9, N9, N9, N9, NY, M1, NY, __, __, NY, N9, N9, N9, N9, N9, N9, N9, N9, NY, __, __, NY, N9, N9, N9, N9, N9, N9, N9, N9, NY, __, __, NY, N9, N9, N9, N9, N9, N9, N9, N9, NY, __, Q1, NY, N9, N9, N9, N9, N9, N9, N9, N9, NY, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, Q1, __, __, __, __, __, __, __, __, __, __, Q3, __, QW, QW, QW, QW, QW, QW, QW, QW, QW, QW, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254},
		{ypos = 4,prob = 254},
		{ypos = 5,prob = 254},
		{ypos = 6,prob = 254},
		{ypos = 7,prob = 254},
		{ypos = 8,prob = 254}
	}
}

towns_gambit.schem_gambit_pub_x10_y6_z13_0 = {
	size = {x = 10,y = 6,z = 13},
	data = { __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, SW, S0, S0, S0, S0, S0, S0, S0, S0, SW, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, NY, II, II, II, II, II, II, NY, __, __, NY, M1, M1, M1, M1, M1, M1, NY, __, __, NY, N9, N9, N9, G1, G1, N9, NY, __, S1, NY, N9, N9, N9, N9, N9, N9, NY, S3, __, SW, S0, S0, S0, S0, S0, S0, SW, __, __, __, __, __, __, __, __, __, __, __, __, M1, N9, N9, N9, N9, N9, N9, II, __, __, N9, BN, __,
		{param2 = 2,name = "default:sign_wall",prob = 254}, S2,
		{param2 = 3,name = "default:sign_wall",prob = 254}, __, M1, __, __, N9, __, __, __, __, __, T2, N9, __, S1, N9, __, __, __, __, __, __, N9, S3, __, S1, QW, QW, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, M1, N9, N9, N9, N9, N9, N9, II, __, __, N9, BN, __, __, __, __, __, M1, __, __, N9, T4, __, __, __, __, __, N9, __, S1, N9, __, __, __, __, __, __, N9, S3, __, S1, QW, QW, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, NY, M1, NY, N9, N9, N9, N9, II, __, __, NY, N9, NY, Q8,
		{param2 = 23,name = "stairs:slab_cobble",prob = 254},
		{param2 = 23,name = "stairs:slab_cobble",prob = 254}, Q6, M1, __, __, NY, N9, NY, __, __, __, __, N9, __, S1, NY, N9, NY, QW, QW, QW, QW, N9, S3, __, SW, S2, N9, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, __, __, S1, N9, N9, N9, N9, II, __, __, T5,
		{param2 = 5,name = "default:sign_wall",prob = 254}, __, __, __, __, __, M1, __, __, __, __, __, __, __, __, __, N9, __, SW, S2, N9, __, __, __, __, __, N9, S3, __, __, __, S1, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, __, __, S1, N9, N9, N9, N9, II, __, __, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __, __, N9, __, __, __, S1, __, __, __, __, __, N9, S3, __, __, __, S1, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, __, __, S1, N9, N9, N9, N9, II, __, __, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __, __, N9, __, __, __, S1, __, __, __, __, __, N9, S3, __, __, __, S1, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, __, __, S1, N9, N9, N9, N9, II, __, __, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __, __, N9, __, __, __, S1, __, __, __, __, __, N9, S3, __, __, __, S1, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, __, __, S1, N9, N9, N9, N9, II, __, __, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __, __, N9, __, __, __, S1, __, __, __, __, __, N9, S3, __, __, __, S1, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, __, __, S1, N9, N9, N9, N9, II, __, __, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __, __, N9, __, __, __, S1, __, __, __, __, __, N9, S3, __, __, __, S1, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, __, __, NY, M1, M1, M1, M1, NY, __, __, __, T2, NY, M1, M1, M1, M1, NY, __, __, __, __, NY, II, II, II, II, NY, __, __, __, S1, NY, N9, N9, N9, N9, NY, S3, __, __, __, SW, S2, S2, S2, S2, SW, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, SW, S2, S2, S2, S2, S2, S2, SW, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254},
		{ypos = 4,prob = 254},
		{ypos = 5,prob = 254}
	}
}

towns_gambit.schem_gambit_shed_open_chests_x5_y5_z5_0 = {
	size = {x = 5,y = 5,z = 5},
	data = {
		DD, DD, DD, DD, DD,
		GR, DD, DD, DD, GR,
		II, NY, M1, NY, __,
		II, NY, N9, NY, __,
		S1, N9, N9, N9, S3,

		DD, DD, DD, DD, DD,
		N2, N2, DD, DD, GR,
		__, __, C1, N9, __,
		__, __, T5, N9, __,
		S1, N9, N9, N9, S3,

		DD, DD, DD, DD, DD,
		N2, N2, DD, DD, GR,
		__, __, C1, N9, __,
		__, __, __, N9, __,
		S1, N9, N9, N9, S3,

		DD, DD, DD, DD, DD,
		N2, N2, DD, DD, GR,
		__, __, C1, N9, __,
		__, __, T4, N9, __,
		S1, N9, N9, N9, S3,

		DD, DD, DD, DD, DD,
		GR, DD, DD, DD, GR,
		II, NY, M1, NY, __,
		II, NY, N9, NY, __,
		S1, N9, N9, N9, S3
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254},
		{ypos = 4,prob = 254}
	}
}

towns_gambit.schem_gambit_shop_x10_y6_z10_90 = {
	size = {x = 10,y = 6,z = 10},
	data = { __, __, __, __, __, __, __, __, __, __, __, T4, __, __, __, T4, __, __, __, __, __, __, __, __, __, __, __, __, __, __, SW, S0, S0, S0, S0, S0, S0, S0, S0, SW, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, NY, S0, S0, S0, NY, II, II, NY, __, __, NY, __, __, __, NY, M1, M1, NY, __, __, NY, __, __, __, NY, M1, M1, NY, __, S1, NY, N9, N9, N9, NY, N9, N9, NY, S3, __, SW, S0, S0, S0, S0, S0, S0, SW, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9, N9, N9, II, __, __, M1, __, __, __, NY, BN, BN, M1, __, __, N9, __, __,
		{param2 = 2,name = "default:sign_wall",prob = 254}, NY, BN, BN, N9, __, S1, N9, __, T5, __, Q1, __, __, N9, S3, __, S1, QW, QW, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9, N9, N9, II, __, __, M1, __, __, __,
		{param2 = 3,name = "doors:door_wood_b_1",prob = 254}, __, __, M1, __, __, N9, __, __, __,
		{param2 = 3,name = "doors:door_wood_t_1",prob = 254}, __, __, N9, __, S1, N9, __, __, __, Q1, __, __, N9, S3, __, S1, QW, QW, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9, N9, N9, II, __, __, M1, Q8,
		{param2 = 23,name = "stairs:slab_cobble",prob = 254}, Q6, NY, __, __, M1, __, __, N9, __, __, __, NY, __, __, N9, __, S1, N9, Q0, Q0, Q0, NY, __, __, N9, S3, __, S1, QW, QW, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9, N9, N9, II, __, __, M1, __, __, __, __, __, __, M1, __, __, N9, __, __, __, __, __, __, N9, __, S1, N9, T5, __, __, __, __, __, N9, S3, __, S1, QW, QW, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9, N9, N9, II, __, __, M1, __, __, __, __, __, __, M1, __, __, N9, __, __, __, __, __, __, N9, __, S1, N9, __, __, __, __, __, __, N9, S3, __, S1, QW, QW, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9, N9, N9, II, __, __, M1, Q8,
		{param2 = 23,name = "stairs:slab_cobble",prob = 254},
		{param2 = 23,name = "stairs:slab_cobble",prob = 254},
		{param2 = 23,name = "stairs:slab_cobble",prob = 254},
		{param2 = 23,name = "stairs:slab_cobble",prob = 254}, Q6, M1, __, __, N9, T1, __, __, __, __, T1, N9, __, S1, N9, __, __, __, __, __, __, N9, S3, __, S1, QW, QW, QW, QW, QW, QW, S3, __, __, __, __, __, __, __, __, __, __, __, __, NY, II, II, II, II, II, II, NY, __, __, NY, M1, M1, M1, M1, M1, M1, NY, __, __, NY, N9, N9, N9, N9, N9, N9, NY, __, S1, NY, N9, N9, N9, N9, N9, N9, NY, S3, __, SW, S2, S2, S2, S2, S2, S2, SW, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, SW, S2, S2, S2, S2, S2, S2, S2, S2, SW, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254},
		{ypos = 4,prob = 254},
		{ypos = 5,prob = 254}
	}
}

towns_gambit.schem_gambit_shop_large_x12_y8_z16_0 = {
	size = {x = 12,y = 8,z = 16},
	data = { __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, Q0, __, __, NY, II, II, II, II, II, II, II, NY, __, __, __, NY, M1, M1, M1, M1, M1, M1, M1, NY, __, __, __, NY, N9, N9, N9, N9, N9, N9, N9, NY, __, __, __, NY, N9, N9, N9, N9, N9, N9, N9, NY, __, __, __, NY, N9, N9, N9, N9, N9, N9, N9, NY, __, __, __, NY, N9, N9, N9, N9, N9, N9, N9, NY, __, __, __, NY, N9, N9, N9, N9, N9, N9, N9, NY, __, __, M1, N9, N9, N9, N9, N9, N9, N9, N9, N9, M1, __, __, II, N9, N9, N9, N9, N9, N9, N9, II, __, __, __, M1, __, __, __, F1, N9, M1, M1, M1, __, __, __, N9, __, T5, __, F1, N9, Q3, __, N9, __, __, QW, N9, N9, N9, N9, N9, Q3, __, __, N9, __, __, __, N9, BN, BN, __, __, __, __, __, N9, __, __, __, N9, BN, BN, __, __, __, __, __, N9, __, __, __, N9, __, __, __, T5, __, __, __, N9, __, __, M1, N9, N9, N9, N9, N9, N9, N9, N9, N9, M1, __, __, II, N9, N9, N9, N9, N9, N9, N9, II, __, __, __, M1, __, __, __, C1, N9, __, Q2, M1, __, __, __, N9, __, __, __, __, N9, __, __, N9, __, __, QW, N9, N9, N9, N9, N9, N9, N9, __, N9, __, __, __, N9, BN, __,
		{param2 = 4,name = "default:sign_wall",prob = 254}, __,
		{param2 = 4,name = "default:sign_wall",prob = 254}, __, __, N9, __, __, __, N9, BN, __, __, __, __, __, T2, N9, __, __, __, N9, __, __, __, __, __, __, __, N9, __, __, M1, N9, N9, N9, N9, N9, N9, N9, N9, N9, M1, __, __, II, N9, N9, N9, N9, N9, N9, N9, II, __, __, __, M1, __, __, __, C1, N9, __, __, M1, __, __, __, N9, __, __, __, T2, N9, __, __, N9, __, __, QW, N9, N9, N9, N9, N9, N9, N9, __, N9, __, __, __, N9, BN, __, Q3, __, Q1, __, __, N9, __, __, __, N9, BN, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, N9, __, __, M1, N9, N9, N9, N9, N9, N9, N9, N9, N9, M1, __, __, II, N9, N9, N9, N9, N9, N9, N9, II, __, __, __, M1, __, __, __, BN, N9, __, __, M1, __, __, __, N9, __, __, __, BN, N9, __, __, N9, __, __, QW, N9, N9, N9, N9, N9, N9, N9, N9, N9, __, __, __, N9, BN, __, Q3, __, Q1, __, BN, N9, __, __, __, N9, BN, __, __, __, __, __, BN, N9, __, __, __, N9, __, __, __, __, __, __, __, N9, __, __, M1, N9, N9, N9, N9, N9, N9, N9, N9, N9, M1, __, __, II, N9, N9, N9, N9, N9, N9, N9, II, __, __, __, M1, __, __, __, BN, N9, __, __, M1, __, __, __, N9, T4, __, __, BN, N9, __, __, N9, __, __, QW, N9, N9, N9, N9, N9, N9, N9, N9, N9, __, __, __, N9, BN, __,
		{param2 = 5,name = "default:sign_wall",prob = 254}, __,
		{param2 = 5,name = "default:sign_wall",prob = 254}, __, BN, N9, __, __, __, N9, BN, __, __, __, __, __, BN, N9, __, __, __, N9, __, __, __, __, __, __, __, N9, __, __, M1, N9, N9, N9, N9, N9, N9, N9, N9, N9, M1, __, __, II, N9, N9, N9, N9, N9, N9, N9, II, __, __, __, M1, NY,
		{param2 = 0,name = "doors:door_wood_b_1",prob = 254}, NY, BN, BN, NY,
		{param2 = 0,name = "doors:door_wood_b_1",prob = 254}, M1, __, __, __, N9, NY,
		{param2 = 0,name = "doors:door_wood_t_1",prob = 254}, NY, BN, BN, NY,
		{param2 = 0,name = "doors:door_wood_t_1",prob = 254}, N9, __, __, QW, N9, N9, N9, N9, N9, N9, N9, N9, N9, __, __, __, N9, BN, __, __, __, __, __, BN, N9, __, __, __, N9, BN, __, __, __, __, __, BN, N9, __, __, __, N9, __, __, __, __, __, __, __, N9, __, __, M1, N9, N9, N9, N9, N9, N9, N9, N9, N9, M1, __, __, II, N9, N9, N9, N9, N9, N9, N9, II, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, N9, __, __, __, __, __, __, __, N9, __, __, QW, N9, S2, S2, S2, S2, S2, S2, S2, N9, __, __, __, N9, II, II, II, II, II, II, II, N9, __, __, __, N9, __, __, __, __, __, __, __, N9, __, __, __, N9, NY, NY, NY, NY, NY, NY, NY, N9, __, __, M1, N9, N9, N9, N9, N9, N9, N9, N9, N9, M1, __, __, II, N9, N9, N9,
		{param2 = 0,name = "wool:red",prob = 254},
		{param2 = 0,name = "wool:red",prob = 254},
		{param2 = 0,name = "wool:red",prob = 254}, N9, II, __, __, __, M1, __, __, Q8,
		{param2 = 23,name = "stairs:slab_cobble",prob = 254},
		{param2 = 23,name = "stairs:slab_cobble",prob = 254},
		{param2 = 23,name = "stairs:slab_cobble",prob = 254}, Q6, M1, __, __, __, G1, __, __, __, __, __, __, __, N9, __, __, QW, N9, __, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, N9, __, __, M1, N9, N9, N9, N9, N9, N9, N9, N9, N9, M1, M1, M1, NY, N9, N9, N9,
		{param2 = 0,name = "wool:red",prob = 254},
		{param2 = 0,name = "wool:red",prob = 254},
		{param2 = 0,name = "wool:red",prob = 254}, N9, II, __, Q1, M1, NY, __, __, __, __, __, __, __, M1, __, __, II, NY, __, __, __, __, __, __, __, N9, __, __, QW, NY, __, __, __, __, __, __, __, N9, __, __, __, NY, __, T4, __, __, __, T4, __, N9, __, __, __, NY, __, __, __, __, __, __, __, N9, __, __, __, NY, __, __, __, __, __, __, __, N9, __, __, M1, N9, N9, N9, N9, N9, N9, N9, N9, N9, M1, Q1, M1, M1, N9, N9, N9, N9, N9, N9, N9, II, __, __, __,
		{param2 = 3,name = "doors:door_wood_b_1",prob = 254}, __, __, __, __, __, __, __, M1, __, __, __,
		{param2 = 3,name = "doors:door_wood_t_1",prob = 254}, __, __, __, __, __, __, __, N9, __, __, QW, N9, __, __, __, __, __, __, __, N9, __, __, __, N9, T2,
		{param2 = 0,name = "wool:white",prob = 254}, T3, __, T2,
		{param2 = 0,name = "wool:white",prob = 254}, T3, N9, __, __, __, N9, __, II, __, __, __, II, __, N9, __, __, __, N9, __, II, __, __, __, II, __, N9, __, __, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, M1, M1, NY, N9, N9, N9, N9, N9, N9, N9, II, __, Q1, M1, NY, __, __, __, __, __, __, __, M1, __, __, II, NY, __, __, __, __, __, __, __, N9, __, __, QW, NY, __, __, __, __, __, __, __, N9, __, __, __, NY, __, T5, __, __, __, T5, __, N9, __, __, __, NY, __, __, __, __, __, __, __, N9, __, __, Q2, S2, S2, S2, S2, S2, S2, S2, S2, S2, Q2, __, __, __, __, __, __, __, __, __, __, __, __, __, __, II, N9, N9, N9, N9, N9, N9, N9, II, __, __, __, M1, __, Q8,
		{param2 = 23,name = "stairs:slab_cobble",prob = 254},
		{param2 = 23,name = "stairs:slab_cobble",prob = 254},
		{param2 = 23,name = "stairs:slab_cobble",prob = 254}, Q6, __, M1, __, __, __, G1, __, __, __, __, __, __, __, N9, __, __, QW, N9, __, __, __, __, __, __, __, N9, __, __, __, N9, __, __, __, __, __, __, __, N9, __, __, Q2, S2, S2, S2, S2, S2, S2, S2, S2, S2, Q2, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, NY, II, II, II, II, II, II, II, NY, __, __, __, NY, M1, M1, M1, M1, M1, M1, M1, NY, __, __, __, NY, N9, N9, N9, N9, N9, N9, N9, NY, __, __, __, NY, N9, N9, N9, N9, N9, N9, N9, NY, __, __, Q2, S2, S2, S2, S2, S2, S2, S2, S2, S2, Q2, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, Q2, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254},
		{ypos = 4,prob = 254},
		{ypos = 5,prob = 254},
		{ypos = 6,prob = 254},
		{ypos = 7,prob = 254}
	}
}

towns_gambit.schem_gambit_stable_x19_y9_z9_90 = {
	size = {x = 19,y = 9,z = 9},
	data = {
		M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0,
		GR, GR, GR, N2, N2, N2, GR, GR, GR, GR, N2, N2, N2, GR, GR, GR, GR, GR, GR,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		S1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, S1, __, __, __, __, __, __, __, S0, S0, S0, S0, S0, S0, S0, S0, S0, SW,
		__, __, S1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, S1, N9, N9, N9, N9, N9, N9, S3, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0,
		DD, DD, DD, N2, N2, N2, DD, DD, DD, DD, N2, N2, N2, DD, DD, DD, DD, DD, GR,
		NY, M1, NY, __, __, __, NY, M1, M1, NY, __, __, __, NY, M1, M1, M1, NY, __,
		NY, N9, NY, __, __, __, NY, N9, N9, NY, __, __, __, NY, __, __, __, NY, __,
		S1, N9, NY, II, II, II, NY, NY, NY, NY, II, II, II, NY, II, II, II, NY, __,
		__, S1, NY, M1, M1, M1, NY, N9, N9, NY, N9, N9, N9, N9, N9, N9, N9, N9, S3,
		__, __, S1, N9, N9, N9, NY, N9, N9, NY, __, __, __, __, __, __, __, __, __,
		__, __, __, S1, N9, N9, N9, N9, N9, N9, S3, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0,
		DD, N2, N2, N2, N2, N2, N2, N2, N2, DD, N2, N2, N2, N2, N2, N2, N2, DD, GR,
		M1, __, __, __, __, __, II, __, __, M1, __, __, __, __, __, __, __, M1, __,
		N9, T3, __, __, __, __, __, __, __, N9, __, __, __, __, __, __, __, __, __,
		S1, __, __, __, __, __, SW, SW, SW, NY, __, __, __, NY, __, __, __, II, __,
		__, S1, __, __, __, __, __, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, S3,
		__, __, S1, __, __, __, __, __, __, N9, __, __, __, __, __, __, __, __, __,
		__, __, __, S1, N9, N9, N9, N9, N9, N9, S3, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0,
		DD, N2, N2, N2, N2, N2, N2, N2, N2, DD, N2, N2, N2, N2, N2, N2, N2, DD, GR,
		M1, __, __, __, __, __, II, __, __, M1, __, __, __, __, __, __, __, M1, __,
		N9, __, __, __, __, __, __, __, __, N9, T3, __, __, __, __, __, __, __, __,
		S1, __, __, __, __, __, SW, SW, SW, NY, __, __, __, NY, __, __, __, II, __,
		__, S1, __, __, __, __, __, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, S3,
		__, __, S1, __, __, __, __, __, __, N9, __, __, __, __, __, __, __, __, __,
		__, __, __, S1, N9, N9, N9, N9, N9, N9, S3, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0,
		DD, N2, N2, N2, N2, N2, DD, DD, DD, DD, N2, N2, N2, N2, N2, N2, N2, DD, GR,
		M1, __, __, __, __, L2, NY, N9, N9, NY, __, __, __, __, __, __, __, M1, __,
		N9, __, __, __, __, L2, NY, II, II, NY, __, __, __, __, __, __, __, __, __,
		S1, __, __, __, __, L2, SW, SW, SW, NY, __, __, __, NY, __, __, __, II, __,
		__, S1, __, __, __, __, __, __, T2, NY, N9, N9, N9, N9, N9, N9, N9, N9, S3,
		__, __, S1, __, __, __, __, __, __, NY, __, __, __, __, __, __, __, __, __,
		__, __, __, S1, N9, N9, N9, N9, N9, N9, S3, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0,
		DD, N2, N2, N2, N2, N2, N2, N2, N2, DD, N2, N2, N2, N2, N2, N2, N2, DD, GR,
		M1, __, __, __, __, __, II, __, __, M1, __, __, __, __, __, __, __, M1, __,
		N9, __, __, __, __, __, __, __, __, N9, T3, __, __, __, __, __, __, __, __,
		S1, __, __, __, __, __, SW, SW, SW, NY, __, __, __, NY, __, __, __, II, __,
		__, S1, __, __, __, __, __, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, S3,
		__, __, S1, __, __, __, __, __, __, N9, __, __, __, __, __, __, __, __, __,
		__, __, __, S1, N9, N9, N9, N9, N9, N9, S3, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0,
		DD, N2, N2, N2, N2, N2, N2, N2, N2, DD, N2, N2, N2, N2, N2, N2, N2, DD, GR,
		M1, __, __, __, __, __, II, __, __, M1, __, __, __, __, __, __, __, M1, __,
		N9, T3, __, __, __, __, __, __, __, N9, __, __, __, __, __, __, __, __, __,
		S1, __, __, __, __, __, SW, SW, SW, NY, __, __, __, NY, __, __, __, II, __,
		__, S1, __, __, __, __, __, __, __, N9, N9, N9, N9, N9, N9, N9, N9, N9, S3,
		__, __, S1, __, __, __, __, __, __, N9, __, __, __, __, __, __, __, __, __,
		__, __, __, S1, N9, N9, N9, N9, N9, N9, S3, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0,
		DD, DD, DD, N2, N2, N2, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, GR,
		NY, M1, NY, M1, M1, M1, NY, M1, M1, NY, M1, M1, M1, NY, M1, M1, M1, NY, __,
		NY, N9, NY, N9, N9, N9, NY, N9, N9, NY, __, __, __, NY, __, __, __, NY, __,
		S1, N9, NY, NY, NY, NY, NY, NY, NY, NY, II, II, II, NY, II, II, II, NY, __,
		__, S1, NY, N9, N9, N9, NY, N9, N9, NY, N9, N9, N9, N9, N9, N9, N9, N9, S3,
		__, __, S1, N9, N9, N9, NY, N9, N9, NY, __, __, __, __, __, __, __, __, __,
		__, __, __, S1, N9, N9, N9, N9, N9, N9, S3, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0,
		GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR, GR,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		S1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, S1, __, __, __, __, __, __, __, S2, S2, S2, S2, S2, S2, S2, S2, S2, SW,
		__, __, S1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, S1, N9, N9, N9, N9, N9, N9, S3, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254},
		{ypos = 4,prob = 254},
		{ypos = 5,prob = 254},
		{ypos = 6,prob = 254},
		{ypos = 7,prob = 254},
		{ypos = 8,prob = 254}
	}
}

towns_gambit.schem_gambit_tower_x7_y23_z7_270 = {
	size = {x = 7,y = 23,z = 7},
	data = {
		__, __, M1, M1, M1, __, __,
		__, __, Q0, Q0, Q0, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		SW, S0, S0, S0, S0, S0, SW,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,

		__, NY, M1, M1, M1, NY, __,
		__, NY, M1, M1, M1, NY, __,
		__, NY, M1, M1, M1, NY, __,
		__, NY, M1, M1, M1, NY, __,
		__, NY, M1, M1, M1, NY, __,
		__, NY, M1, M1, M1, NY, __,
		__, NY, M1, M1, M1, NY, __,
		__, NY, M1, M1, M1, NY, __,
		__, QW, Q0, Q0, Q0, QW, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, M1, M1, M1, M1, M1, __,
		__, M1, S2, S2, S2, M1, __,
		__, II, __, __, __, II, __,
		S1, II, __, __, __, II, S3,
		__, SW, S0, S0, S0, SW, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,

		M1, M1, N9, N9, N9, M1, M1,
		Q1, M1, __, S1, N9, M1, Q3,
		__, M1, __, __, S1, M1, __,
		__, M1, __, __, __, M1, __,
		__, M1, T3, __, __, M1, __,
		__, M1, N9, N9, __, M1, __,
		__, M1, __, NY, __, M1, __,
		__, M1, __, NY, __, M1, __,
		__, Q1, T5, NY, T5, Q3, __,
		__, __, NY, NY, NY, __, __,
		__, __, NY, NY, NY, __, __,
		__, __, NY, NY, NY, __, __,
		__, __, NY, NY, NY, __, __,
		__, __, NY, NY, NY, __, __,
		__, M1, N9, N9, N9, M1, __,
		__, S3, __, __, __, S1, __,
		__, __, __, __, __, __, __,
		S1, __, __, __, __, __, S3,
		__, S1, __, T5, __, S3, __,
		__, __, SW, S0, SW, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,

		M1, M1, N9, N9, N9, M1, M1,
		Q1, M1, __, __, __, M1, Q3,
		__, M1, __, __, __, M1, __,
		__, M1, __, __, S0, M1, __,
		__, M1, __, __, __, M1, __,
		__, M1, N9, N9, __, M1, __,
		__, Q1, __, L5, __, Q3, __,
		__, __, __, L5, __, __, __,
		__, Q1, __, L5, __, Q3, __,
		__, __, NY, L5, NY, __, __,
		__, __, NY, L5, NY, __, __,
		__, __, NY, L5, NY, __, __,
		__, __, NY, L5, NY, __, __,
		__, __, NY, L5, NY, __, __,
		__, M1, N9, L5, N9, M1, __,
		__, S3, __, __, __, S1, __,
		__, __, __, __, __, __, __,
		S1, __, __, __, __, __, S3,
		__, S1, T3, __, T2, S3, __,
		__, __, S1, N9, S3, __, __,
		__, __, __, SW, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,

		M1, M1, N9, N9, N9, M1, M1,
		Q1, M1, __, __, __, M1, Q3,
		__, M1, __, __, __, M1, __,
		__, M1, __, __, __, M1, __,
		__, M1, __, __, S0, M1, __,
		__, M1, N9, S3, __, M1, __,
		__, M1, __, __, __, M1, __,
		__, M1, __, __, __, M1, __,
		__, Q1, __, __, __, Q3, __,
		__, __, NY, NY, NY, __, __,
		__, __, NY, NY, NY, __, __,
		__, __, NY, NY, NY, __, __,
		__, __, NY, NY, NY, __, __,
		__, __, NY, NY, NY, __, __,
		__, M1, N9, N9, N9, M1, __,
		__, S3, __, __, __, S1, __,
		__, __, __, __, __, __, __,
		S1, __, __, __, __, __, S3,
		__, S1, __, T4, __, S3, __,
		__, __, SW, S2, SW, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,

		__, NY, M1, N9, M1, NY, __,
		__, NY, M1, {param2 = 2,name = "doors:door_wood_b_1",prob = 254}, M1, NY, __,
		__, NY, M1, {param2 = 2,name = "doors:door_wood_t_1",prob = 254}, M1, NY, __,
		__, NY, M1, M1, M1, NY, __,
		__, NY, M1, M1, M1, NY, __,
		__, NY, M1, M1, M1, NY, __,
		__, NY, M1, Q2, M1, NY, __,
		__, NY, M1, __, M1, NY, __,
		__, QW, Q2, Q2, Q2, QW, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, M1, M1, M1, M1, M1, __,
		__, M1, S0, S0, S0, M1, __,
		__, II, __, __, __, II, __,
		S1, II, __, __, __, II, S3,
		__, SW, S2, S2, S2, SW, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,

		__, __, M1, S2, M1, __, __,
		__, __, Q2, __, Q2, __, __,
		__, __, __, __, __, __, __,
		__, __, Q1, QW, Q3, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		SW, S2, S2, S2, S2, S2, SW,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __,
		__, __, __, __, __, __, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254},
		{ypos = 4,prob = 254},
		{ypos = 5,prob = 254},
		{ypos = 6,prob = 254},
		{ypos = 7,prob = 254},
		{ypos = 8,prob = 254},
		{ypos = 9,prob = 254},
		{ypos = 10,prob = 254},
		{ypos = 11,prob = 254},
		{ypos = 12,prob = 254},
		{ypos = 13,prob = 254},
		{ypos = 14,prob = 254},
		{ypos = 15,prob = 254},
		{ypos = 16,prob = 254},
		{ypos = 17,prob = 254},
		{ypos = 18,prob = 254},
		{ypos = 19,prob = 254},
		{ypos = 20,prob = 254},
		{ypos = 21,prob = 254},
		{ypos = 22,prob = 254}
	}
}
	

--Fortress Schematic Node Definitions
S0 = {name = "stairs:stair_cobble", param2 = 0, prob = 254}
S1 = {name = "stairs:stair_cobble", param2 = 1, prob = 254}
S2 = {name = "stairs:stair_cobble", param2 = 2, prob = 254}
S3 = {name = "stairs:stair_cobble", param2 = 3, prob = 254}


towns_gambit.schem_bldg_fortress_x25_y22_z23_r90 = {
	size = {x = 25,y = 22,z = 23},
	data = {
		M2, M2, M2, M2, M2, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M2, M2, M2, M2, M2,
		M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, __, M1, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, __, M1,
		T1, __, T1, __, T1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, T1, __, T1, __, T1,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2,
		M1, M1, M1, M1, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, M1, M1, M1, M1,
		M1, F2, S3, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, __, __, F1, M1,
		M1, S3, __, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, __, __, S2, M1,
		M1, __, __, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, C2, S3, __, M1,
		M1, __, __, M0, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, S3, __, __, M1,
		M1, __, __, __, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, __, __, __, M1,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2,
		M1, M1, M1, M1, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, M1, M1, M1, M1,
		M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, S2, M1,
		M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1,
		M1, S0, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, __, __, M1,
		M1, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, M1,
		M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1,
		M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1,
		T1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, T1,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M2, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M2, M2, M2,
		M1, M1, M1, M1, M1, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, M1, M1, M1, M1, M1,
		M1, __, __, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, __, __, __, M1,
		M1, __, __, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, __, __, __, M1,
		M1, C3, __, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, __, __, __, M1,
		M1, S0, M0, M0, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, M0, M0, M0, M1,
		M1, __, __, __, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, __, __, __, M1,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M2, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M2, M2, M2,
		M1, M1, M1, N3, M1, NY, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, NY, M1, M1, M1, M1, M1,
		M1, M1, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, M1, M1,
		M1, M1, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, M1, M1,
		M1, M1, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, M1, M0, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M0, M1, M1,
		M1, M1, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, __, M1, M1,
		M1, __, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, __, __, M1,
		T1, __, __, __, T1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, T1, __, __, __, T1,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M2, __, __,
		__, M0, M0, NY, NY, NY, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, NY, NY, NY, M0, __, __,
		__, M0, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, T4, M0, __, __,
		__, M0, M0, M0, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M1, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M2, __, __,
		__, M0, M0, NY, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, NY, M0, __, __,
		__, M0, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, __, T4, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, M0, M0, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M1, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M2, __, __,
		__, M0, M0, NY, M0, M0, M0, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, M0, M0, M0, NY, M0, __, __,
		__, M0, __, M0, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, __, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, M0, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M1, __, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M2, __, __,
		__, M0, M0, NY, M0, M0, M0, NY, M0, M0, M0, M0, M0, M0, M0, M0, M0, NY, M0, M0, M0, NY, M0, __, __,
		__, M0, __, M0, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, __, __, __, __, M0, __, __,
		__, M0, __, M0, __, __, __, __, M0, M0, M0, M1, M1, M1, M0, M0, M0, __, __, __, __, __, M0, __, __,
		__, M0, __, M0, __, __, __, __, M0, M0, M0, M1, __, M1, M0, M0, M0, __, __, __, __, __, M0, __, __,
		__, M0, M0, M0, __, __, __, __, M0, M0, M0, M1, M1, M1, M0, M0, M0, __, __, __, __, __, M0, __, __,
		__, M1, __, M1, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M1, M1, M1, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M1, __, M1, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M1, M1, M1, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, M1, M1, M1, M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, M1, __, M1, __, M1, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, T1, __, T1, __, T1, __, T1, __, T1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M1, M1, __,
		__, M0, M0, NY, M0, M0, M0, NY, M0, NY, NY, NY, NY, NY, NY, NY, M0, NY, M0, M0, M0, NY, M1, M1, __,
		__, M0, __, M0, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, M1, M1, M1, __,
		__, M0, __, M0, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, M1, M1, M1, __,
		__, M0, __, M0, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, M1, M1, M1, __,
		__, M0, M0, M0, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, M1, M0, M1, __,
		__, M1, __, M1, __, __, __, __, M0, TC, __, __, __, __, __, TC, M0, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, M0, NY, NY, NY, NY, NY, NY, NY, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, TC, __, __, __, __, __, TC, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, NY, NY, NY, NY, NY, NY, NY, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, M0, M0, M0, N1, N1, N1, N1, N1, N1, N1, NY, M1, M1, S3,
		__, M0, M0, NY, M0, M0, M0, NY, M0, NY, M0, M0, M0, M0, M0, NY, M0, NY, NY, NY, NY, NY, M1, S3, __,
		__, M0, __, M0, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, DR, __, __,
		__, M0, __, M0, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, M0, __, M0, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, M0, M0, M0, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, M1, M0, M1, __,
		__, M1, __, M1, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, M0, NY, M0, M0, M0, M0, M0, NY, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, NY, M0, M0, M0, M0, M0, NY, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, T1, __, __, __, __, __, __, __, T1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, M0, L3, M0, N1, N1, N1, N1, N1, N1, N1, N9, M1, M1, S3,
		__, M0, M0, NY, M0, M0, M0, NY, M0, NY, M0, M0, L3, M0, M0, NY, NY, NY, N9, N9, N9, N9, M1, S3, __,
		__, M0, __, M0, __, __, __, __, __, __, __, NY, L3, __, __, __, __, __, __, __, __, __, __, __, __,
		__, M0, __, M0, __, __, __, __, __, __, __, NY, L3, __, __, __, __, __, __, __, __, __, __, __, __,
		__, M0, __, M0, __, __, __, __, M1, __, __, NY, L3, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, M0, M0, M0, __, __, __, __, M0, __, __, NY, L3, __, __, __, M0, __, __, __, __, M1, M0, M1, __,
		__, M1, __, M1, __, __, __, __, M0, __, __, NY, L3, __, __, __, M0, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, M0, NY, M0, M0, L3, M0, M0, NY, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, NY, L3, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, NY, L3, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, NY, L3, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, NY, L3, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, NY, L3, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, NY, M0, M0, L3, M0, M0, NY, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, M1, __, __, __, M1, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, M1, __, __, __, M1, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, M1, __, __, __, M1, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, M1, __, __, __, M1, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, M1, __, M1, __, M1, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, M0, M0, M0, N1, N1, N1, N1, N1, N1, N1, NY, M1, M1, S3,
		__, M0, M0, NY, M0, M0, M0, NY, M0, NY, M0, M0, M0, M0, M0, NY, M0, NY, NY, NY, NY, NY, M1, S3, __,
		__, M0, __, M0, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, DL, __, __,
		__, M0, __, M0, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, M0, __, M0, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, M0, M0, M0, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, M1, M0, M1, __,
		__, M1, __, M1, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, M0, NY, M0, M0, M0, M0, M0, NY, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, NY, M0, M0, M0, M0, M0, NY, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, __, __, __, L5, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, __, __, __, L5, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, T1, __, __, __, __, __, L5, __, T1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, L5, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, L5, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, L5, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M1, M1, __,
		__, M0, M0, NY, M0, M0, M0, NY, M0, NY, NY, NY, NY, NY, NY, NY, M0, NY, M0, M0, M0, NY, M1, M1, __,
		__, M0, __, M0, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, M1, M1, M1, __,
		__, M0, __, M0, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, M1, M1, M1, __,
		__, M0, __, M0, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, M1, M1, M1, __,
		__, M0, M0, M0, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, M1, M0, M1, __,
		__, M1, __, M1, __, __, __, __, M0, TC, __, __, __, __, __, TC, M0, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, M0, NY, NY, NY, NY, NY, NY, NY, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, TC, __, __, __, __, __, TC, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, NY, NY, NY, NY, NY, NY, NY, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M2, __, __,
		__, M0, M0, NY, M0, M0, M0, NY, M0, M0, M0, M0, M0, M0, M0, M0, M0, NY, M0, M0, M0, NY, M0, __, __,
		__, M0, __, M0, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, __, __, __, __, M0, __, __,
		__, M0, __, M0, __, __, __, __, M0, M0, M0, M1, M1, M1, M0, M0, M0, __, __, __, __, __, M0, __, __,
		__, M0, __, M0, __, __, __, __, M0, M0, M0, M1, __, M1, M0, M0, M0, __, __, __, __, __, M0, __, __,
		__, M0, M0, M0, __, __, __, __, M0, M0, M0, M1, M1, M1, M0, M0, M0, __, __, __, __, __, M0, __, __,
		__, M1, __, M1, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M1, M1, M1, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M1, __, M1, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M1, M1, M1, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, M1, M1, M1, M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, M1, __, M1, __, M1, __, M1, __, M1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, T1, __, T1, __, T1, __, T1, __, T1, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M2, __, __,
		__, M0, M0, NY, M0, M0, M0, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, M0, M0, M0, NY, M0, __, __,
		__, M0, __, M0, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, __, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, M0, M0, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M1, __, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M2, __, __,
		__, M0, M0, NY, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, NY, M0, __, __,
		__, M0, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, __, T5, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, M0, M0, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M1, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		__, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M2, __, __,
		__, M0, M0, NY, NY, NY, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, NY, NY, NY, M0, __, __,
		__, M0, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M0, M0, M0, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M0, __, __,
		__, M1, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M2, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M2, M2, M2,
		M1, M1, M1, M1, M1, NY, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, NY, M1, M1, M1, M1, M1,
		M1, M1, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, M1, M1,
		M1, M1, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, M1, M1,
		M1, M1, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, M1, M0, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M0, M1, M1,
		M1, M1, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, __, M1, M1,
		M1, __, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, __, __, M1,
		T1, __, __, __, T1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, T1, __, __, __, T1,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M2, M2, M2, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, N1, M2, M2, M2,
		M1, M1, M1, M1, M1, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, NY, M1, M1, M1, M1, M1,
		M1, __, __, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, __, __, __, M1,
		M1, __, __, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, __, __, __, M1,
		M1, __, __, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, T5, __, C1, M1,
		M1, M0, M0, M0, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, M0, M0, S2, M1,
		M1, M1, __, __, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, __, __, __, M1,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2,
		M1, M1, M1, M1, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, M1, M1, M1, M1,
		M1, S0, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1,
		M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1,
		M1, __, __, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, __, S2, M1,
		M1, __, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, __, M1,
		M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1,
		M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1,
		T1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, T1,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2, M2,
		M1, M1, N3, M1, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, M1, M1, N3, M1,
		M1, F3, __, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, __, S1, F0, M1,
		M1, S0, __, __, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, __, __, S1, M1,
		M1, __, S1, C0, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, __, __, __, M1,
		M1, __, __, S1, M1, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M0, M1, M0, __, __, M1,
		M1, __, __, __, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, M1, __, __, __, M1,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

		M2, M2, M2, M2, M2, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M2, M2, M2, M2, M2,
		M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, N3, M1,
		M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, M1, M1, M1, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, M1, M1, M1, M1,
		M1, __, M1, __, M1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M1, __, M1, __, M1,
		T1, __, T1, __, T1, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, T1, __, T1, __, T1,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
		__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __
	},
	yslice_prob = {
		{ypos = 0,prob = 254},
		{ypos = 1,prob = 254},
		{ypos = 2,prob = 254},
		{ypos = 3,prob = 254},
		{ypos = 4,prob = 254},
		{ypos = 5,prob = 254},
		{ypos = 6,prob = 254},
		{ypos = 7,prob = 254},
		{ypos = 8,prob = 254},
		{ypos = 9,prob = 254},
		{ypos = 10,prob = 254},
		{ypos = 11,prob = 254},
		{ypos = 12,prob = 254},
		{ypos = 13,prob = 254},
		{ypos = 14,prob = 254},
		{ypos = 15,prob = 254},
		{ypos = 16,prob = 254},
		{ypos = 17,prob = 254},
		{ypos = 18,prob = 254},
		{ypos = 19,prob = 254},
		{ypos = 20,prob = 254},
		{ypos = 21,prob = 254}
	}
}

	
	