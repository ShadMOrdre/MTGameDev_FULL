--
-- switch for debugging
--
towns_medival.debug = false
--
-- material to replace cobblestone with
--
towns_medival_wallmaterial = {
  "default:cobble", 
  "default:desert_cobble", 
  "default:mossycobble"
}
--
-- path to schematics
--
towns_medival_schem_path = towns_medival.modpath.."/schematics/"
--
-- list of schematics
--  {name = "townhall", mts = towns_medival_schem_path.."townhall.mts", hsize = 15, max_num = 0, rplc = "n"},
--  {name = "well", mts = towns_medival_schem_path.."well.mts", hsize = 11, max_num = 0.045, rplc = "n"},
--  {name = "hut", mts = towns_medival_schem_path.."hut.mts", hsize = 11, max_num = 0.9, rplc = "y"},
--  {name = "garden", mts = towns_medival_schem_path.."garden.mts", hsize = 11, max_num = 0.1, rplc = "n"},
--  {name = "lamp", mts = towns_medival_schem_path.."lamp.mts", hsize = 10, max_num = 0.1, rplc = "n"},
--  {name = "tower", mts = towns_medival_schem_path.."tower.mts", hsize = 11, max_num = 0.055, rplc = "n"},
--  {name = "church", mts = towns_medival_schem_path.."church.mts", hsize = 17, max_num = 0.050, rplc = "n"},
--  {name = "blacksmith", mts = towns_medival_schem_path.."blacksmith.mts", hsize = 11, max_num = 0.050, rplc = "n"},
  -- {name = "mgs_fortress_new_01_25w_25l_22h_0_180", mts = towns_medival_schem_path.."mgs_fortress_new_01_25w_25l_22h_0_180.mts", hsize = 30, max_num = 0.025, rplc = "n"},
--
--[[
  {name = "farm_full_3", mts = towns_medival_schem_path.."farm_full_3.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_full_4", mts = towns_medival_schem_path.."farm_full_4.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_tiny_4", mts = towns_medival_schem_path.."farm_tiny_4.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_tiny_5", mts = towns_medival_schem_path.."farm_tiny_5.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_tiny_6", mts = towns_medival_schem_path.."farm_tiny_6.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_tiny_7", mts = towns_medival_schem_path.."farm_tiny_7.mts", hsize = 20, max_num = 0.050, rplc = "n"},


  {name = "farm_full_2", mts = towns_medival_schem_path.."farm_full_2.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_tiny_2", mts = towns_medival_schem_path.."farm_tiny_2.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_tiny_3", mts = towns_medival_schem_path.."farm_tiny_3.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "default_town_hotel", mts = towns_medival_schem_path.."default_town_hotel.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "trader_clay_4", mts = towns_medival_schem_path.."trader_clay_4.mts", hsize = 20, max_num = 0.050, rplc = "n"},

  {name = "mgs_fortress_new_01_25w_25l_22h_0_180", mts = towns_medival_schem_path.."mgs_fortress_new_01_25w_25l_22h_0_180.mts", hsize = 28, max_num = 0.050, rplc = "n"},
  {name = "structure_1", mts = towns_medival_schem_path.."structure_1.mts", hsize = 25, max_num = 0.050, rplc = "n"},
  {name = "mgs_mine_new_02_13w_9l_31h_0_270", mts = towns_medival_schem_path.."mgs_mine_new_02_13w_9l_31h_0_270.mts", hsize = 18, max_num = 0.075, rplc = "n"},
  {name = "mgs_turret_new_01_6w_6l_9h_0_90", mts = towns_medival_schem_path.."mgs_turret_new_01_6w_6l_9h_0_90.mts", hsize = 10, max_num = 0.075, rplc = "n"},
  {name = "mgs_tower_new_02_10w_8l_17h_0_90", mts = towns_medival_schem_path.."mgs_tower_new_02_10w_8l_17h_0_90.mts", hsize = 15, max_num = 0.050, rplc = "n"},
  {name = "structure_5", mts = towns_medival_schem_path.."structure_5.mts", hsize = 25, max_num = 0.050, rplc = "n"},
  {name = "structure_6", mts = towns_medival_schem_path.."structure_6.mts", hsize = 25, max_num = 0.050, rplc = "n"},
  
  {name = "mgs_castle_new_01_35w_27l_15h_0_180", mts = towns_medival_schem_path.."mgs_castle_new_01_35w_27l_15h_0_180.mts", hsize = 38, max_num = 0.050, rplc = "n"},
  {name = "mgs_castle_new_02_35w_25l_15h_0_0", mts = towns_medival_schem_path.."mgs_castle_new_02_35w_25l_15h_0_0.mts", hsize = 38, max_num = 0.050, rplc = "n"},
  {name = "towntest_Nanuk_lavabeacon_0_180", mts = towns_medival_schem_path.."towntest_Nanuk_lavabeacon_0_180.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "farm_full_1", mts = towns_medival_schem_path.."farm_full_1.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "well2", mts = towns_medival_schem_path.."well2.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "church_1", mts = towns_medival_schem_path.."church_1.mts", hsize = 25, max_num = 0.050, rplc = "n"},
  {name = "default_town_park", mts = towns_medival_schem_path.."default_town_park.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "baking_house_4", mts = towns_medival_schem_path.."baking_house_4.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "forge_1_0", mts = towns_medival_schem_path.."forge_1_0.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "mgs_bldg_fortress_01_0_0", mts = towns_medival_schem_path.."mgs_bldg_fortress_01_0_0.mts", hsize = 35, max_num = 0.050, rplc = "n"},
  {name = "mill_1", mts = towns_medival_schem_path.."mill_1.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "towntest_cornernote_tower_1_90", mts = towns_medival_schem_path.."towntest_cornernote_tower_1_90.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "taverne_2", mts = towns_medival_schem_path.."taverne_2.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "field_2", mts = towns_medival_schem_path.."field_2.mts", hsize = 30, max_num = 0.050, rplc = "n"},
  {name = "towntest_cornernote_turret_1_270", mts = towns_medival_schem_path.."towntest_cornernote_turret_1_270.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  
  {name = "mgs_tower_new_02_10w_8l_17h_0_90", mts = towns_medival_schem_path.."mgs_tower_new_02_10w_8l_17h_0_90.mts", hsize = 14, max_num = 0.050, rplc = "n"},
  {name = "mgs_turret_new_01_6w_6l_9h_0_90", mts = towns_medival_schem_path.."mgs_turret_new_01_6w_6l_9h_0_90.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "default_town_park", mts = towns_medival_schem_path.."default_town_park.mts", hsize = 16, max_num = 0.050, rplc = "n"},
--]]
--
towns_medival_schematic_table = { 
  {name = "towntest_Nanuk_lavabeacon_0_180", mts = towns_medival_schem_path.."towntest_Nanuk_lavabeacon_0_180.mts", hsize = 14, max_num = 0, rplc = "n"},
  {name = "church_1", mts = towns_medival_schem_path.."church_1.mts", hsize = 25, max_num = 0.050, rplc = "n"},
  {name = "farm_full_1", mts = towns_medival_schem_path.."farm_full_1.mts", hsize = 18, max_num = 0.050, rplc = "n"},
  {name = "baking_house_4", mts = towns_medival_schem_path.."baking_house_4.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "taverne_2", mts = towns_medival_schem_path.."taverne_2.mts", hsize = 20, max_num = 0.050, rplc = "n"},
  {name = "mill_1", mts = towns_medival_schem_path.."mill_1.mts", hsize = 16, max_num = 0.050, rplc = "n"},
  {name = "shed_10", mts = towns_medival_schem_path.."shed_10.mts", hsize = 14, max_num = 0.050, rplc = "n"},
  {name = "well_6", mts = towns_medival_schem_path.."well_6.mts", hsize = 10, max_num = 0.050, rplc = "n"},
  {name = "weide_1", mts = towns_medival_schem_path.."weide_1.mts", hsize = 12, max_num = 0.050, rplc = "n"},
  {name = "wagon_8", mts = towns_medival_schem_path.."wagon_8.mts", hsize = 6, max_num = 0.050, rplc = "n"},
  {name = "cow_shed_1", mts = towns_medival_schem_path.."cow_shed_1_270.mts", hsize = 14, max_num = 0.050, rplc = "n"},
  {name = "shed_with_forge_v2_1", mts = towns_medival_schem_path.."shed_with_forge_v2_1_0.mts", hsize = 16, max_num = 0.050, rplc = "n"},
  {name = "forge_1_0", mts = towns_medival_schem_path.."forge_1_0.mts", hsize = 16, max_num = 0.050, rplc = "n"},
  {name = "mgs_mine_new_02_13w_9l_31h_0_270", mts = towns_medival_schem_path.."mgs_mine_new_02_13w_9l_31h_0_270.mts", hsize = 18, max_num = 0.050, rplc = "n"},
  {name = "field_2", mts = towns_medival_schem_path.."field_2.mts", hsize = 18, max_num = 0.050, rplc = "n"},
  {name = "wheat_field", mts = towns_medival_schem_path.."wheat_field.mts", hsize = 12, max_num = 0.050, rplc = "n"},
}
--
-- baseplate material, to replace dirt with grass and where buildings can be built
--
towns_medival_surface_mat = {
 	--"lib_materials:dirt_with_grass_cool_semihumid_coastal",
 	"lib_materials:dirt_with_grass_cool_semihumid_lowland",
 	--"lib_materials:dirt_with_grass_cool_temperate_coastal",
 	--"lib_materials:dirt_with_grass_cool_temperate_lowland",
 	--"lib_materials:dirt_with_grass_cool_temperate_shelf",

}
--
-- temporary info for currentliy built settlement (position of each building) 
--
towns_medival_settlement_info = {}
--
-- list of towns_medival, load on server start up
--
towns_medival_settled_areas_in_world = {}
--
-- min_distance between towns_medival
--
min_dist_towns_medival = 1000
if towns_medival.debug == true 
then
  min_dist_towns_medival = 200
end
--
-- maximum allowed difference in height for building a sttlement
--
towns_medival_max_height_difference = 3
--
--
--
towns_medival_half_map_chunk_size = 40
towns_medival_quarter_map_chunk_size = 20
