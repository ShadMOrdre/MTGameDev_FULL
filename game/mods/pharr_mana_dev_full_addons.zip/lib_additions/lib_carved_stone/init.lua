
lib_carved_stone = {}

local _lib_carved_stone = {}



function lib_carved_stone.register_nodes(node_name, node_desc, node_texture, node_craft_mat, node_sounds)

--BLOCKS
--GEOMETRIC
	lib_carved_stone.register_geometric_stone_01_100_height_100_width(node_name .. "_geometric_stone_01_100_height_100_width", node_desc .. "_geometric_stone_01_100_height_100_width", node_texture, node_craft_mat, node_sounds)
	lib_carved_stone.register_geometric_stone_03_100_height_100_width(node_name .. "_geometric_stone_03_100_height_100_width", node_desc .. "_geometric_stone_03_100_height_100_width", node_texture, node_craft_mat, node_sounds)
	lib_carved_stone.register_geometric_stone_04_100_height_100_width(node_name .. "_geometric_stone_04_100_height_100_width", node_desc .. "_geometric_stone_04_100_height_100_width", node_texture, node_craft_mat, node_sounds)
	lib_carved_stone.register_geometric_stone_05_100_height_100_width(node_name .. "_geometric_stone_05_100_height_100_width", node_desc .. "_geometric_stone_05_100_height_100_width", node_texture, node_craft_mat, node_sounds)
	lib_carved_stone.register_geometric_stone_06_100_height_100_width(node_name .. "_geometric_stone_06_100_height_100_width", node_desc .. "_geometric_stone_06_100_height_100_width", node_texture, node_craft_mat, node_sounds)
	lib_carved_stone.register_stone_embossed_01_100_height_100_width(node_name .. "_stone_embossed_01_100_height_100_width", node_desc .. "_stone_embossed_01_100_height_100_width", node_texture, node_craft_mat, node_sounds)

	--ROMAN NUMERALS  (I-III)	
	lib_carved_stone.register_geometric_stone_02_100_height_100_width(node_name .. "_geometric_stone_02_100_height_100_width", node_desc .. "_geometric_stone_02_100_height_100_width", node_texture, node_craft_mat, node_sounds)
	
	--CENTERED WALLS
	lib_carved_stone.register_wall_block_100_height_050_width(node_name .. "_wall_block_100_height_050_width", node_desc .. "_wall_block_100_height_050_width", node_texture, node_craft_mat, node_sounds)
	lib_carved_stone.register_wall_brick_100_height_050_width(node_name .. "_wall_brick_100_height_050_width", node_desc .. "_wall_brick_100_height_050_width", node_texture, node_craft_mat, node_sounds)

end




lib_carved_stone.register_geometric_stone_01_100_height_100_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, },
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.375, -0.375, -0.4375, 0.375, 0.375, 0.4375}, -- NodeBox1
			{0.375, -0.375, -0.5, 0.5, 0.375, 0.5}, -- NodeBox2
			{-0.5, -0.375, -0.5, -0.375, 0.375, 0.5}, -- NodeBox3
			{-0.5, 0.375, -0.5, 0.5, 0.5, 0.5}, -- NodeBox6
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox7
			{-0.3125, -0.25, -0.5, 0.3125, 0.25, -0.4375}, -- NodeBox8
			{-0.3125, -0.25, 0.4375, 0.3125, 0.25, 0.5}, -- NodeBox9
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{ -0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_geometric_stone_01_100_height_100_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_geometric_stone_02_100_height_100_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, },
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.375, -0.4375, 0.5, 0.375, 0.5}, -- NodeBox1
			{0.375, -0.375, -0.5, 0.5, 0.375, -0.375}, -- NodeBox2
			{-0.5, -0.375, -0.5, -0.375, 0.375, -0.375}, -- NodeBox3
			{-0.5, 0.375, -0.5, 0.5, 0.5, 0.5}, -- NodeBox6
			{-0.5, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox7
			{-0.25, -0.25, -0.5, -0.125, 0.25, -0.4375}, -- NodeBox8
			{0.125, -0.25, -0.5, 0.25, 0.25, -0.375}, -- NodeBox9
			{-0.0625, -0.25, -0.5, 0.0625, 0.25, -0.4375}, -- NodeBox10
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{ -0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_geometric_stone_02_100_height_100_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_geometric_stone_03_100_height_100_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, },
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.4375, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.5, -0.5, -0.5, -0.1875, 0.5, -0.4375}, -- NodeBox8
			{-0.1875, 0.1875, -0.5, 0.5, 0.5, -0.4375}, -- NodeBox9
			{0.1875, -0.5, -0.5, 0.5, -0.1875, -0.4375}, -- NodeBox10
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{ -0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_geometric_stone_03_100_height_100_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_geometric_stone_04_100_height_100_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, },
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.4375, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.5, 0.1875, -0.5, 0.5, 0.5, -0.4375}, -- NodeBox9
			{-0.5, -0.5, -0.5, 0.5, -0.1875, -0.4375}, -- NodeBox10
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{ -0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_geometric_stone_04_100_height_100_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_geometric_stone_05_100_height_100_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, },
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.4375, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.5, -0.5, -0.5, -0.1875, 0.5, -0.4375}, -- NodeBox9
			{0.1875, -0.5, -0.5, 0.5, 0.5, -0.4375}, -- NodeBox10
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{ -0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_geometric_stone_05_100_height_100_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_geometric_stone_06_100_height_100_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, },
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.4375, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.5, -0.5, -0.5, -0.1875, -0.1875, -0.4375}, -- NodeBox9
			{0.1875, -0.5, -0.5, 0.5, -0.1875, -0.4375}, -- NodeBox10
			{-0.5, 0.1875, -0.5, -0.1875, 0.5, -0.4375}, -- NodeBox11
			{0.1875, 0.1875, -0.5, 0.5, 0.5, -0.4375}, -- NodeBox12
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{ -0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_geometric_stone_06_100_height_100_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_stone_embossed_01_100_height_100_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, },
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.46875, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.46875, -0.375, -0.5, 0.46875, 0.375, -0.4375}, -- NodeBox9
			{-0.5, -0.5, -0.5, 0.5, -0.4375, -0.4375}, -- NodeBox10
			{-0.5, 0.4375, -0.5, 0.5, 0.5, -0.4375}, -- NodeBox11
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{ -0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_stone_embossed_01_100_height_100_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_wall_block_100_height_050_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, },
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.1875, 0.5, 0.5, 0.25}, -- NodeBox1
			{-0.46875, -0.46875, -0.25, 0.46875, 0.46875, -0.1875}, -- NodeBox2
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_wall_block_100_height_050_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_wall_brick_100_height_050_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, },
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.1875, 0.5, 0.5, 0.25}, -- NodeBox1
			{-0.46875, 0.03125, -0.25, 0.46875, 0.46875, -0.1875}, -- NodeBox2
			{0.03125, -0.46875, -0.25, 0.5, -0.03125, -0.1875}, -- NodeBox3
			{-0.5, -0.46875, -0.25, -0.03125, -0.03125, -0.1875}, -- NodeBox4
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_wall_brick_100_height_050_width", ''},
			{ '', wall_mat, ''},
		}
	})

end


lib_carved_stone.register_column2_base_100_height_100_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { "decoblocks_sandstone_pillar_top.png",
			"decoblocks_sandstone_pillar_top.png", 
			"decoblocks_sandstone_pillar.png",
			"decoblocks_sandstone_pillar.png", 
			"decoblocks_sandstone_pillar.png",
			"decoblocks_sandstone_pillar.png", 
		},
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
		   {-0.5, -0.5, -0.5, 0.5, 0.0, 0.5},
		   {-0.5, 0.0, -0.25, 0.5, 0.5, 0.25},
		   {-0.25, 0.0, -0.5, 0.25, 0.5, 0.5},
		   {-0.4375, 0.0, -0.4375, 0.4375, 0.4375, 0.4375},
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{ -0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_column_base_100_height_100_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_column2_pillar_100_height_100_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { "decoblocks_sandstone_pillar_top.png",
			"decoblocks_sandstone_pillar_top.png", 
			"decoblocks_sandstone_pillar.png",
			"decoblocks_sandstone_pillar.png", 
			"decoblocks_sandstone_pillar.png",
			"decoblocks_sandstone_pillar.png", 
		},
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.1875, -0.5, -0.5, 0.1875, 0.5, 0.5},
			{-0.5, -0.5, -0.1875, 0.5, 0.5, 0.1875},
			{-0.375, -0.5, -0.375, 0.375, 0.5, 0.375},
			{-0.3125, -0.5, -0.4375, 0.3125, 0.5, 0.4375},
			{-0.4375, -0.5, -0.3125, 0.4375, 0.5, 0.3125},
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.1875, -0.5, -0.5, 0.1875, 0.5, 0.5},
			{-0.5, -0.5, -0.1875, 0.5, 0.5, 0.1875},
			{-0.375, -0.5, -0.375, 0.375, 0.5, 0.375},
			{-0.3125, -0.5, -0.4375, 0.3125, 0.5, 0.4375},
			{-0.4375, -0.5, -0.3125, 0.4375, 0.5, 0.3125},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{-0.1875, -0.5, -0.5, 0.1875, 0.5, 0.5},
			{-0.5, -0.5, -0.1875, 0.5, 0.5, 0.1875},
			{-0.375, -0.5, -0.375, 0.375, 0.5, 0.375},
			{-0.3125, -0.5, -0.4375, 0.3125, 0.5, 0.4375},
			{-0.4375, -0.5, -0.3125, 0.4375, 0.5, 0.3125},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_column_base_100_height_100_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_column_ended_block_100_height_100_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { "decoblocks_sandstone_pillar_top.png",
			"decoblocks_sandstone_pillar_top.png", 
			"decoblocks_sandstone_pillar.png",
			"decoblocks_sandstone_pillar.png", 
			"decoblocks_sandstone_pillar.png",
			"decoblocks_sandstone_pillar.png", 
		},
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.1875, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.4375, -0.5, -0.3125, 0.4375, 0.5, -0.1875}, -- NodeBox2
			{-0.375, -0.5, -0.375, 0.375, 0.5, -0.3125}, -- NodeBox3
			{-0.3125, -0.5, -0.4375, 0.3125, 0.5, -0.375}, -- NodeBox4
			{-0.1875, -0.5, -0.5, 0.1875, 0.5, -0.4375}, -- NodeBox5
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{ -0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_column_base_100_height_100_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_wall_with_rounded_large_pillar_100_height_050_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { "decoblocks_sandstone_pillar_top.png",
			"decoblocks_sandstone_pillar_top.png", 
			"decoblocks_sandstone_pillar.png",
			"decoblocks_sandstone_pillar.png", 
			"decoblocks_sandstone_pillar.png",
			"decoblocks_sandstone_pillar.png", 
		},
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.125, 0.5, 0.5, 0.25}, -- NodeBox1
			{-0.4375, -0.5, -0.1875, 0.4375, 0.5, -0.125}, -- NodeBox2
			{-0.375, -0.5, -0.25, 0.375, 0.5, -0.1875}, -- NodeBox3
			{-0.3125, -0.5, -0.3125, 0.3125, 0.5, -0.25}, -- NodeBox4
			{-0.1875, -0.5, -0.375, 0.1875, 0.5, -0.3125}, -- NodeBox5
		},
	},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.375, 0.5, 0.5, 0.25},
		},
	},
	collision_box = {
		type = "fixed",
		fixed = {
			{ -0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		},
	},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_column_base_100_height_100_width", ''},
			{ '', wall_mat, ''},
		}
	})

end


lib_carved_stone.register_wall_egypt1_100_height_050_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, 
			wall_texture, 
			wall_texture, 
			wall_texture, 
			"decoblocks_sandstone_wall.png",
			"decoblocks_sandstone_wall.png", 
		},
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
		node_box = {
			type = "fixed",
			fixed = {
				{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}
			},
			},
		selection_box = {
			type = "fixed",
			fixed = {
				{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}
			},
		},
		collision_box = {
			type = "fixed",
			fixed = {
				{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}
			},
		},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_wall_100_height_050_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_wall_egypt2_100_height_050_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, 
			wall_texture, 
			wall_texture, 
			wall_texture, 
			"decoblocks_sandstone_wall2.png",
			"decoblocks_sandstone_wall2.png", 
		},
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
		node_box = {
			type = "fixed",
			fixed = {
				{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}
			},
			},
		selection_box = {
			type = "fixed",
			fixed = {
				{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}
			},
		},
		collision_box = {
			type = "fixed",
			fixed = {
				{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}
			},
		},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_wall_100_height_050_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_wall_egypt3_100_height_050_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, 
			wall_texture, 
			wall_texture, 
			wall_texture, 
			"decoblocks_sandstone_wall3.png",
			"decoblocks_sandstone_wall3.png", 
		},
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
		node_box = {
			type = "fixed",
			fixed = {
				{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}
			},
			},
		selection_box = {
			type = "fixed",
			fixed = {
				{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}
			},
		},
		collision_box = {
			type = "fixed",
			fixed = {
				{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}
			},
		},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_wall_100_height_050_width", ''},
			{ '', wall_mat, ''},
		}
	})

end

lib_carved_stone.register_wall_egypt4_100_height_050_width = function(wall_name, wall_desc, wall_texture, wall_mat, wall_sounds)

	minetest.register_node("lib_carved_stone:" .. wall_name, {
		description = wall_desc,
		drawtype = "nodebox",
		tiles = { wall_texture, 
			wall_texture, 
			wall_texture, 
			wall_texture, 
			"decoblocks_sandstone_wall4.png",
			"decoblocks_sandstone_wall4.png", 
		},
		paramtype = "light",
		paramtype2 = "facedir",
		connects_to = { "group:wall", "group:stone", "group:lib_carved_stone", "group:lib_doors", "group:lib_fences", "group:lib_general" },
		is_ground_content = false,
		walkable = true,
		groups = { cracky = 3, wall = 1, stone = 2, lib_carved_stone = 3 },
		sounds = wall_sounds,
		node_box = {
			type = "fixed",
			fixed = {
				{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}
			},
			},
		selection_box = {
			type = "fixed",
			fixed = {
				{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}
			},
		},
		collision_box = {
			type = "fixed",
			fixed = {
				{-0.5, -0.5, -0.25, 0.5, 0.5, 0.25}
			},
		},

		on_place = function(itemstack, placer, pointed_thing)
			if pointed_thing.type ~= "node" then
				return itemstack
			end

			local p0 = pointed_thing.under
			local p1 = pointed_thing.above
			local param2 = 0

			local placer_pos = placer:getpos()
			if placer_pos then
				local dir = {
					x = p1.x - placer_pos.x,
					y = p1.y - placer_pos.y,
					z = p1.z - placer_pos.z
				}
				param2 = minetest.dir_to_facedir(dir)
			end

			if p0.y-1 == p1.y then
				param2 = param2 + 20
				if param2 == 21 then
					param2 = 23
				elseif param2 == 23 then
					param2 = 21
				end
			end

			return minetest.item_place(itemstack, placer, pointed_thing, param2)
		end,
	})

	-- crafting recipe
	minetest.register_craft({
		output = "lib_carved_stone:" .. wall_name .. " 99",
		recipe = {
			{ '', '', '' },
			{ '', "lib_shapes:shape_wall_100_height_050_width", ''},
			{ '', wall_mat, ''},
		}
	})

end




lib_carved_stone.register_column2_base_100_height_100_width("egypt_sandstone_column_02", "Egyptian Sandstone Column 02 ", "default_sandstone.png",
		"default:sandstone", default.node_sound_stone_defaults())
lib_carved_stone.register_column2_pillar_100_height_100_width("egypt_sandstone_pillar_02", "Egyptian Sandstone Pillar 02 ", "default_sandstone.png",
		"default:sandstone", default.node_sound_stone_defaults())

lib_carved_stone.register_column_ended_block_100_height_100_width("column_ended_block_100_height_100_width", "column_ended_block_100_height_100_width", "default_sandstone.png",
		"default:sandstone", default.node_sound_stone_defaults())
lib_carved_stone.register_wall_with_rounded_large_pillar_100_height_050_width("wall_with_rounded_large_pillar_100_height_050_width", "wall_with_rounded_large_pillar_100_height_050_width ", "default_sandstone.png",
		"default:sandstone", default.node_sound_stone_defaults())


lib_carved_stone.register_wall_egypt1_100_height_050_width("egypt_sandstone_01", "Egyptian Sandstone 01 ", "default_sandstone.png",
		"default:sandstone", default.node_sound_stone_defaults())
lib_carved_stone.register_wall_egypt2_100_height_050_width("egypt_sandstone_02", "Egyptian Sandstone 02 ", "default_sandstone.png",
		"default:sandstone", default.node_sound_stone_defaults())
lib_carved_stone.register_wall_egypt3_100_height_050_width("egypt_sandstone_03", "Egyptian Sandstone 03 ", "default_sandstone.png",
		"default:sandstone", default.node_sound_stone_defaults())
lib_carved_stone.register_wall_egypt4_100_height_050_width("egypt_sandstone_04", "Egyptian Sandstone 04 ", "default_sandstone.png",
		"default:sandstone", default.node_sound_stone_defaults())




lib_carved_stone.register_nodes("cobble", "Cobblestone ", "default_cobble.png",
		"default:cobble", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("mossycobble", "Mossy Cobblestone ", "default_mossycobble.png",
		"default:mossycobble", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("desertcobble", "Desert Cobblestone ", "default_desert_cobble.png",
		"default:desert_cobble", default.node_sound_stone_defaults())

lib_carved_stone.register_nodes("sandstone", "Sandstone ", "default_sandstone.png",
		"default:sandstone", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("desert_stone", "Desert Stone ", "default_desert_stone.png",
		"default:desert_stone", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("desert_sandstone", "Desert Sand Stone ", "default_desert_sandstone.png",
		"default:desert_sandstone", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("stone", "Stone ", "default_stone.png",
		"default:stone", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("obsidian", "Obsidian ", "default_obsidian.png",
		"default:obsidian", default.node_sound_stone_defaults())

lib_carved_stone.register_nodes("sandstone_block", "Sandstone Block ", "default_sandstone_block.png",
		"default:sandstone_block", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("desert_stone_block", "Desert Stone Block ", "default_desert_stone_block.png",
		"default:desert_stone_block", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("desert_sandstone_block", "Desert Sand Stone Block ",
		"default_desert_sandstone_block.png","default:desert_sandstone_block", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("stone_block", "Stone Block ", "default_stone_block.png",
		"default:stone_block", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("obsidian_block", "Obsidian Block ", "default_obsidian_block.png",
		"default:obsidian_block", default.node_sound_stone_defaults())

lib_carved_stone.register_nodes("sandstone_brick", "Sandstone Brick ", "default_sandstone_brick.png",
		"default:sandstonebrick", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("desertstone_brick", "Desert Stone Brick ", "default_desert_stone_brick.png",
		"default:desert_stonebrick", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("desert_sandstone_brick", "Desert Stone Brick ",
		"default_desert_sandstone_brick.png","default:desert_sandstone_brick", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("stone_brick", "Stone Brick ", "default_stone_brick.png",
		"default:stonebrick", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("obsidian_brick", "Obsidian Brick ", "default_obsidian_brick.png",
		"default:obsidianbrick", default.node_sound_stone_defaults())



lib_carved_stone.register_nodes("glass", "Glass ", "default_glass.png",
		"default:glass", default.node_sound_stone_defaults())

--[[
		
lib_carved_stone.register_nodes("tree", "Tree ", "default_tree.png",
		"default:tree", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("wood", "Wood ", "default_wood.png",
		"default:wood", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("jungletree", "Jungle Tree ", "default_jungletree.png",
		"default:jungletree", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("junglewood", "Jungle Wood ", "default_junglewood.png",
		"default:junglewood", default.node_sound_stone_defaults())

lib_carved_stone.register_nodes("acacia_tree", "Acacia Tree ", "default_acacia_tree.png",
		"default:acacia_tree", default.node_sound_stone_defaults())
lib_carved_stone.register_nodes("acacia_wood", "Acacia Wood ", "default_acacia_wood.png",
		"default:acacia_wood", default.node_sound_stone_defaults())

--]]










