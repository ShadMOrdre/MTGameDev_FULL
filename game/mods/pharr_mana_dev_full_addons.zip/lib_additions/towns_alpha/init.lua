--package.cpath = package.cpath .. ";/usr/share/lua/5.2/?.so"
--package.path = package.path .. ";/usr/share/zbstudio/lualibs/mobdebug/?.lua"
--require('mobdebug').start()

towns_alpha = {}
towns_alpha.modpath = minetest.get_modpath("towns_alpha");

dofile(towns_alpha.modpath.."/schematics.lua")
dofile(towns_alpha.modpath.."/schem_settlements.lua")
dofile(towns_alpha.modpath.."/schem_villages.lua")
--dofile(towns_alpha.modpath.."/schem_tent.lua")
dofile(towns_alpha.modpath.."/schem_ruins.lua")
--dofile(towns_alpha.modpath.."/schem_gambit.lua")
dofile(towns_alpha.modpath.."/const.lua")
dofile(towns_alpha.modpath.."/utils.lua")
dofile(towns_alpha.modpath.."/foundation.lua")
dofile(towns_alpha.modpath.."/buildings.lua")
dofile(towns_alpha.modpath.."/paths.lua")
--
-- load towns_alpha on server
--
towns_alpha_settled_areas_in_world = towns_alpha.load()
--
-- register block for npc spawn
--
minetest.register_node("towns_alpha:junglewood", {
    description = "special junglewood floor",
    tiles = {"default_junglewood.png"},
    groups = {choppy=3, wood=2},
    sounds = default.node_sound_wood_defaults(),
  })
--
-- register inhabitants
--
if minetest.get_modpath("mobs_npc") ~= nil then
  mobs:register_spawn("mobs_npc:npc", --name
    {"towns_alpha:junglewood"}, --nodes
    20, --max_light
    0, --min_light
    20, --chance
    7, --active_object_count
    31000, --max_height
    nil) --day_toggle
  mobs:register_spawn("mobs_npc:trader", --name
    {"towns_alpha:junglewood"}, --nodes
    20, --max_light
    0, --min_light
    20, --chance
    7, --active_object_count
    31000, --max_height
    nil)--day_toggle
end 
--
-- on map generation, try to build a settlement
--
minetest.register_on_generated(function(minp, maxp)
    --
    -- randomly try to build towns_alpha
    -- 
	--math.randomseed(2)
	local TownChance = math.random(1,5)
    if TownChance < 2 then 
      --
      -- don't build settlement underground
      --
      if maxp.y < 0 then 
        return 
      end
      --
      -- don't build towns_alpha too close to each other
      --
      local center_of_chunk = { 
        x=maxp.x-towns_alpha_half_map_chunk_size, 
        y=maxp.y-towns_alpha_half_map_chunk_size, 
        z=maxp.z-towns_alpha_half_map_chunk_size
      } 
      local dist_ok = towns_alpha.check_distance_other_towns_alpha(center_of_chunk)
      if dist_ok == false 
      then
        return
      end
      --
      -- don't build towns_alpha on (too) uneven terrain
      --
      local height_difference = towns_alpha.evaluate_heightmap(minp, maxp)
      if height_difference > towns_alpha_max_height_difference 
      then
        return
      end
      -- 
      -- if nothing prevents the settlement -> do it
      --
      towns_alpha.place_settlement_circle(minp, maxp)

    end
  end)
--
-- manually place buildings, for debugging only
--
minetest.register_craftitem("towns_alpha:tool", {
    description = "towns_alpha build tool",
    inventory_image = "default_tool_woodshovel.png",
    --
    -- build single house
    --
    on_use = function(itemstack, placer, pointed_thing)
      local center_surface = pointed_thing.under
      if center_surface then
        local building_all_info = {name = "bldg_tower_x9_y15_z8_r180", 
                                   mts = towns_alpha.schem_bldg_tower_x9_y15_z8_r180, 
                                   hsize = 11, 
                                   max_num = 0.050, 
                                   rplc = "n"}
        towns_alpha.build_schematic(center_surface, 
                                    building_all_info["mts"],
                                    building_all_info["rplc"], 
                                    building_all_info["name"])

--        towns_alpha.convert_mts_to_lua()
--        towns_alpha.mts_save()
      end
    end,
    --
    -- build ssettlement
    --
    on_place = function(itemstack, placer, pointed_thing)
      -- enable debug routines
      towns_alpha.debug = true
      local center_surface = pointed_thing.under
      if center_surface then
        local minp = {
          x=center_surface.x-towns_alpha_half_map_chunk_size, 
          y=center_surface.y-towns_alpha_half_map_chunk_size, 
          z=center_surface.z-towns_alpha_half_map_chunk_size
          }
        local maxp = {
          x=center_surface.x+towns_alpha_half_map_chunk_size, 
          y=center_surface.y+towns_alpha_half_map_chunk_size, 
          z=center_surface.z+towns_alpha_half_map_chunk_size
          }
        towns_alpha.place_settlement_circle(minp, maxp)
      end
    end
  })

