--
-- switch for debugging
--
towns_lumberjack.debug = false
--
-- material to replace cobblestone with
--
towns_lumberjack_wallmaterial = {
  "default:cobble", 
  "default:desert_cobble", 
  "default:mossycobble"
}
--
-- path to schematics
--
towns_lumberjack_schem_path = towns_lumberjack.modpath.."/schematics/"
--
-- list of schematics
--  {name = "townhall", mts = towns_lumberjack_schem_path.."townhall.mts", hsize = 15, max_num = 0, rplc = "n"},
--  {name = "well", mts = towns_lumberjack_schem_path.."well.mts", hsize = 11, max_num = 0.045, rplc = "n"},
--  {name = "hut", mts = towns_lumberjack_schem_path.."hut.mts", hsize = 11, max_num = 0.9, rplc = "y"},
--  {name = "garden", mts = towns_lumberjack_schem_path.."garden.mts", hsize = 11, max_num = 0.1, rplc = "n"},
--  {name = "lamp", mts = towns_lumberjack_schem_path.."lamp.mts", hsize = 10, max_num = 0.1, rplc = "n"},
--  {name = "tower", mts = towns_lumberjack_schem_path.."tower.mts", hsize = 11, max_num = 0.055, rplc = "n"},
--  {name = "church", mts = towns_lumberjack_schem_path.."church.mts", hsize = 17, max_num = 0.050, rplc = "n"},
--  {name = "blacksmith", mts = towns_lumberjack_schem_path.."blacksmith.mts", hsize = 11, max_num = 0.050, rplc = "n"},
--
--[[
--]]
--
towns_lumberjack_schematic_table = { 
  {name = "mgs_tower_new_02_10w_8l_17h_0_90", mts = towns_lumberjack_schem_path.."mgs_tower_new_02_10w_8l_17h_0_90.mts", hsize = 14, max_num = 0, rplc = "n"},
  {name = "settlements_townhall", mts = towns_lumberjack_schem_path.."settlements_townhall.mts", hsize = 15, max_num = 0.050, rplc = "n"},
  {name = "settlements_well", mts = towns_lumberjack_schem_path.."settlements_well.mts", hsize = 11, max_num = 0.045, rplc = "n"},
  {name = "mgs_mine_new_02_13w_9l_31h_0_270", mts = towns_lumberjack_schem_path.."mgs_mine_new_02_13w_9l_31h_0_270.mts", hsize = 25, max_num = 0.050, rplc = "n"},
  {name = "settlements_hut", mts = towns_lumberjack_schem_path.."settlements_hut.mts", hsize = 11, max_num = 0.9, rplc = "y"},
  {name = "settlements_garden", mts = towns_lumberjack_schem_path.."settlements_garden.mts", hsize = 11, max_num = 0.1, rplc = "n"},
  {name = "settlements_lamp", mts = towns_lumberjack_schem_path.."settlements_lamp.mts", hsize = 10, max_num = 0.1, rplc = "n"},
  {name = "settlements_tower", mts = towns_lumberjack_schem_path.."settlements_tower.mts", hsize = 11, max_num = 0.055, rplc = "n"},
  {name = "settlements_church", mts = towns_lumberjack_schem_path.."settlements_church.mts", hsize = 17, max_num = 0.050, rplc = "n"},
  {name = "settlements_blacksmith", mts = towns_lumberjack_schem_path.."settlements_blacksmith.mts", hsize = 11, max_num = 0.050, rplc = "n"},
  {name = "mgs_turret_new_01_6w_6l_9h_0_90", mts = towns_lumberjack_schem_path.."mgs_turret_new_01_6w_6l_9h_0_90.mts", hsize = 10, max_num = 0.075, rplc = "n"},
}
towns_lumberjack_schematic_table2 = { 
  {name = "bldg_lumberjack_church_x9_y19_z14_r000", mts = towns_lumberjack.schem_bldg_lumberjack_church_x9_y19_z14_r000, hsize = 18, max_num = 0, rplc = "n", rot = "90", off = 0},
  {name = "bldg_lumberjack_hotel_x16_y10_z19_r000", mts = towns_lumberjack.schem_bldg_lumberjack_hotel_x16_y10_z19_r000, hsize = 23, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_lumberjack_school_x10_y12_z16_r000", mts = towns_lumberjack.schem_bldg_lumberjack_school_x10_y12_z16_r000, hsize = 20, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_lavabeacon_x9_y24_z9_r90", mts = towns_lumberjack.schem_bldg_lavabeacon_x9_y24_z9_r90, hsize = 13, max_num = 0.025, rplc = "n", rot = "-1", off = 1},
  {name = "bldg_lumberjack_shop_1_x11_y16_z14_r000", mts = towns_lumberjack.schem_bldg_lumberjack_shop_1_x11_y16_z14_r000, hsize = 18, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_lumberjack_sawmill_x12_y17_z22_r000", mts = towns_lumberjack.schem_bldg_lumberjack_sawmill_x12_y17_z22_r000, hsize = 26, max_num = 0.050, rplc = "n", rot = "-1", off = -5},
  {name = "bldg_lumberjack_stable_x14_y13_z16_r000", mts = towns_lumberjack.schem_bldg_lumberjack_stable_x14_y13_z16_r000, hsize = 20, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_lumberjack_pub_x11_y9_z12_r000", mts = towns_lumberjack.schem_bldg_lumberjack_pub_x11_y9_z12_r000, hsize = 16, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_logcabin_1_x7_y9_z6_r000", mts = towns_lumberjack.schem_bldg_logcabin_1_x7_y9_z6_r000, hsize = 11, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_logcabin_2_x6_y8_z4_r000", mts = towns_lumberjack.schem_bldg_logcabin_2_x6_y8_z4_r000, hsize = 10, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_logcabin_3_x6_y10_z6_r000", mts = towns_lumberjack.schem_bldg_logcabin_3_x6_y10_z6_r000, hsize = 10, max_num = 0.065, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_logcabin_4_x5_y11_z7_r000", mts = towns_lumberjack.schem_bldg_logcabin_4_x5_y11_z7_r000, hsize = 11, max_num = 0.035, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_logcabin_5_x5_y9_z5_r000", mts = towns_lumberjack.schem_bldg_logcabin_5_x5_y9_z5_r000, hsize = 9, max_num = 0.035, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_logcabin_6_x5_y9_z7_r000", mts = towns_lumberjack.schem_bldg_logcabin_6_x5_y9_z7_r000, hsize = 11, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_logcabin_7_x7_y10_z7_r000", mts = towns_lumberjack.schem_bldg_logcabin_7_x7_y10_z7_r000, hsize = 11, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
}
--[[
--  {name = "bldg_fortress_x25_y22_z23_r90", mts = towns_lumberjack.schem_bldg_fortress_x25_y22_z23_r90, hsize = 27, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
--]]
--
-- baseplate material, to replace dirt with grass and where buildings can be built
--
towns_lumberjack_surface_mat = {
 	"lib_materials:dirt_with_grass_cool_humid_coastal",
 	"lib_materials:dirt_with_grass_cool_humid_lowland",
 	--"lib_materials:dirt_with_grass_cool_humid_shelf",
 	--"lib_materials:dirt_with_grass_cool_semihumid_coastal",
 	--"lib_materials:dirt_with_grass_cool_semihumid_lowland",
 	--"lib_materials:dirt_with_grass_cool_semihumid_shelf",

}
--
-- temporary info for currentliy built settlement (position of each building) 
--
towns_lumberjack_settlement_info = {}
--
-- list of towns_lumberjack, load on server start up
--
towns_lumberjack_settled_areas_in_world = {}
--
-- min_distance between towns_lumberjack
--
min_dist_towns_lumberjack = 1000
if towns_lumberjack.debug == true 
then
  min_dist_towns_lumberjack = 200
end
--
-- maximum allowed difference in height for building a sttlement
--
towns_lumberjack_max_height_difference = 3
--
--
--
towns_lumberjack_half_map_chunk_size = 40
towns_lumberjack_quarter_map_chunk_size = 20
