--
-- switch for debugging
--
towns_royal.debug = false
--
-- material to replace cobblestone with
--
towns_royal_wallmaterial = {
  "default:cobble", 
  "default:desert_cobble", 
  "default:mossycobble"
}
--
-- path to schematics
--
towns_royal_schem_path = towns_royal.modpath.."/schematics/"
--
-- list of schematics
--  {name = "townhall", mts = towns_royal_schem_path.."townhall.mts", hsize = 15, max_num = 0, rplc = "n"},
--  {name = "well", mts = towns_royal_schem_path.."well.mts", hsize = 11, max_num = 0.045, rplc = "n"},
--  {name = "hut", mts = towns_royal_schem_path.."hut.mts", hsize = 11, max_num = 0.9, rplc = "y"},
--  {name = "garden", mts = towns_royal_schem_path.."garden.mts", hsize = 11, max_num = 0.1, rplc = "n"},
--  {name = "lamp", mts = towns_royal_schem_path.."lamp.mts", hsize = 10, max_num = 0.1, rplc = "n"},
--  {name = "tower", mts = towns_royal_schem_path.."tower.mts", hsize = 11, max_num = 0.055, rplc = "n"},
--  {name = "church", mts = towns_royal_schem_path.."church.mts", hsize = 17, max_num = 0.050, rplc = "n"},
--  {name = "blacksmith", mts = towns_royal_schem_path.."blacksmith.mts", hsize = 11, max_num = 0.050, rplc = "n"},
--
--[[
--]]
--
towns_royal_schematic_table2 = { 
  {name = "bldg_peak_church_1_x37_y51_z49_r000", mts = towns_royal.schem_bldg_peak_church_1_x37_y51_z49_r000, hsize = 55, max_num = 0, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_mgs_stone_5s_02_x24_y23_z18_r180", mts = towns_royal.schem_bldg_mgs_stone_5s_02_x24_y23_z18_r180, hsize = 28, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_mgs_mansion_1_x24_y16_z19_r090", mts = towns_royal.schem_bldg_mgs_mansion_1_x24_y16_z19_r090, hsize = 28, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_mgs_mansion_1_x29_y11_z21_r270", mts = towns_royal.schem_bldg_mgs_mansion_1_x29_y11_z21_r270, hsize = 33, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_peak_mausoleum_1_x25_y40_z25_r000", mts = towns_royal.schem_bldg_peak_mausoleum_1_x25_y40_z25_r000, hsize = 30, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
}



--
-- baseplate material, to replace dirt with grass and where buildings can be built
--
towns_royal_surface_mat = {
 	"lib_materials:dirt_with_grass_temperate_temperate_lowland",
}
--
-- temporary info for currentliy built settlement (position of each building) 
--
towns_royal_settlement_info = {}
--
-- list of towns_royal, load on server start up
--
towns_royal_settled_areas_in_world = {}
--
-- min_distance between towns_royal
--
min_dist_towns_royal = 1000
if towns_royal.debug == true 
then
  min_dist_towns_royal = 200
end
--
-- maximum allowed difference in height for building a sttlement
--
towns_royal_max_height_difference = 4
--
--
--
towns_royal_half_map_chunk_size = 40
towns_royal_quarter_map_chunk_size = 20
