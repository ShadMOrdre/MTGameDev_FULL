--
-- switch for debugging
--
towns_cottages.debug = false
--
-- material to replace cobblestone with
--
towns_cottages_wallmaterial = {
  "default:cobble", 
  "default:desert_cobble", 
  "default:mossycobble"
}
--
-- path to schematics
--
towns_cottages_schem_path = towns_cottages.modpath.."/schematics/"
--
-- list of schematics
--  {name = "townhall", mts = towns_cottages_schem_path.."townhall.mts", hsize = 15, max_num = 0, rplc = "n"},
--  {name = "well", mts = towns_cottages_schem_path.."well.mts", hsize = 11, max_num = 0.045, rplc = "n"},
--  {name = "hut", mts = towns_cottages_schem_path.."hut.mts", hsize = 11, max_num = 0.9, rplc = "y"},
--  {name = "garden", mts = towns_cottages_schem_path.."garden.mts", hsize = 11, max_num = 0.1, rplc = "n"},
--  {name = "lamp", mts = towns_cottages_schem_path.."lamp.mts", hsize = 10, max_num = 0.1, rplc = "n"},
--  {name = "tower", mts = towns_cottages_schem_path.."tower.mts", hsize = 11, max_num = 0.055, rplc = "n"},
--  {name = "church", mts = towns_cottages_schem_path.."church.mts", hsize = 17, max_num = 0.050, rplc = "n"},
--  {name = "blacksmith", mts = towns_cottages_schem_path.."blacksmith.mts", hsize = 11, max_num = 0.050, rplc = "n"},
--
--[[
--]]
--
towns_cottages_schematic_table_orig = { 
  {name = "mgs_tower_new_02_10w_8l_17h_0_90", mts = towns_cottages_schem_path.."mgs_tower_new_02_10w_8l_17h_0_90.mts", hsize = 14, max_num = 0, rplc = "n"},
  {name = "settlements_townhall", mts = towns_cottages_schem_path.."settlements_townhall.mts", hsize = 15, max_num = 0.050, rplc = "n"},
  {name = "settlements_well", mts = towns_cottages_schem_path.."settlements_well.mts", hsize = 11, max_num = 0.045, rplc = "n"},
  {name = "mgs_mine_new_02_13w_9l_31h_0_270", mts = towns_cottages_schem_path.."mgs_mine_new_02_13w_9l_31h_0_270.mts", hsize = 25, max_num = 0.050, rplc = "n"},
  {name = "settlements_hut", mts = towns_cottages_schem_path.."settlements_hut.mts", hsize = 11, max_num = 0.9, rplc = "y"},
  {name = "settlements_garden", mts = towns_cottages_schem_path.."settlements_garden.mts", hsize = 11, max_num = 0.1, rplc = "n"},
  {name = "settlements_lamp", mts = towns_cottages_schem_path.."settlements_lamp.mts", hsize = 10, max_num = 0.1, rplc = "n"},
  {name = "settlements_tower", mts = towns_cottages_schem_path.."settlements_tower.mts", hsize = 11, max_num = 0.055, rplc = "n"},
  {name = "settlements_church", mts = towns_cottages_schem_path.."settlements_church.mts", hsize = 17, max_num = 0.050, rplc = "n"},
  {name = "settlements_blacksmith", mts = towns_cottages_schem_path.."settlements_blacksmith.mts", hsize = 11, max_num = 0.050, rplc = "n"},
  {name = "mgs_turret_new_01_6w_6l_9h_0_90", mts = towns_cottages_schem_path.."mgs_turret_new_01_6w_6l_9h_0_90.mts", hsize = 10, max_num = 0.075, rplc = "n"},
}
towns_cottages_schematic_table_bak = { 
  {name = "bldg_castle_x27_y16_z33_r90", mts = towns_cottages.schem_bldg_castle_x27_y15_z33_r90, hsize = 40, max_num = 0, rplc = "n", rot = "270", off = 0},
  {name = "bldg_church_stone_x11_y16_z20_r000", mts = towns_cottages.schem_bldg_church_stone_x11_y16_z20_r000, hsize = 25, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_settlements_townhall_x10_y12_z11_r000", mts = towns_cottages.schem_bldg_settlements_townhall_x10_y12_z11_r000, hsize = 15, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_lavabeacon_x9_y24_z9_r90", mts = towns_cottages.schem_bldg_lavabeacon_x9_y24_z9_r90, hsize = 13, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_settlements_well_x5_y5_z5_r000", mts = towns_cottages.schem_bldg_settlements_well_x5_y5_z5_r000, hsize = 9, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_settlements_lamp_x3_y7_z3_r000", mts = towns_cottages.schem_bldg_settlements_lamp_x3_y7_z3_r000, hsize = 7, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_village_farm_01_x9_y3_z13_r000", mts = towns_cottages.schem_bldg_village_farm_01_x9_y3_z13_r000, hsize = 19, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_village_05_x15_y13_z9_r000", mts = towns_cottages.schem_bldg_village_05_x15_y13_z9_r000, hsize = 19, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_village_06_x15_y13_z13_r000", mts = towns_cottages.schem_bldg_village_06_x15_y13_z13_r000, hsize = 19, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_village_07_x15_y13_z15_r000", mts = towns_cottages.schem_bldg_village_07_x15_y13_z15_r000, hsize = 19, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_hut_x7_y8_z7_r180", mts = towns_cottages.schem_bldg_hut_x7_y8_z7_r180, hsize = 11, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_forge_x8_y9_z9_r270", mts = towns_cottages.schem_bldg_forge_x8_y9_z9_r270, hsize = 12, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_mine_x11_y29_z9_r180", mts = towns_cottages.schem_bldg_mine_x11_y29_z9_r180, hsize = 15, max_num = 0.050, rplc = "n", rot = "0", off = 0},
  {name = "bldg_turret_x6_y9_z6_r180", mts = towns_cottages.schem_bldg_turret_x6_y9_z6_r180, hsize = 10, max_num = 0.050, rplc = "n", rot = "0", off = 0},
  {name = "bldg_tower_x9_y15_z8_r180", mts = towns_cottages.schem_bldg_tower_x9_y15_z8_r180, hsize = 13, max_num = 0.050, rplc = "n", rot = "0", off = 0},
}
towns_cottages_schematic_table2 = { 
  {name = "bldg_cottages_church_1_x26_y26_z12_r000", mts = towns_cottages.schem_bldg_cottages_church_1_x26_y26_z12_r000, hsize = 30, max_num = 0, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_watermill_x17_y22_z22_r000", mts = towns_cottages.schem_bldg_cottages_watermill_x17_y22_z22_r000, hsize = 27, max_num = 0.050, rplc = "n", rot = "-1", off = -2},
  {name = "bldg_cottages_mill_x15_y22_z15_r000", mts = towns_cottages.schem_bldg_cottages_mill_x15_y22_z15_r000, hsize = 27, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_shed_forge_x9_y11_z9_r000", mts = towns_cottages.schem_bldg_cottages_shed_forge_x9_y11_z9_r000, hsize = 15, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_farm_full_1_x14_y10_z13_r000", mts = towns_cottages.schem_bldg_cottages_farm_full_1_x14_y10_z13_r000, hsize = 18, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_farm_full_2_x18_y13_z14_r000", mts = towns_cottages.schem_bldg_cottages_farm_full_2_x18_y13_z14_r000, hsize = 22, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_farm_full_3_x14_y11_z16_r000", mts = towns_cottages.schem_bldg_cottages_farm_full_3_x14_y11_z16_r000, hsize = 20, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_farm_full_4_x18_y14_z18_r000", mts = towns_cottages.schem_bldg_cottages_farm_full_4_x18_y14_z18_r000, hsize = 23, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_chateau_wo_garden_x32_y30_z23_r000", mts = towns_cottages.schem_bldg_cottages_chateau_wo_garden_x32_y30_z23_r000, hsize = 36, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_farm_tiny_1_x14_y8_z12_r000", mts = towns_cottages.schem_bldg_cottages_farm_tiny_1_x14_y8_z12_r000, hsize = 18, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_farm_tiny_2_x12_y10_z16_r000", mts = towns_cottages.schem_bldg_cottages_farm_tiny_2_x12_y10_z16_r000, hsize = 20, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_farm_tiny_3_x15_y14_z16_r000", mts = towns_cottages.schem_bldg_cottages_farm_tiny_3_x15_y14_z16_r000, hsize = 20, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_farm_tiny_4_x14_y10_z17_r000", mts = towns_cottages.schem_bldg_cottages_farm_tiny_4_x14_y10_z17_r000, hsize = 22, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_farm_tiny_5_x13_y9_z19_r000", mts = towns_cottages.schem_bldg_cottages_farm_tiny_5_x13_y9_z19_r000, hsize = 24, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_farm_tiny_6_x15_y10_z14_r000", mts = towns_cottages.schem_bldg_cottages_farm_tiny_6_x15_y10_z14_r000, hsize = 20, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_farm_tiny_7_x14_y14_z13_r000", mts = towns_cottages.schem_bldg_cottages_farm_tiny_7_x14_y14_z13_r000, hsize = 18, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_cow_shed_1_x16_y10_z18_r000", mts = towns_cottages.schem_bldg_cottages_cow_shed_1_x16_y10_z18_r000, hsize = 22, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_baking_house_1_x9_y12_z12_r000", mts = towns_cottages.schem_bldg_cottages_baking_house_1_x9_y12_z12_r000, hsize = 16, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_baking_house_2_x9_y14_z12_r000", mts = towns_cottages.schem_bldg_cottages_baking_house_2_x9_y14_z12_r000, hsize = 16, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_baking_house_3_x9_y12_z14_r000", mts = towns_cottages.schem_bldg_cottages_baking_house_3_x9_y12_z14_r000, hsize = 18, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_baking_house_4_x11_y15_z16_r000", mts = towns_cottages.schem_bldg_cottages_baking_house_4_x11_y15_z16_r000, hsize = 20, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_taverne_1_x18_y22_z20_r000", mts = towns_cottages.schem_bldg_cottages_taverne_1_x18_y22_z20_r000, hsize = 26, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_taverne_2_x11_y14_z13_r000", mts = towns_cottages.schem_bldg_cottages_taverne_2_x11_y14_z13_r000, hsize = 18, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_taverne_3_x15_y14_z15_r000", mts = towns_cottages.schem_bldg_cottages_taverne_3_x15_y14_z15_r000, hsize = 20, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_taverne_4_x10_y7_z12_r000", mts = towns_cottages.schem_bldg_cottages_taverne_4_x10_y7_z12_r000, hsize = 16, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_cottages_field_cotton_x9_y2_z9_r000", mts = towns_cottages.schem_bldg_cottages_field_cotton_x9_y2_z9_r000, hsize = 13, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
}
--[[
  {name = "bldg_cottages_library_x12_y9_z11_r000", mts = towns_cottages.schem_bldg_cottages_library_x12_y9_z11_r000, hsize = 16, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_village_03_x13_y8_z7_r000", mts = towns_cottages.schem_bldg_village_03_x13_y8_z7_r000, hsize = 17, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_village_04_x19_y13_z14_r000", mts = towns_cottages.schem_bldg_village_04_x19_y13_z14_r000, hsize = 23, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
--  {name = "bldg_fortress_x25_y22_z23_r90", mts = towns_cottages.schem_bldg_fortress_x25_y22_z23_r90, hsize = 27, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
--]]
--
-- baseplate material, to replace dirt with grass and where buildings can be built
--
towns_cottages_surface_mat = {
 	"lib_materials:dirt_with_grass_temperate_temperate_coastal",
}
--
-- temporary info for currentliy built settlement (position of each building) 
--
towns_cottages_settlement_info = {}
--
-- list of towns_cottages, load on server start up
--
towns_cottages_settled_areas_in_world = {}
--
-- min_distance between towns_cottages
--
min_dist_towns_cottages = 1000
if towns_cottages.debug == true 
then
  min_dist_towns_cottages = 200
end
--
-- maximum allowed difference in height for building a sttlement
--
towns_cottages_max_height_difference = 4
--
--
--
towns_cottages_half_map_chunk_size = 40
towns_cottages_quarter_map_chunk_size = 20
