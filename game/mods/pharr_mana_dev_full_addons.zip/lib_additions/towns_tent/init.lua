--package.cpath = package.cpath .. ";/usr/share/lua/5.2/?.so"
--package.path = package.path .. ";/usr/share/zbstudio/lualibs/mobdebug/?.lua"
--require('mobdebug').start()

towns_tent = {}
towns_tent.modpath = minetest.get_modpath("towns_tent");

--dofile(towns_tent.modpath.."/schematics.lua")
--dofile(towns_tent.modpath.."/schem_settlements.lua")
--dofile(towns_tent.modpath.."/schem_villages.lua")
dofile(towns_tent.modpath.."/schem_tent.lua")
dofile(towns_tent.modpath.."/schem_ruins.lua")
--dofile(towns_tent.modpath.."/schem_gambit.lua")
dofile(towns_tent.modpath.."/const.lua")
dofile(towns_tent.modpath.."/utils.lua")
dofile(towns_tent.modpath.."/foundation.lua")
dofile(towns_tent.modpath.."/buildings.lua")
dofile(towns_tent.modpath.."/paths.lua")
--
-- load towns_tent on server
--
towns_tent_settled_areas_in_world = towns_tent.load()
--
-- register block for npc spawn
--
minetest.register_node("towns_tent:junglewood", {
    description = "special junglewood floor",
    tiles = {"default_junglewood.png"},
    groups = {choppy=3, wood=2},
    sounds = default.node_sound_wood_defaults(),
  })
--
-- register inhabitants
--
if minetest.get_modpath("mobs_npc") ~= nil then
  mobs:register_spawn("mobs_npc:npc", --name
    {"towns_tent:junglewood"}, --nodes
    20, --max_light
    0, --min_light
    20, --chance
    7, --active_object_count
    31000, --max_height
    nil) --day_toggle
  mobs:register_spawn("mobs_npc:trader", --name
    {"towns_tent:junglewood"}, --nodes
    20, --max_light
    0, --min_light
    20, --chance
    7, --active_object_count
    31000, --max_height
    nil)--day_toggle
end 
--
-- on map generation, try to build a settlement
--
minetest.register_on_generated(function(minp, maxp)
    --
    -- randomly try to build towns_tent
    -- 
	--math.randomseed(2)
	local TownChance = math.random(1,5)
    if TownChance < 2 then 
      --
      -- don't build settlement underground
      --
      if maxp.y < 0 then 
        return 
      end
      --
      -- don't build towns_tent too close to each other
      --
      local center_of_chunk = { 
        x=maxp.x-towns_tent_half_map_chunk_size, 
        y=maxp.y-towns_tent_half_map_chunk_size, 
        z=maxp.z-towns_tent_half_map_chunk_size
      } 
      local dist_ok = towns_tent.check_distance_other_towns_tent(center_of_chunk)
      if dist_ok == false 
      then
        return
      end
      --
      -- don't build towns_tent on (too) uneven terrain
      --
      local height_difference = towns_tent.evaluate_heightmap(minp, maxp)
      if height_difference > towns_tent_max_height_difference 
      then
        return
      end
      -- 
      -- if nothing prevents the settlement -> do it
      --
      towns_tent.place_settlement_circle(minp, maxp)

    end
  end)
--
-- manually place buildings, for debugging only
--
minetest.register_craftitem("towns_tent:tool", {
    description = "towns_tent build tool",
    inventory_image = "default_tool_woodshovel.png",
    --
    -- build single house
    --
    on_use = function(itemstack, placer, pointed_thing)
      local center_surface = pointed_thing.under
      if center_surface then
        local building_all_info = {name = "bldg_tower_x9_y15_z8_r180", 
                                   mts = towns_tent.schem_bldg_tower_x9_y15_z8_r180, 
                                   hsize = 11, 
                                   max_num = 0.050, 
                                   rplc = "n"}
        towns_tent.build_schematic(center_surface, 
                                    building_all_info["mts"],
                                    building_all_info["rplc"], 
                                    building_all_info["name"])

--        towns_tent.convert_mts_to_lua()
--        towns_tent.mts_save()
      end
    end,
    --
    -- build ssettlement
    --
    on_place = function(itemstack, placer, pointed_thing)
      -- enable debug routines
      towns_tent.debug = true
      local center_surface = pointed_thing.under
      if center_surface then
        local minp = {
          x=center_surface.x-towns_tent_half_map_chunk_size, 
          y=center_surface.y-towns_tent_half_map_chunk_size, 
          z=center_surface.z-towns_tent_half_map_chunk_size
          }
        local maxp = {
          x=center_surface.x+towns_tent_half_map_chunk_size, 
          y=center_surface.y+towns_tent_half_map_chunk_size, 
          z=center_surface.z+towns_tent_half_map_chunk_size
          }
        towns_tent.place_settlement_circle(minp, maxp)
      end
    end
  })

