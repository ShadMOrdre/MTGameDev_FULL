local path = minetest.get_modpath("decoblocks")

dofile(path.."/nodes.lua")
dofile(path.."/crafts.lua")
dofile(path.."/lantern.lua")