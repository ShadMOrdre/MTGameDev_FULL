
------------------------------------------------------------------NODES
----------------------------------------------------------------

-- Node water_rushing
--Erodes sand and dirt while finding quickest path to terrain y = -1

minetest.register_node("lib_rivers:water_rushing", {
	description = S("Rushing Water"),
	_doc_items_longdesc = S("Erodes single path through sand, dirt, and stone"),
	_doc_items_usagehelp = S("This node seeks the shortest path to the next lowest elevation, carving a singlenode path and leaving behind, first a custom 'river' water node that ultimately turns into a default:river_water_source node.  This node is spawned automatically at either a spring, or a snow_melt."),
	light_source = 8,
	tiles = {"selfrep_tower.png"},
	paramtype = "light",
	groups = {cracky = 3, flammable = 2, oddly_breakable_by_hand=1},
	sounds = default.node_sound_metal_defaults(),

	--node lifespan
	on_construct = function(pos)
		minetest.get_node_timer(pos):start(1800)
	end,
	on_timer = function(pos, elapsed)
		minetest.set_node(pos, {name = "lib_rivers:river_water"})
	end,
})


minetest.register_node('lib_rivers:river_water', {
	description = S("River Water"),
	_doc_items_longdesc = S("Prevents flooding from river_water_source nodes."),
	_doc_items_usagehelp = S("A temporary river_water node, created by the water_rushing node.  It serves to prevent flooding from river_water_source nodes that this node turns into."),
	tiles = {
		{
			name = "default_river_water_source_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	paramtype = "light",
	walkable = false,
	pointable = true,
	diggable = true,
	buildable_to = false,
	is_ground_content = false,
	groups = {cracky = 3, oddly_breakable_by_hand=1},
	sounds = default.node_sound_metal_defaults(),

	--node lifespan
	on_construct = function(pos)
		minetest.get_node_timer(pos):start(300)
	end,
	on_timer = function(pos, elapsed)
		minetest.set_node(pos, {name = "default:river_water_source"})
	end,
})



--[[
	tiles = {
		{
			name = "default_river_water_source_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	special_tiles = {
		{
			name = "default_river_water_source_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
			backface_culling = false,
		},
	},
	--alpha = 160,
	drop = "",
	drowning = 1,

--]]



minetest.register_node("lib_rivers:spring", {
	description = S("Spring"),
	_doc_items_longdesc = S("A natural spring that generates an endless stream of water source blocks"),
	_doc_items_usagehelp = S("Generates one source block of water directly on top of itself once per second, provided the space is clear. If this natural spring is dug out the flow stops and it is turned into ordinary cobble."),
	drops = "default:gravel",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"default_cobble.png^[combine:16x80:0,-48=crack_anylength.png",
		"default_cobble.png^[combine:16x80:0,-48=crack_anylength.png",
		"default_cobble.png^[combine:16x80:0,-48=crack_anylength.png",
		"default_cobble.png^[combine:16x80:0,-48=crack_anylength.png",
		"default_cobble.png^[combine:16x80:0,-48=crack_anylength.png",
		"default_cobble.png^[combine:16x80:0,-48=crack_anylength.png",
		},
	is_ground_content = false,
	groups = {cracky = 3, stone = 2},
	sounds = default.node_sound_gravel_defaults(),
})
	

minetest.register_node("lib_rivers:snow_melt", {
	description = S("Snow Melt"),
	_doc_items_longdesc = S("Melting snow and ice generates an endless stream of water source blocks"),
	_doc_items_usagehelp = S("Generates one source block of water directly on top of itself once per second, provided the space is clear. If this natural spring is dug out the flow stops and it is turned into ordinary cobble."),
	drops = "default:snow",
	paramtype = "light",
	paramtype2 = "facedir",
	tiles = {"default_ice.png^[combine:16x80:0,-48=crack_anylength.png",
		"default_ice.png^[combine:16x80:0,-48=crack_anylength.png",
		"default_ice.png^[combine:16x80:0,-48=crack_anylength.png",
		"default_ice.png^[combine:16x80:0,-48=crack_anylength.png",
		"default_ice.png^[combine:16x80:0,-48=crack_anylength.png",
		"default_ice.png^[combine:16x80:0,-48=crack_anylength.png",
		},
	is_ground_content = false,
	groups = {cracky = 3, stone = 2},
	sounds = default.node_sound_gravel_defaults(),
})
	

