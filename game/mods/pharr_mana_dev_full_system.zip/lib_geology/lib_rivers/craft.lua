



----------------------------------------------------------------
---CRAFT
----------------------------------------------------------------


--Crafting river

minetest.register_craft({
	output = "lib_rivers:water_rushing",
	recipe = {
		{'', '', ''},
		{'default:dirt', 'default:river_water_flowing', ''},
		{'', '', ''}
	}
})


minetest.register_craft({
	output = "lib_rivers:spring",
	recipe = {
		{'', 'default:river_water_flowing', ''},
		{'', "group:stone", ''},
		{'', '', ''}
	}
})


minetest.register_craft({
	output = "lib_rivers:snow_melt",
	recipe = {
		{'', 'default:ice', ''},
		{'', "group:stone", ''},
		{'', '', ''}
	}
})


