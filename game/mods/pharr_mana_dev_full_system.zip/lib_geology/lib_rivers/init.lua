-------------------------------------------------------------
--Do files
-------------------------------------------------------------
local water_level = tonumber(minetest.get_mapgen_setting("water_level")) or 1
local search_radius = 8



-- internationalization boilerplate
local MP = minetest.get_modpath(minetest.get_current_modname())
S, NS = dofile(MP.."/intllib.lua")

dofile(minetest.get_modpath("lib_rivers").."/nodes.lua")

dofile(minetest.get_modpath("lib_rivers").."/craft.lua")



------------------------------------------------------------------ABMS
---------------------------------------------------------------

-- Spawn springs and snowmelts.

--[[

minetest.register_ore({
	ore_type = "scatter", -- See "Ore types"
	ore = "lib_rivers:spring",
	wherein = {"default:stone", "default:desert_stone", "valleys_c:sand_stone", "valleys_c:brown_stone", },
	clust_scarcity = 8*8*8,
	clust_num_ores = 1,
	clust_size = 3,
	y_min = -1000,
	y_max = 12000,
	flags = "",
	noise_threshold = 0.5,
	noise_params = {offset=0, scale=1, spread={x=100, y=100, z=100}, seed=42, octaves=3, persist=0.70},
			--  ^ NoiseParams structure describing the perlin noise used for ore distribution.
			--  ^ Needed for sheet ore_type.  Omit from scatter ore_type for a uniform ore distribution
	random_factor = 1.0,
			--  ^ Multiplier of the randomness contribution to the noise value at any
			--   given point to decide if ore should be placed.  Set to 0 for solid veins.
			--  ^ This parameter is only valid for ore_type == "vein".
	--biomes = {"tundra", "desert"}
			--  ^ List of biomes in which this decoration occurs.  Occurs in all biomes if this is omitted,
			--  ^ and ignored if the Mapgen being used does not support biomes.
			--  ^ Can be a list of (or a single) biome names, IDs, or definitions.
})


minetest.register_ore({
	ore_type = "scatter", -- See "Ore types"
	ore = "lib_rivers:snow_melt",
	wherein = "default:ice",
	clust_scarcity = 8*8*8,
	clust_num_ores = 1,
	clust_size = 3,
	y_min = 1,
	y_max = 1200,
	flags = "",
	noise_threshold = 0.5,
	noise_params = {offset=0, scale=1, spread={x=100, y=100, z=100}, seed=23, octaves=3, persist=0.70},
			--  ^ NoiseParams structure describing the perlin noise used for ore distribution.
			--  ^ Needed for sheet ore_type.  Omit from scatter ore_type for a uniform ore distribution
	random_factor = 1.0,
			--  ^ Multiplier of the randomness contribution to the noise value at any
			--   given point to decide if ore should be placed.  Set to 0 for solid veins.
			--  ^ This parameter is only valid for ore_type == "vein".
	biomes = {"glacier"}
			--  ^ List of biomes in which this decoration occurs.  Occurs in all biomes if this is omitted,
			--  ^ and ignored if the Mapgen being used does not support biomes.
			--  ^ Can be a list of (or a single) biome names, IDs, or definitions.
})

--]]



--[[
minetest.register_decoration({
	deco_type = "simple",
	place_on = {"default:stone"},
	sidelen = 16,
	noise_params = {
		offset = 0,
		scale = 0.007,
		spread = {x = 100, y = 100, z = 100},
		seed = 329,
		octaves = 3,
		persist = 0.6
	},
	y_min = 1,
	y_max = 30,
	spawn_by = {"default:dirt"},
	num_spawn_by = 3,
	decoration = "lib_rivers:spring",
})

minetest.register_decoration({
	deco_type = "simple",
	place_on = {"default:stone", "default:dirt"},
	sidelen = 16,
	noise_params = {
		offset = 0,
		scale = 0.007,
		spread = {x = 100, y = 100, z = 100},
		seed = 329,
		octaves = 3,
		persist = 0.6
	},
	y_min = 1,
	y_max = 30,
	spawn_by = {"default:ice", "default:snow"},
	num_spawn_by = 3,
	decoration = "lib_rivers:snow_melt",
})

--]]


-- Grow river

minetest.register_abm({
    nodenames = {"lib_rivers:water_rushing"},
	neighbors = {"air"},
	interval = 3,
	chance = 1,
	action = function(pos)
	
		if (pos.y - 1) < water_level then
			return
		end
	
		local node_below = minetest.get_node({pos.x, pos.y - 1, pos.z})
		local node_below_name = node_below.name
	
		if node_below_name == "air" then
		
			minetest.set_node({pos.x, pos.y - 1, pos.z}, {name = "lib_rivers:water_rushing"})
			minetest.set_node(pos, {name = "lib_rivers:river_water"})
			minetest.sound_play("default_water_footstep.1.ogg", {pos = pos, gain = 0.5, max_hear_distance = 15,})
			
		else

			local idx = 0
			local path_to_follow = {}
			local air_pos = {}
			local air_pos_name = ""
			local count_air_pos_y = 0
			
			repeat
				--air_pos = (minetest.find_node_near(pos, idx, "air") or nil)
				
				local ps, cn = minetest.find_nodes_in_area(
					{x = pos.x - idx, y = pos.y, z = pos.z - idx},
					{x = pos.x + idx, y = pos.y, z = pos.z + idx}, {"air"})
				count_air_pos_y = (cn["air"] or 0)
				
				if count_air_pos_y > 0 then
					air_pos = {x = ps.x, y = ps.y, z = ps.z}
				end
				
				if air_pos then
					air_pos_name = minetest.get_node(air_pos).name
				end
				
				idx = idx + 1
				
			until air_pos_name == "air" or idx == search_radius or count_air_pos_y > 0
			
			if air_pos_name == "air" then
			
				if idx == 1 then

					minetest.set_node({pos.x, pos.y - 1, pos.z}, {name = "lib_rivers:water_rushing"})
					minetest.set_node(pos, {name = "lib_rivers:river_water"})
					minetest.sound_play("default_water_footstep.1.ogg", {pos = pos, gain = 0.5, max_hear_distance = 15,})

				end
				
				if idx > 1 then
			
					path_to_follow = minetest.find_path(pos, air_pos, idx, 0, 1, "Dijkstra")
					
					if path_to_follow then
					
						minetest.log(dump(path_to_follow))
					
						air_pos = path_to_follow[0]
									
						minetest.set_node(air_pos, {name = "lib_rivers:water_rushing"})
						minetest.set_node(pos, {name = "lib_rivers:river_water"})
						minetest.sound_play("default_water_footstep.1.ogg", {pos = pos, gain = 0.5, max_hear_distance = 15,})

					end
					
				end
				
			else
			
				local new_pos = {x = pos.x + math.random(-1,1), y = pos.y, z = pos.z + math.random(-1,1)}
				
				minetest.log("###  lib_rivers   ###      new pos: " .. minetest.pos_to_string(new_pos))

				minetest.set_node(new_pos, {name = "lib_rivers:water_rushing"})
				minetest.set_node(pos, {name = "lib_rivers:river_water"})
				minetest.sound_play("default_water_footstep.1.ogg", {pos = pos, gain = 0.5, max_hear_distance = 15,})

			end
		end
	end,
		
})





minetest.register_abm({
    nodenames = {"lib_rivers:river_water"},
	neighbors = {"lib_rivers:water_rushing"},
	interval = 10,
	chance = 2,
	action = function(pos)

		minetest.set_node(pos, {name = "default:river_water_source"})
		minetest.sound_play("default_water_footstep.1.ogg", {pos = pos, gain = 0.5, max_hear_distance = 15,})

		minetest.log("###  lib_rivers   ###      RIVER CARVED AT: " .. minetest.pos_to_string(pos))

	end
		
})


minetest.register_abm({
	label = "lib_rivers creative spring",
	nodenames = {"lib_rivers:spring"},
	neighbors = {"air" },
	interval = 4,
	chance = 1,
	catch_up = false,
	action = function(pos,node)
		
		local air_pos = minetest.find_node_near(pos, 1, "air")
		local check_node = minetest.get_node(air_pos)
		local check_node_name = check_node.name
		if check_node_name == "air" then
			minetest.set_node(air_pos, {name="lib_rivers:water_rushing"})
		end
	end
})	

--[[
local mapgen_prefill = minetest.setting_getbool("lib_rivers_mapgen_prefill")
mapgen_prefill = mapgen_prefill or mapgen_prefill == nil -- default true

if mapgen_prefill then
	local c_water = minetest.get_content_id("lib_rivers:water_rushing")
	local c_air = minetest.get_content_id("air")

	minetest.register_on_generated(function(minp, maxp, seed)
		if minp.y >= water_level then
			return
		end
	
		local vm, emin, emax = minetest.get_mapgen_object("voxelmanip")
		local area = VoxelArea:new{MinEdge=emin, MaxEdge=emax}
		vm:get_data(data)
		
		local filling = false
		for z = minp.z, maxp.z do
			for x = minp.x, maxp.x do
				for y = maxp.y, minp.y, -1 do
					local vi = area:index(x,y,z)
					if data[vi] == c_water then
						filling = true
					elseif data[vi] == c_air and filling == true then
						data[vi] = c_water
					else filling = false end
				end
				filling = false
			end
		end
		vm:set_data(data)
		vm:write_to_map()
		vm:update_liquids()
	end)
end
--]]



