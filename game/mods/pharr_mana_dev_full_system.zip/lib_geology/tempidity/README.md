tempidity
=========

A Minetest mod to display temperature and humidity in-game
