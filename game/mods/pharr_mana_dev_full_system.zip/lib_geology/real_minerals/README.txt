According to the Wayback Machine, RealTest is licensed under the GPLv3:
https://web.archive.org/web/20140331041644/https://forum.minetest.net/viewtopic.php?id=7573
https://web.archive.org/web/20140801020023/https://forum.minetest.net/viewtopic.php?id=2671