

game = {}
game.version = "1.0"
game.path = minetest.get_modpath(minetest.get_current_modname())

-- Intllib
local S
local NS
if minetest.get_modpath("intllib") then
	S = intllib.Getter()
else
	S, NS = dofile(game.path.."/intllib.lua")
end
game.intllib = S

minetest.log(S("[MOD] game:  Loading..."))

game.world_type = minetest.settings:get("game_world_type")
minetest.log(S("[MOD]: game:  Using world type " .. tostring(game.world_type)))




game.api = {}
game.world = {}
game.players = {}
game.rules = {}

game.register_api = function(name, def)
end

game.callbacks = function(name, callbacks)
end
















minetest.log(S("[MOD] game:  Successfully loaded."))

