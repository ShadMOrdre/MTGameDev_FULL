Wool Clothing - Wool Clothing [WIP] [clothing]
==============================================

Depends: multiskin

Recommends: sfinv, inventory_plus or unified_inventory (use only one)

Adds simple clothing that can be crafted from coloured wool using a loom.
Requires the wool mod for craft registration.

Crafting
--------

S = [group:stick]
W = [default:pinewood]

+---+---+---+
| S | W | S |
+---+---+---+
| S | W | S |
+---+---+---+
| W | W | W |
+---+---+---+

Output = [clothing:loom]

Configuration
-------------

Craft registration can disabled by adding `clothing_enable_craft = false` to
your minetest.conf file.
