# white_patterns  


White decorative patterns for exterior walls, inspired by houses in Čičmany, Slovakia.
  

Code licensed as GPLv3 (see file LICENSE)  
Media licensed as CC by SA 3.0 (for more details: http://creativecommons.org/licenses/by-sa/3.0/)  

Crafting brush:  
default:stick  
default:steel_ingot  
dye:white  

Screenshot:  
![Image Decorated walls](https://raw.githubusercontent.com/AspireMint/white_patterns/master/screenshot.png)
